/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EventOrchestrationUnroutedConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#event_orchestration EventOrchestrationUnrouted#event_orchestration}
    */
    readonly eventOrchestration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#id EventOrchestrationUnrouted#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * catch_all block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#catch_all EventOrchestrationUnrouted#catch_all}
    */
    readonly catchAll: EventOrchestrationUnroutedCatchAll;
    /**
    * set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#set EventOrchestrationUnrouted#set}
    */
    readonly set: EventOrchestrationUnroutedSet[] | cdktn.IResolvable;
}
export interface EventOrchestrationUnroutedCatchAllActionsExtraction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#regex EventOrchestrationUnrouted#regex}
    */
    readonly regex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#source EventOrchestrationUnrouted#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#target EventOrchestrationUnrouted#target}
    */
    readonly target: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#template EventOrchestrationUnrouted#template}
    */
    readonly template?: string;
}
export declare function eventOrchestrationUnroutedCatchAllActionsExtractionToTerraform(struct?: EventOrchestrationUnroutedCatchAllActionsExtraction | cdktn.IResolvable): any;
export declare function eventOrchestrationUnroutedCatchAllActionsExtractionToHclTerraform(struct?: EventOrchestrationUnroutedCatchAllActionsExtraction | cdktn.IResolvable): any;
export declare class EventOrchestrationUnroutedCatchAllActionsExtractionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationUnroutedCatchAllActionsExtraction | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationUnroutedCatchAllActionsExtraction | cdktn.IResolvable | undefined);
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    resetTemplate(): void;
    get templateInput(): string | undefined;
}
export declare class EventOrchestrationUnroutedCatchAllActionsExtractionList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationUnroutedCatchAllActionsExtraction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationUnroutedCatchAllActionsExtractionOutputReference;
}
export interface EventOrchestrationUnroutedCatchAllActionsVariable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#name EventOrchestrationUnrouted#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#path EventOrchestrationUnrouted#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#type EventOrchestrationUnrouted#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#value EventOrchestrationUnrouted#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationUnroutedCatchAllActionsVariableToTerraform(struct?: EventOrchestrationUnroutedCatchAllActionsVariable | cdktn.IResolvable): any;
export declare function eventOrchestrationUnroutedCatchAllActionsVariableToHclTerraform(struct?: EventOrchestrationUnroutedCatchAllActionsVariable | cdktn.IResolvable): any;
export declare class EventOrchestrationUnroutedCatchAllActionsVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationUnroutedCatchAllActionsVariable | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationUnroutedCatchAllActionsVariable | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationUnroutedCatchAllActionsVariableList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationUnroutedCatchAllActionsVariable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationUnroutedCatchAllActionsVariableOutputReference;
}
export interface EventOrchestrationUnroutedCatchAllActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#event_action EventOrchestrationUnrouted#event_action}
    */
    readonly eventAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#severity EventOrchestrationUnrouted#severity}
    */
    readonly severity?: string;
    /**
    * extraction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#extraction EventOrchestrationUnrouted#extraction}
    */
    readonly extraction?: EventOrchestrationUnroutedCatchAllActionsExtraction[] | cdktn.IResolvable;
    /**
    * variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#variable EventOrchestrationUnrouted#variable}
    */
    readonly variable?: EventOrchestrationUnroutedCatchAllActionsVariable[] | cdktn.IResolvable;
}
export declare function eventOrchestrationUnroutedCatchAllActionsToTerraform(struct?: EventOrchestrationUnroutedCatchAllActionsOutputReference | EventOrchestrationUnroutedCatchAllActions): any;
export declare function eventOrchestrationUnroutedCatchAllActionsToHclTerraform(struct?: EventOrchestrationUnroutedCatchAllActionsOutputReference | EventOrchestrationUnroutedCatchAllActions): any;
export declare class EventOrchestrationUnroutedCatchAllActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationUnroutedCatchAllActions | undefined;
    set internalValue(value: EventOrchestrationUnroutedCatchAllActions | undefined);
    private _eventAction?;
    get eventAction(): string;
    set eventAction(value: string);
    resetEventAction(): void;
    get eventActionInput(): string | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    resetSeverity(): void;
    get severityInput(): string | undefined;
    get suppress(): cdktn.IResolvable;
    private _extraction;
    get extraction(): EventOrchestrationUnroutedCatchAllActionsExtractionList;
    putExtraction(value: EventOrchestrationUnroutedCatchAllActionsExtraction[] | cdktn.IResolvable): void;
    resetExtraction(): void;
    get extractionInput(): cdktn.IResolvable | EventOrchestrationUnroutedCatchAllActionsExtraction[] | undefined;
    private _variable;
    get variable(): EventOrchestrationUnroutedCatchAllActionsVariableList;
    putVariable(value: EventOrchestrationUnroutedCatchAllActionsVariable[] | cdktn.IResolvable): void;
    resetVariable(): void;
    get variableInput(): cdktn.IResolvable | EventOrchestrationUnroutedCatchAllActionsVariable[] | undefined;
}
export interface EventOrchestrationUnroutedCatchAll {
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#actions EventOrchestrationUnrouted#actions}
    */
    readonly actions: EventOrchestrationUnroutedCatchAllActions;
}
export declare function eventOrchestrationUnroutedCatchAllToTerraform(struct?: EventOrchestrationUnroutedCatchAllOutputReference | EventOrchestrationUnroutedCatchAll): any;
export declare function eventOrchestrationUnroutedCatchAllToHclTerraform(struct?: EventOrchestrationUnroutedCatchAllOutputReference | EventOrchestrationUnroutedCatchAll): any;
export declare class EventOrchestrationUnroutedCatchAllOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationUnroutedCatchAll | undefined;
    set internalValue(value: EventOrchestrationUnroutedCatchAll | undefined);
    private _actions;
    get actions(): EventOrchestrationUnroutedCatchAllActionsOutputReference;
    putActions(value: EventOrchestrationUnroutedCatchAllActions): void;
    get actionsInput(): EventOrchestrationUnroutedCatchAllActions | undefined;
}
export interface EventOrchestrationUnroutedSetRuleActionsExtraction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#regex EventOrchestrationUnrouted#regex}
    */
    readonly regex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#source EventOrchestrationUnrouted#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#target EventOrchestrationUnrouted#target}
    */
    readonly target: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#template EventOrchestrationUnrouted#template}
    */
    readonly template?: string;
}
export declare function eventOrchestrationUnroutedSetRuleActionsExtractionToTerraform(struct?: EventOrchestrationUnroutedSetRuleActionsExtraction | cdktn.IResolvable): any;
export declare function eventOrchestrationUnroutedSetRuleActionsExtractionToHclTerraform(struct?: EventOrchestrationUnroutedSetRuleActionsExtraction | cdktn.IResolvable): any;
export declare class EventOrchestrationUnroutedSetRuleActionsExtractionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationUnroutedSetRuleActionsExtraction | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationUnroutedSetRuleActionsExtraction | cdktn.IResolvable | undefined);
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    resetTemplate(): void;
    get templateInput(): string | undefined;
}
export declare class EventOrchestrationUnroutedSetRuleActionsExtractionList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationUnroutedSetRuleActionsExtraction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationUnroutedSetRuleActionsExtractionOutputReference;
}
export interface EventOrchestrationUnroutedSetRuleActionsVariable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#name EventOrchestrationUnrouted#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#path EventOrchestrationUnrouted#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#type EventOrchestrationUnrouted#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#value EventOrchestrationUnrouted#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationUnroutedSetRuleActionsVariableToTerraform(struct?: EventOrchestrationUnroutedSetRuleActionsVariable | cdktn.IResolvable): any;
export declare function eventOrchestrationUnroutedSetRuleActionsVariableToHclTerraform(struct?: EventOrchestrationUnroutedSetRuleActionsVariable | cdktn.IResolvable): any;
export declare class EventOrchestrationUnroutedSetRuleActionsVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationUnroutedSetRuleActionsVariable | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationUnroutedSetRuleActionsVariable | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationUnroutedSetRuleActionsVariableList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationUnroutedSetRuleActionsVariable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationUnroutedSetRuleActionsVariableOutputReference;
}
export interface EventOrchestrationUnroutedSetRuleActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#event_action EventOrchestrationUnrouted#event_action}
    */
    readonly eventAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#route_to EventOrchestrationUnrouted#route_to}
    */
    readonly routeTo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#severity EventOrchestrationUnrouted#severity}
    */
    readonly severity?: string;
    /**
    * extraction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#extraction EventOrchestrationUnrouted#extraction}
    */
    readonly extraction?: EventOrchestrationUnroutedSetRuleActionsExtraction[] | cdktn.IResolvable;
    /**
    * variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#variable EventOrchestrationUnrouted#variable}
    */
    readonly variable?: EventOrchestrationUnroutedSetRuleActionsVariable[] | cdktn.IResolvable;
}
export declare function eventOrchestrationUnroutedSetRuleActionsToTerraform(struct?: EventOrchestrationUnroutedSetRuleActionsOutputReference | EventOrchestrationUnroutedSetRuleActions): any;
export declare function eventOrchestrationUnroutedSetRuleActionsToHclTerraform(struct?: EventOrchestrationUnroutedSetRuleActionsOutputReference | EventOrchestrationUnroutedSetRuleActions): any;
export declare class EventOrchestrationUnroutedSetRuleActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationUnroutedSetRuleActions | undefined;
    set internalValue(value: EventOrchestrationUnroutedSetRuleActions | undefined);
    private _eventAction?;
    get eventAction(): string;
    set eventAction(value: string);
    resetEventAction(): void;
    get eventActionInput(): string | undefined;
    private _routeTo?;
    get routeTo(): string;
    set routeTo(value: string);
    resetRouteTo(): void;
    get routeToInput(): string | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    resetSeverity(): void;
    get severityInput(): string | undefined;
    private _extraction;
    get extraction(): EventOrchestrationUnroutedSetRuleActionsExtractionList;
    putExtraction(value: EventOrchestrationUnroutedSetRuleActionsExtraction[] | cdktn.IResolvable): void;
    resetExtraction(): void;
    get extractionInput(): cdktn.IResolvable | EventOrchestrationUnroutedSetRuleActionsExtraction[] | undefined;
    private _variable;
    get variable(): EventOrchestrationUnroutedSetRuleActionsVariableList;
    putVariable(value: EventOrchestrationUnroutedSetRuleActionsVariable[] | cdktn.IResolvable): void;
    resetVariable(): void;
    get variableInput(): cdktn.IResolvable | EventOrchestrationUnroutedSetRuleActionsVariable[] | undefined;
}
export interface EventOrchestrationUnroutedSetRuleCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#expression EventOrchestrationUnrouted#expression}
    */
    readonly expression: string;
}
export declare function eventOrchestrationUnroutedSetRuleConditionToTerraform(struct?: EventOrchestrationUnroutedSetRuleCondition | cdktn.IResolvable): any;
export declare function eventOrchestrationUnroutedSetRuleConditionToHclTerraform(struct?: EventOrchestrationUnroutedSetRuleCondition | cdktn.IResolvable): any;
export declare class EventOrchestrationUnroutedSetRuleConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationUnroutedSetRuleCondition | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationUnroutedSetRuleCondition | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export declare class EventOrchestrationUnroutedSetRuleConditionList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationUnroutedSetRuleCondition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationUnroutedSetRuleConditionOutputReference;
}
export interface EventOrchestrationUnroutedSetRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#disabled EventOrchestrationUnrouted#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#label EventOrchestrationUnrouted#label}
    */
    readonly label?: string;
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#actions EventOrchestrationUnrouted#actions}
    */
    readonly actions: EventOrchestrationUnroutedSetRuleActions;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#condition EventOrchestrationUnrouted#condition}
    */
    readonly condition?: EventOrchestrationUnroutedSetRuleCondition[] | cdktn.IResolvable;
}
export declare function eventOrchestrationUnroutedSetRuleToTerraform(struct?: EventOrchestrationUnroutedSetRule | cdktn.IResolvable): any;
export declare function eventOrchestrationUnroutedSetRuleToHclTerraform(struct?: EventOrchestrationUnroutedSetRule | cdktn.IResolvable): any;
export declare class EventOrchestrationUnroutedSetRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationUnroutedSetRule | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationUnroutedSetRule | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _actions;
    get actions(): EventOrchestrationUnroutedSetRuleActionsOutputReference;
    putActions(value: EventOrchestrationUnroutedSetRuleActions): void;
    get actionsInput(): EventOrchestrationUnroutedSetRuleActions | undefined;
    private _condition;
    get condition(): EventOrchestrationUnroutedSetRuleConditionList;
    putCondition(value: EventOrchestrationUnroutedSetRuleCondition[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | EventOrchestrationUnroutedSetRuleCondition[] | undefined;
}
export declare class EventOrchestrationUnroutedSetRuleList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationUnroutedSetRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationUnroutedSetRuleOutputReference;
}
export interface EventOrchestrationUnroutedSet {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#id EventOrchestrationUnrouted#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#rule EventOrchestrationUnrouted#rule}
    */
    readonly rule?: EventOrchestrationUnroutedSetRule[] | cdktn.IResolvable;
}
export declare function eventOrchestrationUnroutedSetToTerraform(struct?: EventOrchestrationUnroutedSet | cdktn.IResolvable): any;
export declare function eventOrchestrationUnroutedSetToHclTerraform(struct?: EventOrchestrationUnroutedSet | cdktn.IResolvable): any;
export declare class EventOrchestrationUnroutedSetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationUnroutedSet | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationUnroutedSet | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _rule;
    get rule(): EventOrchestrationUnroutedSetRuleList;
    putRule(value: EventOrchestrationUnroutedSetRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | EventOrchestrationUnroutedSetRule[] | undefined;
}
export declare class EventOrchestrationUnroutedSetList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationUnroutedSet[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationUnroutedSetOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted pagerduty_event_orchestration_unrouted}
*/
export declare class EventOrchestrationUnrouted extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_event_orchestration_unrouted";
    /**
    * Generates CDKTN code for importing a EventOrchestrationUnrouted resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EventOrchestrationUnrouted to import
    * @param importFromId The id of the existing EventOrchestrationUnrouted that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EventOrchestrationUnrouted to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/event_orchestration_unrouted pagerduty_event_orchestration_unrouted} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EventOrchestrationUnroutedConfig
    */
    constructor(scope: Construct, id: string, config: EventOrchestrationUnroutedConfig);
    private _eventOrchestration?;
    get eventOrchestration(): string;
    set eventOrchestration(value: string);
    get eventOrchestrationInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _catchAll;
    get catchAll(): EventOrchestrationUnroutedCatchAllOutputReference;
    putCatchAll(value: EventOrchestrationUnroutedCatchAll): void;
    get catchAllInput(): EventOrchestrationUnroutedCatchAll | undefined;
    private _set;
    get set(): EventOrchestrationUnroutedSetList;
    putSet(value: EventOrchestrationUnroutedSet[] | cdktn.IResolvable): void;
    get setInput(): cdktn.IResolvable | EventOrchestrationUnroutedSet[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
