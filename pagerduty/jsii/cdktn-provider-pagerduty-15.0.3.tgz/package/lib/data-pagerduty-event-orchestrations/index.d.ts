/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPagerdutyEventOrchestrationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/data-sources/event_orchestrations#id DataPagerdutyEventOrchestrations#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/data-sources/event_orchestrations#name_filter DataPagerdutyEventOrchestrations#name_filter}
    */
    readonly nameFilter: string;
}
export interface DataPagerdutyEventOrchestrationsEventOrchestrationsIntegrationParameters {
}
export declare function dataPagerdutyEventOrchestrationsEventOrchestrationsIntegrationParametersToTerraform(struct?: DataPagerdutyEventOrchestrationsEventOrchestrationsIntegrationParameters): any;
export declare function dataPagerdutyEventOrchestrationsEventOrchestrationsIntegrationParametersToHclTerraform(struct?: DataPagerdutyEventOrchestrationsEventOrchestrationsIntegrationParameters): any;
export declare class DataPagerdutyEventOrchestrationsEventOrchestrationsIntegrationParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyEventOrchestrationsEventOrchestrationsIntegrationParameters | undefined;
    set internalValue(value: DataPagerdutyEventOrchestrationsEventOrchestrationsIntegrationParameters | undefined);
    get routingKey(): string;
    get type(): string;
}
export declare class DataPagerdutyEventOrchestrationsEventOrchestrationsIntegrationParametersList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyEventOrchestrationsEventOrchestrationsIntegrationParametersOutputReference;
}
export interface DataPagerdutyEventOrchestrationsEventOrchestrationsIntegration {
}
export declare function dataPagerdutyEventOrchestrationsEventOrchestrationsIntegrationToTerraform(struct?: DataPagerdutyEventOrchestrationsEventOrchestrationsIntegration): any;
export declare function dataPagerdutyEventOrchestrationsEventOrchestrationsIntegrationToHclTerraform(struct?: DataPagerdutyEventOrchestrationsEventOrchestrationsIntegration): any;
export declare class DataPagerdutyEventOrchestrationsEventOrchestrationsIntegrationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyEventOrchestrationsEventOrchestrationsIntegration | undefined;
    set internalValue(value: DataPagerdutyEventOrchestrationsEventOrchestrationsIntegration | undefined);
    get id(): string;
    get label(): string;
    private _parameters;
    get parameters(): DataPagerdutyEventOrchestrationsEventOrchestrationsIntegrationParametersList;
}
export declare class DataPagerdutyEventOrchestrationsEventOrchestrationsIntegrationList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyEventOrchestrationsEventOrchestrationsIntegrationOutputReference;
}
export interface DataPagerdutyEventOrchestrationsEventOrchestrations {
}
export declare function dataPagerdutyEventOrchestrationsEventOrchestrationsToTerraform(struct?: DataPagerdutyEventOrchestrationsEventOrchestrations): any;
export declare function dataPagerdutyEventOrchestrationsEventOrchestrationsToHclTerraform(struct?: DataPagerdutyEventOrchestrationsEventOrchestrations): any;
export declare class DataPagerdutyEventOrchestrationsEventOrchestrationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyEventOrchestrationsEventOrchestrations | undefined;
    set internalValue(value: DataPagerdutyEventOrchestrationsEventOrchestrations | undefined);
    get id(): string;
    private _integration;
    get integration(): DataPagerdutyEventOrchestrationsEventOrchestrationsIntegrationList;
    get name(): string;
}
export declare class DataPagerdutyEventOrchestrationsEventOrchestrationsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyEventOrchestrationsEventOrchestrationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/data-sources/event_orchestrations pagerduty_event_orchestrations}
*/
export declare class DataPagerdutyEventOrchestrations extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_event_orchestrations";
    /**
    * Generates CDKTN code for importing a DataPagerdutyEventOrchestrations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyEventOrchestrations to import
    * @param importFromId The id of the existing DataPagerdutyEventOrchestrations that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/data-sources/event_orchestrations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyEventOrchestrations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/data-sources/event_orchestrations pagerduty_event_orchestrations} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyEventOrchestrationsConfig
    */
    constructor(scope: Construct, id: string, config: DataPagerdutyEventOrchestrationsConfig);
    private _eventOrchestrations;
    get eventOrchestrations(): DataPagerdutyEventOrchestrationsEventOrchestrationsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _nameFilter?;
    get nameFilter(): string;
    set nameFilter(value: string);
    get nameFilterInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
