/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPagerdutyIncidentCustomFieldConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/data-sources/incident_custom_field#id DataPagerdutyIncidentCustomField#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/data-sources/incident_custom_field#name DataPagerdutyIncidentCustomField#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/data-sources/incident_custom_field pagerduty_incident_custom_field}
*/
export declare class DataPagerdutyIncidentCustomField extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_incident_custom_field";
    /**
    * Generates CDKTN code for importing a DataPagerdutyIncidentCustomField resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyIncidentCustomField to import
    * @param importFromId The id of the existing DataPagerdutyIncidentCustomField that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/data-sources/incident_custom_field#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyIncidentCustomField to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/data-sources/incident_custom_field pagerduty_incident_custom_field} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyIncidentCustomFieldConfig
    */
    constructor(scope: Construct, id: string, config: DataPagerdutyIncidentCustomFieldConfig);
    get dataType(): string;
    get description(): string;
    get displayName(): string;
    get fieldType(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
