/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServiceDependencyConfig extends cdktn.TerraformMetaArguments {
    /**
    * dependency block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/service_dependency#dependency ServiceDependency#dependency}
    */
    readonly dependency?: ServiceDependencyDependency[] | cdktn.IResolvable;
}
export interface ServiceDependencyDependencyDependentService {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/service_dependency#id ServiceDependency#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/service_dependency#type ServiceDependency#type}
    */
    readonly type: string;
}
export declare function serviceDependencyDependencyDependentServiceToTerraform(struct?: ServiceDependencyDependencyDependentService | cdktn.IResolvable): any;
export declare function serviceDependencyDependencyDependentServiceToHclTerraform(struct?: ServiceDependencyDependencyDependentService | cdktn.IResolvable): any;
export declare class ServiceDependencyDependencyDependentServiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceDependencyDependencyDependentService | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceDependencyDependencyDependentService | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ServiceDependencyDependencyDependentServiceList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceDependencyDependencyDependentService[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceDependencyDependencyDependentServiceOutputReference;
}
export interface ServiceDependencyDependencySupportingService {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/service_dependency#id ServiceDependency#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/service_dependency#type ServiceDependency#type}
    */
    readonly type: string;
}
export declare function serviceDependencyDependencySupportingServiceToTerraform(struct?: ServiceDependencyDependencySupportingService | cdktn.IResolvable): any;
export declare function serviceDependencyDependencySupportingServiceToHclTerraform(struct?: ServiceDependencyDependencySupportingService | cdktn.IResolvable): any;
export declare class ServiceDependencyDependencySupportingServiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceDependencyDependencySupportingService | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceDependencyDependencySupportingService | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ServiceDependencyDependencySupportingServiceList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceDependencyDependencySupportingService[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceDependencyDependencySupportingServiceOutputReference;
}
export interface ServiceDependencyDependency {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/service_dependency#type ServiceDependency#type}
    */
    readonly type?: string;
    /**
    * dependent_service block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/service_dependency#dependent_service ServiceDependency#dependent_service}
    */
    readonly dependentService?: ServiceDependencyDependencyDependentService[] | cdktn.IResolvable;
    /**
    * supporting_service block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/service_dependency#supporting_service ServiceDependency#supporting_service}
    */
    readonly supportingService?: ServiceDependencyDependencySupportingService[] | cdktn.IResolvable;
}
export declare function serviceDependencyDependencyToTerraform(struct?: ServiceDependencyDependency | cdktn.IResolvable): any;
export declare function serviceDependencyDependencyToHclTerraform(struct?: ServiceDependencyDependency | cdktn.IResolvable): any;
export declare class ServiceDependencyDependencyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceDependencyDependency | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceDependencyDependency | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _dependentService;
    get dependentService(): ServiceDependencyDependencyDependentServiceList;
    putDependentService(value: ServiceDependencyDependencyDependentService[] | cdktn.IResolvable): void;
    resetDependentService(): void;
    get dependentServiceInput(): cdktn.IResolvable | ServiceDependencyDependencyDependentService[] | undefined;
    private _supportingService;
    get supportingService(): ServiceDependencyDependencySupportingServiceList;
    putSupportingService(value: ServiceDependencyDependencySupportingService[] | cdktn.IResolvable): void;
    resetSupportingService(): void;
    get supportingServiceInput(): cdktn.IResolvable | ServiceDependencyDependencySupportingService[] | undefined;
}
export declare class ServiceDependencyDependencyList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceDependencyDependency[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceDependencyDependencyOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/service_dependency pagerduty_service_dependency}
*/
export declare class ServiceDependency extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_service_dependency";
    /**
    * Generates CDKTN code for importing a ServiceDependency resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServiceDependency to import
    * @param importFromId The id of the existing ServiceDependency that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/service_dependency#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServiceDependency to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/service_dependency pagerduty_service_dependency} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServiceDependencyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ServiceDependencyConfig);
    get id(): string;
    private _dependency;
    get dependency(): ServiceDependencyDependencyList;
    putDependency(value: ServiceDependencyDependency[] | cdktn.IResolvable): void;
    resetDependency(): void;
    get dependencyInput(): cdktn.IResolvable | ServiceDependencyDependency[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
