/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SlackConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/slack_connection#channel_id SlackConnection#channel_id}
    */
    readonly channelId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/slack_connection#id SlackConnection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/slack_connection#notification_type SlackConnection#notification_type}
    */
    readonly notificationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/slack_connection#source_id SlackConnection#source_id}
    */
    readonly sourceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/slack_connection#source_type SlackConnection#source_type}
    */
    readonly sourceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/slack_connection#workspace_id SlackConnection#workspace_id}
    */
    readonly workspaceId: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/slack_connection#config SlackConnection#config}
    */
    readonly config: SlackConnectionConfigA[] | cdktn.IResolvable;
}
export interface SlackConnectionConfigA {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/slack_connection#events SlackConnection#events}
    */
    readonly events: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/slack_connection#priorities SlackConnection#priorities}
    */
    readonly priorities?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/slack_connection#urgency SlackConnection#urgency}
    */
    readonly urgency?: string;
}
export declare function slackConnectionConfigAToTerraform(struct?: SlackConnectionConfigA | cdktn.IResolvable): any;
export declare function slackConnectionConfigAToHclTerraform(struct?: SlackConnectionConfigA | cdktn.IResolvable): any;
export declare class SlackConnectionConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SlackConnectionConfigA | cdktn.IResolvable | undefined;
    set internalValue(value: SlackConnectionConfigA | cdktn.IResolvable | undefined);
    private _events?;
    get events(): string[];
    set events(value: string[]);
    get eventsInput(): string[] | undefined;
    private _priorities?;
    get priorities(): string[];
    set priorities(value: string[]);
    resetPriorities(): void;
    get prioritiesInput(): string[] | undefined;
    private _urgency?;
    get urgency(): string;
    set urgency(value: string);
    resetUrgency(): void;
    get urgencyInput(): string | undefined;
}
export declare class SlackConnectionConfigAList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: SlackConnectionConfigA[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SlackConnectionConfigAOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/slack_connection pagerduty_slack_connection}
*/
export declare class SlackConnection extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_slack_connection";
    /**
    * Generates CDKTN code for importing a SlackConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SlackConnection to import
    * @param importFromId The id of the existing SlackConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/slack_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SlackConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.3/docs/resources/slack_connection pagerduty_slack_connection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SlackConnectionConfig
    */
    constructor(scope: Construct, id: string, config: SlackConnectionConfig);
    private _channelId?;
    get channelId(): string;
    set channelId(value: string);
    get channelIdInput(): string | undefined;
    get channelName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _notificationType?;
    get notificationType(): string;
    set notificationType(value: string);
    get notificationTypeInput(): string | undefined;
    private _sourceId?;
    get sourceId(): string;
    set sourceId(value: string);
    get sourceIdInput(): string | undefined;
    get sourceName(): string;
    private _sourceType?;
    get sourceType(): string;
    set sourceType(value: string);
    get sourceTypeInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
    private _config;
    get config(): SlackConnectionConfigAList;
    putConfig(value: SlackConnectionConfigA[] | cdktn.IResolvable): void;
    get configInput(): cdktn.IResolvable | SlackConnectionConfigA[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
