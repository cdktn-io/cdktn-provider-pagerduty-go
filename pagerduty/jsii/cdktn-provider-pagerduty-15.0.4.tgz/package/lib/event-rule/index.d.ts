/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EventRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/event_rule#action_json EventRule#action_json}
    */
    readonly actionJson: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/event_rule#advanced_condition_json EventRule#advanced_condition_json}
    */
    readonly advancedConditionJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/event_rule#condition_json EventRule#condition_json}
    */
    readonly conditionJson: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/event_rule#id EventRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/event_rule pagerduty_event_rule}
*/
export declare class EventRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_event_rule";
    /**
    * Generates CDKTN code for importing a EventRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EventRule to import
    * @param importFromId The id of the existing EventRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/event_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EventRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/event_rule pagerduty_event_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EventRuleConfig
    */
    constructor(scope: Construct, id: string, config: EventRuleConfig);
    private _actionJson?;
    get actionJson(): string;
    set actionJson(value: string);
    get actionJsonInput(): string | undefined;
    private _advancedConditionJson?;
    get advancedConditionJson(): string;
    set advancedConditionJson(value: string);
    resetAdvancedConditionJson(): void;
    get advancedConditionJsonInput(): string | undefined;
    get catchAll(): cdktn.IResolvable;
    private _conditionJson?;
    get conditionJson(): string;
    set conditionJson(value: string);
    get conditionJsonInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
