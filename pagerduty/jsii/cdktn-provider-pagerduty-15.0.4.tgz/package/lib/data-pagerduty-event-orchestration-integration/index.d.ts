/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPagerdutyEventOrchestrationIntegrationAConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/data-sources/event_orchestration_integration#event_orchestration DataPagerdutyEventOrchestrationIntegrationA#event_orchestration}
    */
    readonly eventOrchestration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/data-sources/event_orchestration_integration#id DataPagerdutyEventOrchestrationIntegrationA#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/data-sources/event_orchestration_integration#label DataPagerdutyEventOrchestrationIntegrationA#label}
    */
    readonly label?: string;
}
export interface DataPagerdutyEventOrchestrationIntegrationParametersA {
}
export declare function dataPagerdutyEventOrchestrationIntegrationParametersAToTerraform(struct?: DataPagerdutyEventOrchestrationIntegrationParametersA): any;
export declare function dataPagerdutyEventOrchestrationIntegrationParametersAToHclTerraform(struct?: DataPagerdutyEventOrchestrationIntegrationParametersA): any;
export declare class DataPagerdutyEventOrchestrationIntegrationParametersAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyEventOrchestrationIntegrationParametersA | undefined;
    set internalValue(value: DataPagerdutyEventOrchestrationIntegrationParametersA | undefined);
    get routingKey(): string;
    get type(): string;
}
export declare class DataPagerdutyEventOrchestrationIntegrationParametersAList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyEventOrchestrationIntegrationParametersAOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/data-sources/event_orchestration_integration pagerduty_event_orchestration_integration}
*/
export declare class DataPagerdutyEventOrchestrationIntegrationA extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_event_orchestration_integration";
    /**
    * Generates CDKTN code for importing a DataPagerdutyEventOrchestrationIntegrationA resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyEventOrchestrationIntegrationA to import
    * @param importFromId The id of the existing DataPagerdutyEventOrchestrationIntegrationA that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/data-sources/event_orchestration_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyEventOrchestrationIntegrationA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/data-sources/event_orchestration_integration pagerduty_event_orchestration_integration} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyEventOrchestrationIntegrationAConfig
    */
    constructor(scope: Construct, id: string, config: DataPagerdutyEventOrchestrationIntegrationAConfig);
    private _eventOrchestration?;
    get eventOrchestration(): string;
    set eventOrchestration(value: string);
    get eventOrchestrationInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _parameters;
    get parameters(): DataPagerdutyEventOrchestrationIntegrationParametersAList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
