/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PagerdutyProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs#api_url_override PagerdutyProvider#api_url_override}
    */
    readonly apiUrlOverride?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs#insecure_tls PagerdutyProvider#insecure_tls}
    */
    readonly insecureTls?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs#service_region PagerdutyProvider#service_region}
    */
    readonly serviceRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs#skip_credentials_validation PagerdutyProvider#skip_credentials_validation}
    */
    readonly skipCredentialsValidation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs#token PagerdutyProvider#token}
    */
    readonly token?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs#user_token PagerdutyProvider#user_token}
    */
    readonly userToken?: string;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs#alias PagerdutyProvider#alias}
    */
    readonly alias?: string;
    /**
    * use_app_oauth_scoped_token block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs#use_app_oauth_scoped_token PagerdutyProvider#use_app_oauth_scoped_token}
    */
    readonly useAppOauthScopedToken?: PagerdutyProviderUseAppOauthScopedToken;
}
export interface PagerdutyProviderUseAppOauthScopedToken {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs#pd_client_id PagerdutyProvider#pd_client_id}
    */
    readonly pdClientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs#pd_client_secret PagerdutyProvider#pd_client_secret}
    */
    readonly pdClientSecret?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs#pd_subdomain PagerdutyProvider#pd_subdomain}
    */
    readonly pdSubdomain?: string;
}
export declare function pagerdutyProviderUseAppOauthScopedTokenToTerraform(struct?: PagerdutyProviderUseAppOauthScopedToken): any;
export declare function pagerdutyProviderUseAppOauthScopedTokenToHclTerraform(struct?: PagerdutyProviderUseAppOauthScopedToken): any;
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs pagerduty}
*/
export declare class PagerdutyProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "pagerduty";
    /**
    * Generates CDKTN code for importing a PagerdutyProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PagerdutyProvider to import
    * @param importFromId The id of the existing PagerdutyProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PagerdutyProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs pagerduty} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PagerdutyProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: PagerdutyProviderConfig);
    private _apiUrlOverride?;
    get apiUrlOverride(): string | undefined;
    set apiUrlOverride(value: string | undefined);
    resetApiUrlOverride(): void;
    get apiUrlOverrideInput(): string | undefined;
    private _insecureTls?;
    get insecureTls(): boolean | cdktn.IResolvable | undefined;
    set insecureTls(value: boolean | cdktn.IResolvable | undefined);
    resetInsecureTls(): void;
    get insecureTlsInput(): boolean | cdktn.IResolvable | undefined;
    private _serviceRegion?;
    get serviceRegion(): string | undefined;
    set serviceRegion(value: string | undefined);
    resetServiceRegion(): void;
    get serviceRegionInput(): string | undefined;
    private _skipCredentialsValidation?;
    get skipCredentialsValidation(): boolean | cdktn.IResolvable | undefined;
    set skipCredentialsValidation(value: boolean | cdktn.IResolvable | undefined);
    resetSkipCredentialsValidation(): void;
    get skipCredentialsValidationInput(): boolean | cdktn.IResolvable | undefined;
    private _token?;
    get token(): string | undefined;
    set token(value: string | undefined);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _userToken?;
    get userToken(): string | undefined;
    set userToken(value: string | undefined);
    resetUserToken(): void;
    get userTokenInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _useAppOauthScopedToken?;
    get useAppOauthScopedToken(): PagerdutyProviderUseAppOauthScopedToken | undefined;
    set useAppOauthScopedToken(value: PagerdutyProviderUseAppOauthScopedToken | undefined);
    resetUseAppOauthScopedToken(): void;
    get useAppOauthScopedTokenInput(): PagerdutyProviderUseAppOauthScopedToken | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
