/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServiceEventRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#disabled ServiceEventRule#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#id ServiceEventRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#position ServiceEventRule#position}
    */
    readonly position?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#service ServiceEventRule#service}
    */
    readonly service: string;
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#actions ServiceEventRule#actions}
    */
    readonly actions?: ServiceEventRuleActions;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#conditions ServiceEventRule#conditions}
    */
    readonly conditions?: ServiceEventRuleConditions;
    /**
    * time_frame block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#time_frame ServiceEventRule#time_frame}
    */
    readonly timeFrame?: ServiceEventRuleTimeFrame;
    /**
    * variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#variable ServiceEventRule#variable}
    */
    readonly variable?: ServiceEventRuleVariable[] | cdktn.IResolvable;
}
export interface ServiceEventRuleActionsAnnotate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#value ServiceEventRule#value}
    */
    readonly value?: string;
}
export declare function serviceEventRuleActionsAnnotateToTerraform(struct?: ServiceEventRuleActionsAnnotate | cdktn.IResolvable): any;
export declare function serviceEventRuleActionsAnnotateToHclTerraform(struct?: ServiceEventRuleActionsAnnotate | cdktn.IResolvable): any;
export declare class ServiceEventRuleActionsAnnotateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceEventRuleActionsAnnotate | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceEventRuleActionsAnnotate | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ServiceEventRuleActionsAnnotateList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceEventRuleActionsAnnotate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceEventRuleActionsAnnotateOutputReference;
}
export interface ServiceEventRuleActionsEventAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#value ServiceEventRule#value}
    */
    readonly value?: string;
}
export declare function serviceEventRuleActionsEventActionToTerraform(struct?: ServiceEventRuleActionsEventAction | cdktn.IResolvable): any;
export declare function serviceEventRuleActionsEventActionToHclTerraform(struct?: ServiceEventRuleActionsEventAction | cdktn.IResolvable): any;
export declare class ServiceEventRuleActionsEventActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceEventRuleActionsEventAction | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceEventRuleActionsEventAction | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ServiceEventRuleActionsEventActionList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceEventRuleActionsEventAction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceEventRuleActionsEventActionOutputReference;
}
export interface ServiceEventRuleActionsExtractions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#regex ServiceEventRule#regex}
    */
    readonly regex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#source ServiceEventRule#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#target ServiceEventRule#target}
    */
    readonly target?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#template ServiceEventRule#template}
    */
    readonly template?: string;
}
export declare function serviceEventRuleActionsExtractionsToTerraform(struct?: ServiceEventRuleActionsExtractions | cdktn.IResolvable): any;
export declare function serviceEventRuleActionsExtractionsToHclTerraform(struct?: ServiceEventRuleActionsExtractions | cdktn.IResolvable): any;
export declare class ServiceEventRuleActionsExtractionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceEventRuleActionsExtractions | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceEventRuleActionsExtractions | cdktn.IResolvable | undefined);
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    resetTemplate(): void;
    get templateInput(): string | undefined;
}
export declare class ServiceEventRuleActionsExtractionsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceEventRuleActionsExtractions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceEventRuleActionsExtractionsOutputReference;
}
export interface ServiceEventRuleActionsPriority {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#value ServiceEventRule#value}
    */
    readonly value?: string;
}
export declare function serviceEventRuleActionsPriorityToTerraform(struct?: ServiceEventRuleActionsPriority | cdktn.IResolvable): any;
export declare function serviceEventRuleActionsPriorityToHclTerraform(struct?: ServiceEventRuleActionsPriority | cdktn.IResolvable): any;
export declare class ServiceEventRuleActionsPriorityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceEventRuleActionsPriority | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceEventRuleActionsPriority | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ServiceEventRuleActionsPriorityList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceEventRuleActionsPriority[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceEventRuleActionsPriorityOutputReference;
}
export interface ServiceEventRuleActionsSeverity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#value ServiceEventRule#value}
    */
    readonly value?: string;
}
export declare function serviceEventRuleActionsSeverityToTerraform(struct?: ServiceEventRuleActionsSeverity | cdktn.IResolvable): any;
export declare function serviceEventRuleActionsSeverityToHclTerraform(struct?: ServiceEventRuleActionsSeverity | cdktn.IResolvable): any;
export declare class ServiceEventRuleActionsSeverityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceEventRuleActionsSeverity | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceEventRuleActionsSeverity | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ServiceEventRuleActionsSeverityList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceEventRuleActionsSeverity[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceEventRuleActionsSeverityOutputReference;
}
export interface ServiceEventRuleActionsSuppress {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#threshold_time_amount ServiceEventRule#threshold_time_amount}
    */
    readonly thresholdTimeAmount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#threshold_time_unit ServiceEventRule#threshold_time_unit}
    */
    readonly thresholdTimeUnit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#threshold_value ServiceEventRule#threshold_value}
    */
    readonly thresholdValue?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#value ServiceEventRule#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function serviceEventRuleActionsSuppressToTerraform(struct?: ServiceEventRuleActionsSuppress | cdktn.IResolvable): any;
export declare function serviceEventRuleActionsSuppressToHclTerraform(struct?: ServiceEventRuleActionsSuppress | cdktn.IResolvable): any;
export declare class ServiceEventRuleActionsSuppressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceEventRuleActionsSuppress | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceEventRuleActionsSuppress | cdktn.IResolvable | undefined);
    private _thresholdTimeAmount?;
    get thresholdTimeAmount(): number;
    set thresholdTimeAmount(value: number);
    resetThresholdTimeAmount(): void;
    get thresholdTimeAmountInput(): number | undefined;
    private _thresholdTimeUnit?;
    get thresholdTimeUnit(): string;
    set thresholdTimeUnit(value: string);
    resetThresholdTimeUnit(): void;
    get thresholdTimeUnitInput(): string | undefined;
    private _thresholdValue?;
    get thresholdValue(): number;
    set thresholdValue(value: number);
    resetThresholdValue(): void;
    get thresholdValueInput(): number | undefined;
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ServiceEventRuleActionsSuppressList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceEventRuleActionsSuppress[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceEventRuleActionsSuppressOutputReference;
}
export interface ServiceEventRuleActionsSuspend {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#value ServiceEventRule#value}
    */
    readonly value?: number;
}
export declare function serviceEventRuleActionsSuspendToTerraform(struct?: ServiceEventRuleActionsSuspend | cdktn.IResolvable): any;
export declare function serviceEventRuleActionsSuspendToHclTerraform(struct?: ServiceEventRuleActionsSuspend | cdktn.IResolvable): any;
export declare class ServiceEventRuleActionsSuspendOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceEventRuleActionsSuspend | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceEventRuleActionsSuspend | cdktn.IResolvable | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export declare class ServiceEventRuleActionsSuspendList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceEventRuleActionsSuspend[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceEventRuleActionsSuspendOutputReference;
}
export interface ServiceEventRuleActions {
    /**
    * annotate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#annotate ServiceEventRule#annotate}
    */
    readonly annotate?: ServiceEventRuleActionsAnnotate[] | cdktn.IResolvable;
    /**
    * event_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#event_action ServiceEventRule#event_action}
    */
    readonly eventAction?: ServiceEventRuleActionsEventAction[] | cdktn.IResolvable;
    /**
    * extractions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#extractions ServiceEventRule#extractions}
    */
    readonly extractions?: ServiceEventRuleActionsExtractions[] | cdktn.IResolvable;
    /**
    * priority block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#priority ServiceEventRule#priority}
    */
    readonly priority?: ServiceEventRuleActionsPriority[] | cdktn.IResolvable;
    /**
    * severity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#severity ServiceEventRule#severity}
    */
    readonly severity?: ServiceEventRuleActionsSeverity[] | cdktn.IResolvable;
    /**
    * suppress block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#suppress ServiceEventRule#suppress}
    */
    readonly suppress?: ServiceEventRuleActionsSuppress[] | cdktn.IResolvable;
    /**
    * suspend block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#suspend ServiceEventRule#suspend}
    */
    readonly suspend?: ServiceEventRuleActionsSuspend[] | cdktn.IResolvable;
}
export declare function serviceEventRuleActionsToTerraform(struct?: ServiceEventRuleActionsOutputReference | ServiceEventRuleActions): any;
export declare function serviceEventRuleActionsToHclTerraform(struct?: ServiceEventRuleActionsOutputReference | ServiceEventRuleActions): any;
export declare class ServiceEventRuleActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceEventRuleActions | undefined;
    set internalValue(value: ServiceEventRuleActions | undefined);
    private _annotate;
    get annotate(): ServiceEventRuleActionsAnnotateList;
    putAnnotate(value: ServiceEventRuleActionsAnnotate[] | cdktn.IResolvable): void;
    resetAnnotate(): void;
    get annotateInput(): cdktn.IResolvable | ServiceEventRuleActionsAnnotate[] | undefined;
    private _eventAction;
    get eventAction(): ServiceEventRuleActionsEventActionList;
    putEventAction(value: ServiceEventRuleActionsEventAction[] | cdktn.IResolvable): void;
    resetEventAction(): void;
    get eventActionInput(): cdktn.IResolvable | ServiceEventRuleActionsEventAction[] | undefined;
    private _extractions;
    get extractions(): ServiceEventRuleActionsExtractionsList;
    putExtractions(value: ServiceEventRuleActionsExtractions[] | cdktn.IResolvable): void;
    resetExtractions(): void;
    get extractionsInput(): cdktn.IResolvable | ServiceEventRuleActionsExtractions[] | undefined;
    private _priority;
    get priority(): ServiceEventRuleActionsPriorityList;
    putPriority(value: ServiceEventRuleActionsPriority[] | cdktn.IResolvable): void;
    resetPriority(): void;
    get priorityInput(): cdktn.IResolvable | ServiceEventRuleActionsPriority[] | undefined;
    private _severity;
    get severity(): ServiceEventRuleActionsSeverityList;
    putSeverity(value: ServiceEventRuleActionsSeverity[] | cdktn.IResolvable): void;
    resetSeverity(): void;
    get severityInput(): cdktn.IResolvable | ServiceEventRuleActionsSeverity[] | undefined;
    private _suppress;
    get suppress(): ServiceEventRuleActionsSuppressList;
    putSuppress(value: ServiceEventRuleActionsSuppress[] | cdktn.IResolvable): void;
    resetSuppress(): void;
    get suppressInput(): cdktn.IResolvable | ServiceEventRuleActionsSuppress[] | undefined;
    private _suspend;
    get suspend(): ServiceEventRuleActionsSuspendList;
    putSuspend(value: ServiceEventRuleActionsSuspend[] | cdktn.IResolvable): void;
    resetSuspend(): void;
    get suspendInput(): cdktn.IResolvable | ServiceEventRuleActionsSuspend[] | undefined;
}
export interface ServiceEventRuleConditionsSubconditionsParameter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#path ServiceEventRule#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#value ServiceEventRule#value}
    */
    readonly value?: string;
}
export declare function serviceEventRuleConditionsSubconditionsParameterToTerraform(struct?: ServiceEventRuleConditionsSubconditionsParameter | cdktn.IResolvable): any;
export declare function serviceEventRuleConditionsSubconditionsParameterToHclTerraform(struct?: ServiceEventRuleConditionsSubconditionsParameter | cdktn.IResolvable): any;
export declare class ServiceEventRuleConditionsSubconditionsParameterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceEventRuleConditionsSubconditionsParameter | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceEventRuleConditionsSubconditionsParameter | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ServiceEventRuleConditionsSubconditionsParameterList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceEventRuleConditionsSubconditionsParameter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceEventRuleConditionsSubconditionsParameterOutputReference;
}
export interface ServiceEventRuleConditionsSubconditions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#operator ServiceEventRule#operator}
    */
    readonly operator?: string;
    /**
    * parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#parameter ServiceEventRule#parameter}
    */
    readonly parameter?: ServiceEventRuleConditionsSubconditionsParameter[] | cdktn.IResolvable;
}
export declare function serviceEventRuleConditionsSubconditionsToTerraform(struct?: ServiceEventRuleConditionsSubconditions | cdktn.IResolvable): any;
export declare function serviceEventRuleConditionsSubconditionsToHclTerraform(struct?: ServiceEventRuleConditionsSubconditions | cdktn.IResolvable): any;
export declare class ServiceEventRuleConditionsSubconditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceEventRuleConditionsSubconditions | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceEventRuleConditionsSubconditions | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _parameter;
    get parameter(): ServiceEventRuleConditionsSubconditionsParameterList;
    putParameter(value: ServiceEventRuleConditionsSubconditionsParameter[] | cdktn.IResolvable): void;
    resetParameter(): void;
    get parameterInput(): cdktn.IResolvable | ServiceEventRuleConditionsSubconditionsParameter[] | undefined;
}
export declare class ServiceEventRuleConditionsSubconditionsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceEventRuleConditionsSubconditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceEventRuleConditionsSubconditionsOutputReference;
}
export interface ServiceEventRuleConditions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#operator ServiceEventRule#operator}
    */
    readonly operator?: string;
    /**
    * subconditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#subconditions ServiceEventRule#subconditions}
    */
    readonly subconditions?: ServiceEventRuleConditionsSubconditions[] | cdktn.IResolvable;
}
export declare function serviceEventRuleConditionsToTerraform(struct?: ServiceEventRuleConditionsOutputReference | ServiceEventRuleConditions): any;
export declare function serviceEventRuleConditionsToHclTerraform(struct?: ServiceEventRuleConditionsOutputReference | ServiceEventRuleConditions): any;
export declare class ServiceEventRuleConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceEventRuleConditions | undefined;
    set internalValue(value: ServiceEventRuleConditions | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _subconditions;
    get subconditions(): ServiceEventRuleConditionsSubconditionsList;
    putSubconditions(value: ServiceEventRuleConditionsSubconditions[] | cdktn.IResolvable): void;
    resetSubconditions(): void;
    get subconditionsInput(): cdktn.IResolvable | ServiceEventRuleConditionsSubconditions[] | undefined;
}
export interface ServiceEventRuleTimeFrameActiveBetween {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#end_time ServiceEventRule#end_time}
    */
    readonly endTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#start_time ServiceEventRule#start_time}
    */
    readonly startTime?: number;
}
export declare function serviceEventRuleTimeFrameActiveBetweenToTerraform(struct?: ServiceEventRuleTimeFrameActiveBetween | cdktn.IResolvable): any;
export declare function serviceEventRuleTimeFrameActiveBetweenToHclTerraform(struct?: ServiceEventRuleTimeFrameActiveBetween | cdktn.IResolvable): any;
export declare class ServiceEventRuleTimeFrameActiveBetweenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceEventRuleTimeFrameActiveBetween | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceEventRuleTimeFrameActiveBetween | cdktn.IResolvable | undefined);
    private _endTime?;
    get endTime(): number;
    set endTime(value: number);
    resetEndTime(): void;
    get endTimeInput(): number | undefined;
    private _startTime?;
    get startTime(): number;
    set startTime(value: number);
    resetStartTime(): void;
    get startTimeInput(): number | undefined;
}
export declare class ServiceEventRuleTimeFrameActiveBetweenList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceEventRuleTimeFrameActiveBetween[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceEventRuleTimeFrameActiveBetweenOutputReference;
}
export interface ServiceEventRuleTimeFrameScheduledWeekly {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#duration ServiceEventRule#duration}
    */
    readonly duration?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#start_time ServiceEventRule#start_time}
    */
    readonly startTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#timezone ServiceEventRule#timezone}
    */
    readonly timezone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#weekdays ServiceEventRule#weekdays}
    */
    readonly weekdays?: number[];
}
export declare function serviceEventRuleTimeFrameScheduledWeeklyToTerraform(struct?: ServiceEventRuleTimeFrameScheduledWeekly | cdktn.IResolvable): any;
export declare function serviceEventRuleTimeFrameScheduledWeeklyToHclTerraform(struct?: ServiceEventRuleTimeFrameScheduledWeekly | cdktn.IResolvable): any;
export declare class ServiceEventRuleTimeFrameScheduledWeeklyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceEventRuleTimeFrameScheduledWeekly | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceEventRuleTimeFrameScheduledWeekly | cdktn.IResolvable | undefined);
    private _duration?;
    get duration(): number;
    set duration(value: number);
    resetDuration(): void;
    get durationInput(): number | undefined;
    private _startTime?;
    get startTime(): number;
    set startTime(value: number);
    resetStartTime(): void;
    get startTimeInput(): number | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
    private _weekdays?;
    get weekdays(): number[];
    set weekdays(value: number[]);
    resetWeekdays(): void;
    get weekdaysInput(): number[] | undefined;
}
export declare class ServiceEventRuleTimeFrameScheduledWeeklyList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceEventRuleTimeFrameScheduledWeekly[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceEventRuleTimeFrameScheduledWeeklyOutputReference;
}
export interface ServiceEventRuleTimeFrame {
    /**
    * active_between block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#active_between ServiceEventRule#active_between}
    */
    readonly activeBetween?: ServiceEventRuleTimeFrameActiveBetween[] | cdktn.IResolvable;
    /**
    * scheduled_weekly block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#scheduled_weekly ServiceEventRule#scheduled_weekly}
    */
    readonly scheduledWeekly?: ServiceEventRuleTimeFrameScheduledWeekly[] | cdktn.IResolvable;
}
export declare function serviceEventRuleTimeFrameToTerraform(struct?: ServiceEventRuleTimeFrameOutputReference | ServiceEventRuleTimeFrame): any;
export declare function serviceEventRuleTimeFrameToHclTerraform(struct?: ServiceEventRuleTimeFrameOutputReference | ServiceEventRuleTimeFrame): any;
export declare class ServiceEventRuleTimeFrameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceEventRuleTimeFrame | undefined;
    set internalValue(value: ServiceEventRuleTimeFrame | undefined);
    private _activeBetween;
    get activeBetween(): ServiceEventRuleTimeFrameActiveBetweenList;
    putActiveBetween(value: ServiceEventRuleTimeFrameActiveBetween[] | cdktn.IResolvable): void;
    resetActiveBetween(): void;
    get activeBetweenInput(): cdktn.IResolvable | ServiceEventRuleTimeFrameActiveBetween[] | undefined;
    private _scheduledWeekly;
    get scheduledWeekly(): ServiceEventRuleTimeFrameScheduledWeeklyList;
    putScheduledWeekly(value: ServiceEventRuleTimeFrameScheduledWeekly[] | cdktn.IResolvable): void;
    resetScheduledWeekly(): void;
    get scheduledWeeklyInput(): cdktn.IResolvable | ServiceEventRuleTimeFrameScheduledWeekly[] | undefined;
}
export interface ServiceEventRuleVariableParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#path ServiceEventRule#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#value ServiceEventRule#value}
    */
    readonly value?: string;
}
export declare function serviceEventRuleVariableParametersToTerraform(struct?: ServiceEventRuleVariableParameters | cdktn.IResolvable): any;
export declare function serviceEventRuleVariableParametersToHclTerraform(struct?: ServiceEventRuleVariableParameters | cdktn.IResolvable): any;
export declare class ServiceEventRuleVariableParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceEventRuleVariableParameters | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceEventRuleVariableParameters | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ServiceEventRuleVariableParametersList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceEventRuleVariableParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceEventRuleVariableParametersOutputReference;
}
export interface ServiceEventRuleVariable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#name ServiceEventRule#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#type ServiceEventRule#type}
    */
    readonly type?: string;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#parameters ServiceEventRule#parameters}
    */
    readonly parameters?: ServiceEventRuleVariableParameters[] | cdktn.IResolvable;
}
export declare function serviceEventRuleVariableToTerraform(struct?: ServiceEventRuleVariable | cdktn.IResolvable): any;
export declare function serviceEventRuleVariableToHclTerraform(struct?: ServiceEventRuleVariable | cdktn.IResolvable): any;
export declare class ServiceEventRuleVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceEventRuleVariable | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceEventRuleVariable | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _parameters;
    get parameters(): ServiceEventRuleVariableParametersList;
    putParameters(value: ServiceEventRuleVariableParameters[] | cdktn.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | ServiceEventRuleVariableParameters[] | undefined;
}
export declare class ServiceEventRuleVariableList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceEventRuleVariable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceEventRuleVariableOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule pagerduty_service_event_rule}
*/
export declare class ServiceEventRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_service_event_rule";
    /**
    * Generates CDKTN code for importing a ServiceEventRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServiceEventRule to import
    * @param importFromId The id of the existing ServiceEventRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServiceEventRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.4/docs/resources/service_event_rule pagerduty_service_event_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServiceEventRuleConfig
    */
    constructor(scope: Construct, id: string, config: ServiceEventRuleConfig);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _position?;
    get position(): number;
    set position(value: number);
    resetPosition(): void;
    get positionInput(): number | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _actions;
    get actions(): ServiceEventRuleActionsOutputReference;
    putActions(value: ServiceEventRuleActions): void;
    resetActions(): void;
    get actionsInput(): ServiceEventRuleActions | undefined;
    private _conditions;
    get conditions(): ServiceEventRuleConditionsOutputReference;
    putConditions(value: ServiceEventRuleConditions): void;
    resetConditions(): void;
    get conditionsInput(): ServiceEventRuleConditions | undefined;
    private _timeFrame;
    get timeFrame(): ServiceEventRuleTimeFrameOutputReference;
    putTimeFrame(value: ServiceEventRuleTimeFrame): void;
    resetTimeFrame(): void;
    get timeFrameInput(): ServiceEventRuleTimeFrame | undefined;
    private _variable;
    get variable(): ServiceEventRuleVariableList;
    putVariable(value: ServiceEventRuleVariable[] | cdktn.IResolvable): void;
    resetVariable(): void;
    get variableInput(): cdktn.IResolvable | ServiceEventRuleVariable[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
