/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EscalationPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/escalation_policy#description EscalationPolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/escalation_policy#id EscalationPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/escalation_policy#name EscalationPolicy#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/escalation_policy#num_loops EscalationPolicy#num_loops}
    */
    readonly numLoops?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/escalation_policy#teams EscalationPolicy#teams}
    */
    readonly teams?: string[];
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/escalation_policy#rule EscalationPolicy#rule}
    */
    readonly rule: EscalationPolicyRule[] | cdktn.IResolvable;
}
export interface EscalationPolicyRuleEscalationRuleAssignmentStrategy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/escalation_policy#type EscalationPolicy#type}
    */
    readonly type?: string;
}
export declare function escalationPolicyRuleEscalationRuleAssignmentStrategyToTerraform(struct?: EscalationPolicyRuleEscalationRuleAssignmentStrategyOutputReference | EscalationPolicyRuleEscalationRuleAssignmentStrategy): any;
export declare function escalationPolicyRuleEscalationRuleAssignmentStrategyToHclTerraform(struct?: EscalationPolicyRuleEscalationRuleAssignmentStrategyOutputReference | EscalationPolicyRuleEscalationRuleAssignmentStrategy): any;
export declare class EscalationPolicyRuleEscalationRuleAssignmentStrategyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EscalationPolicyRuleEscalationRuleAssignmentStrategy | undefined;
    set internalValue(value: EscalationPolicyRuleEscalationRuleAssignmentStrategy | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface EscalationPolicyRuleTarget {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/escalation_policy#id EscalationPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/escalation_policy#type EscalationPolicy#type}
    */
    readonly type?: string;
}
export declare function escalationPolicyRuleTargetToTerraform(struct?: EscalationPolicyRuleTarget | cdktn.IResolvable): any;
export declare function escalationPolicyRuleTargetToHclTerraform(struct?: EscalationPolicyRuleTarget | cdktn.IResolvable): any;
export declare class EscalationPolicyRuleTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EscalationPolicyRuleTarget | cdktn.IResolvable | undefined;
    set internalValue(value: EscalationPolicyRuleTarget | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class EscalationPolicyRuleTargetList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EscalationPolicyRuleTarget[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EscalationPolicyRuleTargetOutputReference;
}
export interface EscalationPolicyRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/escalation_policy#escalation_delay_in_minutes EscalationPolicy#escalation_delay_in_minutes}
    */
    readonly escalationDelayInMinutes: number;
    /**
    * escalation_rule_assignment_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/escalation_policy#escalation_rule_assignment_strategy EscalationPolicy#escalation_rule_assignment_strategy}
    */
    readonly escalationRuleAssignmentStrategy?: EscalationPolicyRuleEscalationRuleAssignmentStrategy;
    /**
    * target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/escalation_policy#target EscalationPolicy#target}
    */
    readonly target: EscalationPolicyRuleTarget[] | cdktn.IResolvable;
}
export declare function escalationPolicyRuleToTerraform(struct?: EscalationPolicyRule | cdktn.IResolvable): any;
export declare function escalationPolicyRuleToHclTerraform(struct?: EscalationPolicyRule | cdktn.IResolvable): any;
export declare class EscalationPolicyRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EscalationPolicyRule | cdktn.IResolvable | undefined;
    set internalValue(value: EscalationPolicyRule | cdktn.IResolvable | undefined);
    private _escalationDelayInMinutes?;
    get escalationDelayInMinutes(): number;
    set escalationDelayInMinutes(value: number);
    get escalationDelayInMinutesInput(): number | undefined;
    get id(): string;
    private _escalationRuleAssignmentStrategy;
    get escalationRuleAssignmentStrategy(): EscalationPolicyRuleEscalationRuleAssignmentStrategyOutputReference;
    putEscalationRuleAssignmentStrategy(value: EscalationPolicyRuleEscalationRuleAssignmentStrategy): void;
    resetEscalationRuleAssignmentStrategy(): void;
    get escalationRuleAssignmentStrategyInput(): EscalationPolicyRuleEscalationRuleAssignmentStrategy | undefined;
    private _target;
    get target(): EscalationPolicyRuleTargetList;
    putTarget(value: EscalationPolicyRuleTarget[] | cdktn.IResolvable): void;
    get targetInput(): cdktn.IResolvable | EscalationPolicyRuleTarget[] | undefined;
}
export declare class EscalationPolicyRuleList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EscalationPolicyRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EscalationPolicyRuleOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/escalation_policy pagerduty_escalation_policy}
*/
export declare class EscalationPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_escalation_policy";
    /**
    * Generates CDKTN code for importing a EscalationPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EscalationPolicy to import
    * @param importFromId The id of the existing EscalationPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/escalation_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EscalationPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/escalation_policy pagerduty_escalation_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EscalationPolicyConfig
    */
    constructor(scope: Construct, id: string, config: EscalationPolicyConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _numLoops?;
    get numLoops(): number;
    set numLoops(value: number);
    resetNumLoops(): void;
    get numLoopsInput(): number | undefined;
    private _teams?;
    get teams(): string[];
    set teams(value: string[]);
    resetTeams(): void;
    get teamsInput(): string[] | undefined;
    private _rule;
    get rule(): EscalationPolicyRuleList;
    putRule(value: EscalationPolicyRule[] | cdktn.IResolvable): void;
    get ruleInput(): cdktn.IResolvable | EscalationPolicyRule[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
