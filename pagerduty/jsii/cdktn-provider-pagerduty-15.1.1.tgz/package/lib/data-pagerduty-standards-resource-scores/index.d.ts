/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPagerdutyStandardsResourceScoresConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/data-sources/standards_resource_scores#id DataPagerdutyStandardsResourceScores#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/data-sources/standards_resource_scores#resource_type DataPagerdutyStandardsResourceScores#resource_type}
    */
    readonly resourceType: string;
}
export interface DataPagerdutyStandardsResourceScoresScore {
}
export declare function dataPagerdutyStandardsResourceScoresScoreToTerraform(struct?: DataPagerdutyStandardsResourceScoresScore): any;
export declare function dataPagerdutyStandardsResourceScoresScoreToHclTerraform(struct?: DataPagerdutyStandardsResourceScoresScore): any;
export declare class DataPagerdutyStandardsResourceScoresScoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataPagerdutyStandardsResourceScoresScore | undefined;
    set internalValue(value: DataPagerdutyStandardsResourceScoresScore | undefined);
    get passing(): number;
    get total(): number;
}
export interface DataPagerdutyStandardsResourceScoresStandards {
}
export declare function dataPagerdutyStandardsResourceScoresStandardsToTerraform(struct?: DataPagerdutyStandardsResourceScoresStandards): any;
export declare function dataPagerdutyStandardsResourceScoresStandardsToHclTerraform(struct?: DataPagerdutyStandardsResourceScoresStandards): any;
export declare class DataPagerdutyStandardsResourceScoresStandardsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyStandardsResourceScoresStandards | undefined;
    set internalValue(value: DataPagerdutyStandardsResourceScoresStandards | undefined);
    get active(): cdktn.IResolvable;
    get description(): string;
    get id(): string;
    get name(): string;
    get pass(): cdktn.IResolvable;
    get type(): string;
}
export declare class DataPagerdutyStandardsResourceScoresStandardsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyStandardsResourceScoresStandardsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/data-sources/standards_resource_scores pagerduty_standards_resource_scores}
*/
export declare class DataPagerdutyStandardsResourceScores extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_standards_resource_scores";
    /**
    * Generates CDKTN code for importing a DataPagerdutyStandardsResourceScores resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyStandardsResourceScores to import
    * @param importFromId The id of the existing DataPagerdutyStandardsResourceScores that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/data-sources/standards_resource_scores#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyStandardsResourceScores to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/data-sources/standards_resource_scores pagerduty_standards_resource_scores} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyStandardsResourceScoresConfig
    */
    constructor(scope: Construct, id: string, config: DataPagerdutyStandardsResourceScoresConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    private _score;
    get score(): DataPagerdutyStandardsResourceScoresScoreOutputReference;
    private _standards;
    get standards(): DataPagerdutyStandardsResourceScoresStandardsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
