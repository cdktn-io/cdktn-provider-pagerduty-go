/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServiceCustomFieldValueConfig extends cdktn.TerraformMetaArguments {
    /**
    * The custom field values to set for the service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/service_custom_field_value#custom_fields ServiceCustomFieldValue#custom_fields}
    */
    readonly customFields: ServiceCustomFieldValueCustomFields[] | cdktn.IResolvable;
    /**
    * The ID of the service to set custom field values for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/service_custom_field_value#service_id ServiceCustomFieldValue#service_id}
    */
    readonly serviceId: string;
}
export interface ServiceCustomFieldValueCustomFields {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/service_custom_field_value#id ServiceCustomFieldValue#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/service_custom_field_value#name ServiceCustomFieldValue#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/service_custom_field_value#value ServiceCustomFieldValue#value}
    */
    readonly value: string;
}
export declare function serviceCustomFieldValueCustomFieldsToTerraform(struct?: ServiceCustomFieldValueCustomFields | cdktn.IResolvable): any;
export declare function serviceCustomFieldValueCustomFieldsToHclTerraform(struct?: ServiceCustomFieldValueCustomFields | cdktn.IResolvable): any;
export declare class ServiceCustomFieldValueCustomFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceCustomFieldValueCustomFields | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceCustomFieldValueCustomFields | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ServiceCustomFieldValueCustomFieldsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceCustomFieldValueCustomFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceCustomFieldValueCustomFieldsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/service_custom_field_value pagerduty_service_custom_field_value}
*/
export declare class ServiceCustomFieldValue extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_service_custom_field_value";
    /**
    * Generates CDKTN code for importing a ServiceCustomFieldValue resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServiceCustomFieldValue to import
    * @param importFromId The id of the existing ServiceCustomFieldValue that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/service_custom_field_value#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServiceCustomFieldValue to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/service_custom_field_value pagerduty_service_custom_field_value} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServiceCustomFieldValueConfig
    */
    constructor(scope: Construct, id: string, config: ServiceCustomFieldValueConfig);
    private _customFields;
    get customFields(): ServiceCustomFieldValueCustomFieldsList;
    putCustomFields(value: ServiceCustomFieldValueCustomFields[] | cdktn.IResolvable): void;
    get customFieldsInput(): cdktn.IResolvable | ServiceCustomFieldValueCustomFields[] | undefined;
    get id(): string;
    private _serviceId?;
    get serviceId(): string;
    set serviceId(value: string);
    get serviceIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
