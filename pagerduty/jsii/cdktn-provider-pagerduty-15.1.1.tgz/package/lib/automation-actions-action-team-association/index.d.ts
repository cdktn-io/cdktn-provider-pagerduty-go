/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AutomationActionsActionTeamAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/automation_actions_action_team_association#action_id AutomationActionsActionTeamAssociation#action_id}
    */
    readonly actionId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/automation_actions_action_team_association#id AutomationActionsActionTeamAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/automation_actions_action_team_association#team_id AutomationActionsActionTeamAssociation#team_id}
    */
    readonly teamId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/automation_actions_action_team_association pagerduty_automation_actions_action_team_association}
*/
export declare class AutomationActionsActionTeamAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_automation_actions_action_team_association";
    /**
    * Generates CDKTN code for importing a AutomationActionsActionTeamAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AutomationActionsActionTeamAssociation to import
    * @param importFromId The id of the existing AutomationActionsActionTeamAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/automation_actions_action_team_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AutomationActionsActionTeamAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/automation_actions_action_team_association pagerduty_automation_actions_action_team_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AutomationActionsActionTeamAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AutomationActionsActionTeamAssociationConfig);
    private _actionId?;
    get actionId(): string;
    set actionId(value: string);
    get actionIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
