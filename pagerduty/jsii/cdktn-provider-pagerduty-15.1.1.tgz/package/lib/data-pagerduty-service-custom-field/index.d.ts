/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPagerdutyServiceCustomFieldConfig extends cdktn.TerraformMetaArguments {
    /**
    * The human-readable name of the field. This must be unique across an account
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/data-sources/service_custom_field#display_name DataPagerdutyServiceCustomField#display_name}
    */
    readonly displayName: string;
}
export interface DataPagerdutyServiceCustomFieldFieldOptions {
}
export declare function dataPagerdutyServiceCustomFieldFieldOptionsToTerraform(struct?: DataPagerdutyServiceCustomFieldFieldOptions): any;
export declare function dataPagerdutyServiceCustomFieldFieldOptionsToHclTerraform(struct?: DataPagerdutyServiceCustomFieldFieldOptions): any;
export declare class DataPagerdutyServiceCustomFieldFieldOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyServiceCustomFieldFieldOptions | undefined;
    set internalValue(value: DataPagerdutyServiceCustomFieldFieldOptions | undefined);
    get dataType(): string;
    get id(): string;
    get value(): string;
}
export declare class DataPagerdutyServiceCustomFieldFieldOptionsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyServiceCustomFieldFieldOptionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/data-sources/service_custom_field pagerduty_service_custom_field}
*/
export declare class DataPagerdutyServiceCustomField extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_service_custom_field";
    /**
    * Generates CDKTN code for importing a DataPagerdutyServiceCustomField resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyServiceCustomField to import
    * @param importFromId The id of the existing DataPagerdutyServiceCustomField that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/data-sources/service_custom_field#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyServiceCustomField to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/data-sources/service_custom_field pagerduty_service_custom_field} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyServiceCustomFieldConfig
    */
    constructor(scope: Construct, id: string, config: DataPagerdutyServiceCustomFieldConfig);
    get dataType(): string;
    get defaultValue(): string;
    get description(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get enabled(): cdktn.IResolvable;
    private _fieldOptions;
    get fieldOptions(): DataPagerdutyServiceCustomFieldFieldOptionsList;
    get fieldType(): string;
    get id(): string;
    get name(): string;
    get selfAttribute(): string;
    get summary(): string;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
