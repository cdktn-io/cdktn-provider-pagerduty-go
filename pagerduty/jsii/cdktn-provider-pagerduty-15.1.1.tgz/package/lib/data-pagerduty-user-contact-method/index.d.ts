/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPagerdutyUserContactMethodConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/data-sources/user_contact_method#id DataPagerdutyUserContactMethod#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the contact method to find in the PagerDuty API
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/data-sources/user_contact_method#label DataPagerdutyUserContactMethod#label}
    */
    readonly label: string;
    /**
    * The type of the contact method
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/data-sources/user_contact_method#type DataPagerdutyUserContactMethod#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/data-sources/user_contact_method#user_id DataPagerdutyUserContactMethod#user_id}
    */
    readonly userId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/data-sources/user_contact_method pagerduty_user_contact_method}
*/
export declare class DataPagerdutyUserContactMethod extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_user_contact_method";
    /**
    * Generates CDKTN code for importing a DataPagerdutyUserContactMethod resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyUserContactMethod to import
    * @param importFromId The id of the existing DataPagerdutyUserContactMethod that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/data-sources/user_contact_method#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyUserContactMethod to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/data-sources/user_contact_method pagerduty_user_contact_method} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyUserContactMethodConfig
    */
    constructor(scope: Construct, id: string, config: DataPagerdutyUserContactMethodConfig);
    get address(): string;
    get blacklisted(): cdktn.IResolvable;
    get countryCode(): number;
    get deviceType(): string;
    get enabled(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    get sendShortEmail(): cdktn.IResolvable;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
