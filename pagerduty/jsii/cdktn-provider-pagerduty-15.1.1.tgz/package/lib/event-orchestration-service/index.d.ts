/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EventOrchestrationServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#enable_event_orchestration_for_service EventOrchestrationService#enable_event_orchestration_for_service}
    */
    readonly enableEventOrchestrationForService?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#id EventOrchestrationService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#service EventOrchestrationService#service}
    */
    readonly service: string;
    /**
    * catch_all block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#catch_all EventOrchestrationService#catch_all}
    */
    readonly catchAll: EventOrchestrationServiceCatchAll;
    /**
    * set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#set EventOrchestrationService#set}
    */
    readonly set: EventOrchestrationServiceSet[] | cdktn.IResolvable;
}
export interface EventOrchestrationServiceCatchAllActionsAutomationActionHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#key EventOrchestrationService#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#value EventOrchestrationService#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationServiceCatchAllActionsAutomationActionHeaderToTerraform(struct?: EventOrchestrationServiceCatchAllActionsAutomationActionHeader | cdktn.IResolvable): any;
export declare function eventOrchestrationServiceCatchAllActionsAutomationActionHeaderToHclTerraform(struct?: EventOrchestrationServiceCatchAllActionsAutomationActionHeader | cdktn.IResolvable): any;
export declare class EventOrchestrationServiceCatchAllActionsAutomationActionHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationServiceCatchAllActionsAutomationActionHeader | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationServiceCatchAllActionsAutomationActionHeader | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationServiceCatchAllActionsAutomationActionHeaderList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationServiceCatchAllActionsAutomationActionHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationServiceCatchAllActionsAutomationActionHeaderOutputReference;
}
export interface EventOrchestrationServiceCatchAllActionsAutomationActionParameter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#key EventOrchestrationService#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#value EventOrchestrationService#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationServiceCatchAllActionsAutomationActionParameterToTerraform(struct?: EventOrchestrationServiceCatchAllActionsAutomationActionParameter | cdktn.IResolvable): any;
export declare function eventOrchestrationServiceCatchAllActionsAutomationActionParameterToHclTerraform(struct?: EventOrchestrationServiceCatchAllActionsAutomationActionParameter | cdktn.IResolvable): any;
export declare class EventOrchestrationServiceCatchAllActionsAutomationActionParameterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationServiceCatchAllActionsAutomationActionParameter | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationServiceCatchAllActionsAutomationActionParameter | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationServiceCatchAllActionsAutomationActionParameterList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationServiceCatchAllActionsAutomationActionParameter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationServiceCatchAllActionsAutomationActionParameterOutputReference;
}
export interface EventOrchestrationServiceCatchAllActionsAutomationAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#auto_send EventOrchestrationService#auto_send}
    */
    readonly autoSend?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#name EventOrchestrationService#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#trigger_types EventOrchestrationService#trigger_types}
    */
    readonly triggerTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#url EventOrchestrationService#url}
    */
    readonly url: string;
    /**
    * header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#header EventOrchestrationService#header}
    */
    readonly header?: EventOrchestrationServiceCatchAllActionsAutomationActionHeader[] | cdktn.IResolvable;
    /**
    * parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#parameter EventOrchestrationService#parameter}
    */
    readonly parameter?: EventOrchestrationServiceCatchAllActionsAutomationActionParameter[] | cdktn.IResolvable;
}
export declare function eventOrchestrationServiceCatchAllActionsAutomationActionToTerraform(struct?: EventOrchestrationServiceCatchAllActionsAutomationActionOutputReference | EventOrchestrationServiceCatchAllActionsAutomationAction): any;
export declare function eventOrchestrationServiceCatchAllActionsAutomationActionToHclTerraform(struct?: EventOrchestrationServiceCatchAllActionsAutomationActionOutputReference | EventOrchestrationServiceCatchAllActionsAutomationAction): any;
export declare class EventOrchestrationServiceCatchAllActionsAutomationActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationServiceCatchAllActionsAutomationAction | undefined;
    set internalValue(value: EventOrchestrationServiceCatchAllActionsAutomationAction | undefined);
    private _autoSend?;
    get autoSend(): boolean | cdktn.IResolvable;
    set autoSend(value: boolean | cdktn.IResolvable);
    resetAutoSend(): void;
    get autoSendInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _triggerTypes?;
    get triggerTypes(): string[];
    set triggerTypes(value: string[]);
    resetTriggerTypes(): void;
    get triggerTypesInput(): string[] | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _header;
    get header(): EventOrchestrationServiceCatchAllActionsAutomationActionHeaderList;
    putHeader(value: EventOrchestrationServiceCatchAllActionsAutomationActionHeader[] | cdktn.IResolvable): void;
    resetHeader(): void;
    get headerInput(): cdktn.IResolvable | EventOrchestrationServiceCatchAllActionsAutomationActionHeader[] | undefined;
    private _parameter;
    get parameter(): EventOrchestrationServiceCatchAllActionsAutomationActionParameterList;
    putParameter(value: EventOrchestrationServiceCatchAllActionsAutomationActionParameter[] | cdktn.IResolvable): void;
    resetParameter(): void;
    get parameterInput(): cdktn.IResolvable | EventOrchestrationServiceCatchAllActionsAutomationActionParameter[] | undefined;
}
export interface EventOrchestrationServiceCatchAllActionsExtraction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#regex EventOrchestrationService#regex}
    */
    readonly regex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#source EventOrchestrationService#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#target EventOrchestrationService#target}
    */
    readonly target: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#template EventOrchestrationService#template}
    */
    readonly template?: string;
}
export declare function eventOrchestrationServiceCatchAllActionsExtractionToTerraform(struct?: EventOrchestrationServiceCatchAllActionsExtraction | cdktn.IResolvable): any;
export declare function eventOrchestrationServiceCatchAllActionsExtractionToHclTerraform(struct?: EventOrchestrationServiceCatchAllActionsExtraction | cdktn.IResolvable): any;
export declare class EventOrchestrationServiceCatchAllActionsExtractionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationServiceCatchAllActionsExtraction | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationServiceCatchAllActionsExtraction | cdktn.IResolvable | undefined);
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    resetTemplate(): void;
    get templateInput(): string | undefined;
}
export declare class EventOrchestrationServiceCatchAllActionsExtractionList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationServiceCatchAllActionsExtraction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationServiceCatchAllActionsExtractionOutputReference;
}
export interface EventOrchestrationServiceCatchAllActionsIncidentCustomFieldUpdate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#id EventOrchestrationService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#value EventOrchestrationService#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationServiceCatchAllActionsIncidentCustomFieldUpdateToTerraform(struct?: EventOrchestrationServiceCatchAllActionsIncidentCustomFieldUpdate | cdktn.IResolvable): any;
export declare function eventOrchestrationServiceCatchAllActionsIncidentCustomFieldUpdateToHclTerraform(struct?: EventOrchestrationServiceCatchAllActionsIncidentCustomFieldUpdate | cdktn.IResolvable): any;
export declare class EventOrchestrationServiceCatchAllActionsIncidentCustomFieldUpdateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationServiceCatchAllActionsIncidentCustomFieldUpdate | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationServiceCatchAllActionsIncidentCustomFieldUpdate | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationServiceCatchAllActionsIncidentCustomFieldUpdateList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationServiceCatchAllActionsIncidentCustomFieldUpdate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationServiceCatchAllActionsIncidentCustomFieldUpdateOutputReference;
}
export interface EventOrchestrationServiceCatchAllActionsPagerdutyAutomationAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#action_id EventOrchestrationService#action_id}
    */
    readonly actionId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#trigger_types EventOrchestrationService#trigger_types}
    */
    readonly triggerTypes?: string[];
}
export declare function eventOrchestrationServiceCatchAllActionsPagerdutyAutomationActionToTerraform(struct?: EventOrchestrationServiceCatchAllActionsPagerdutyAutomationActionOutputReference | EventOrchestrationServiceCatchAllActionsPagerdutyAutomationAction): any;
export declare function eventOrchestrationServiceCatchAllActionsPagerdutyAutomationActionToHclTerraform(struct?: EventOrchestrationServiceCatchAllActionsPagerdutyAutomationActionOutputReference | EventOrchestrationServiceCatchAllActionsPagerdutyAutomationAction): any;
export declare class EventOrchestrationServiceCatchAllActionsPagerdutyAutomationActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationServiceCatchAllActionsPagerdutyAutomationAction | undefined;
    set internalValue(value: EventOrchestrationServiceCatchAllActionsPagerdutyAutomationAction | undefined);
    private _actionId?;
    get actionId(): string;
    set actionId(value: string);
    get actionIdInput(): string | undefined;
    private _triggerTypes?;
    get triggerTypes(): string[];
    set triggerTypes(value: string[]);
    resetTriggerTypes(): void;
    get triggerTypesInput(): string[] | undefined;
}
export interface EventOrchestrationServiceCatchAllActionsVariable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#name EventOrchestrationService#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#path EventOrchestrationService#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#type EventOrchestrationService#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#value EventOrchestrationService#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationServiceCatchAllActionsVariableToTerraform(struct?: EventOrchestrationServiceCatchAllActionsVariable | cdktn.IResolvable): any;
export declare function eventOrchestrationServiceCatchAllActionsVariableToHclTerraform(struct?: EventOrchestrationServiceCatchAllActionsVariable | cdktn.IResolvable): any;
export declare class EventOrchestrationServiceCatchAllActionsVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationServiceCatchAllActionsVariable | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationServiceCatchAllActionsVariable | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationServiceCatchAllActionsVariableList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationServiceCatchAllActionsVariable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationServiceCatchAllActionsVariableOutputReference;
}
export interface EventOrchestrationServiceCatchAllActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#annotate EventOrchestrationService#annotate}
    */
    readonly annotate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#escalation_policy EventOrchestrationService#escalation_policy}
    */
    readonly escalationPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#event_action EventOrchestrationService#event_action}
    */
    readonly eventAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#priority EventOrchestrationService#priority}
    */
    readonly priority?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#route_to EventOrchestrationService#route_to}
    */
    readonly routeTo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#severity EventOrchestrationService#severity}
    */
    readonly severity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#suppress EventOrchestrationService#suppress}
    */
    readonly suppress?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#suspend EventOrchestrationService#suspend}
    */
    readonly suspend?: number;
    /**
    * automation_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#automation_action EventOrchestrationService#automation_action}
    */
    readonly automationAction?: EventOrchestrationServiceCatchAllActionsAutomationAction;
    /**
    * extraction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#extraction EventOrchestrationService#extraction}
    */
    readonly extraction?: EventOrchestrationServiceCatchAllActionsExtraction[] | cdktn.IResolvable;
    /**
    * incident_custom_field_update block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#incident_custom_field_update EventOrchestrationService#incident_custom_field_update}
    */
    readonly incidentCustomFieldUpdate?: EventOrchestrationServiceCatchAllActionsIncidentCustomFieldUpdate[] | cdktn.IResolvable;
    /**
    * pagerduty_automation_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#pagerduty_automation_action EventOrchestrationService#pagerduty_automation_action}
    */
    readonly pagerdutyAutomationAction?: EventOrchestrationServiceCatchAllActionsPagerdutyAutomationAction;
    /**
    * variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#variable EventOrchestrationService#variable}
    */
    readonly variable?: EventOrchestrationServiceCatchAllActionsVariable[] | cdktn.IResolvable;
}
export declare function eventOrchestrationServiceCatchAllActionsToTerraform(struct?: EventOrchestrationServiceCatchAllActionsOutputReference | EventOrchestrationServiceCatchAllActions): any;
export declare function eventOrchestrationServiceCatchAllActionsToHclTerraform(struct?: EventOrchestrationServiceCatchAllActionsOutputReference | EventOrchestrationServiceCatchAllActions): any;
export declare class EventOrchestrationServiceCatchAllActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationServiceCatchAllActions | undefined;
    set internalValue(value: EventOrchestrationServiceCatchAllActions | undefined);
    private _annotate?;
    get annotate(): string;
    set annotate(value: string);
    resetAnnotate(): void;
    get annotateInput(): string | undefined;
    private _escalationPolicy?;
    get escalationPolicy(): string;
    set escalationPolicy(value: string);
    resetEscalationPolicy(): void;
    get escalationPolicyInput(): string | undefined;
    private _eventAction?;
    get eventAction(): string;
    set eventAction(value: string);
    resetEventAction(): void;
    get eventActionInput(): string | undefined;
    private _priority?;
    get priority(): string;
    set priority(value: string);
    resetPriority(): void;
    get priorityInput(): string | undefined;
    private _routeTo?;
    get routeTo(): string;
    set routeTo(value: string);
    resetRouteTo(): void;
    get routeToInput(): string | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    resetSeverity(): void;
    get severityInput(): string | undefined;
    private _suppress?;
    get suppress(): boolean | cdktn.IResolvable;
    set suppress(value: boolean | cdktn.IResolvable);
    resetSuppress(): void;
    get suppressInput(): boolean | cdktn.IResolvable | undefined;
    private _suspend?;
    get suspend(): number;
    set suspend(value: number);
    resetSuspend(): void;
    get suspendInput(): number | undefined;
    private _automationAction;
    get automationAction(): EventOrchestrationServiceCatchAllActionsAutomationActionOutputReference;
    putAutomationAction(value: EventOrchestrationServiceCatchAllActionsAutomationAction): void;
    resetAutomationAction(): void;
    get automationActionInput(): EventOrchestrationServiceCatchAllActionsAutomationAction | undefined;
    private _extraction;
    get extraction(): EventOrchestrationServiceCatchAllActionsExtractionList;
    putExtraction(value: EventOrchestrationServiceCatchAllActionsExtraction[] | cdktn.IResolvable): void;
    resetExtraction(): void;
    get extractionInput(): cdktn.IResolvable | EventOrchestrationServiceCatchAllActionsExtraction[] | undefined;
    private _incidentCustomFieldUpdate;
    get incidentCustomFieldUpdate(): EventOrchestrationServiceCatchAllActionsIncidentCustomFieldUpdateList;
    putIncidentCustomFieldUpdate(value: EventOrchestrationServiceCatchAllActionsIncidentCustomFieldUpdate[] | cdktn.IResolvable): void;
    resetIncidentCustomFieldUpdate(): void;
    get incidentCustomFieldUpdateInput(): cdktn.IResolvable | EventOrchestrationServiceCatchAllActionsIncidentCustomFieldUpdate[] | undefined;
    private _pagerdutyAutomationAction;
    get pagerdutyAutomationAction(): EventOrchestrationServiceCatchAllActionsPagerdutyAutomationActionOutputReference;
    putPagerdutyAutomationAction(value: EventOrchestrationServiceCatchAllActionsPagerdutyAutomationAction): void;
    resetPagerdutyAutomationAction(): void;
    get pagerdutyAutomationActionInput(): EventOrchestrationServiceCatchAllActionsPagerdutyAutomationAction | undefined;
    private _variable;
    get variable(): EventOrchestrationServiceCatchAllActionsVariableList;
    putVariable(value: EventOrchestrationServiceCatchAllActionsVariable[] | cdktn.IResolvable): void;
    resetVariable(): void;
    get variableInput(): cdktn.IResolvable | EventOrchestrationServiceCatchAllActionsVariable[] | undefined;
}
export interface EventOrchestrationServiceCatchAll {
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#actions EventOrchestrationService#actions}
    */
    readonly actions: EventOrchestrationServiceCatchAllActions;
}
export declare function eventOrchestrationServiceCatchAllToTerraform(struct?: EventOrchestrationServiceCatchAllOutputReference | EventOrchestrationServiceCatchAll): any;
export declare function eventOrchestrationServiceCatchAllToHclTerraform(struct?: EventOrchestrationServiceCatchAllOutputReference | EventOrchestrationServiceCatchAll): any;
export declare class EventOrchestrationServiceCatchAllOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationServiceCatchAll | undefined;
    set internalValue(value: EventOrchestrationServiceCatchAll | undefined);
    private _actions;
    get actions(): EventOrchestrationServiceCatchAllActionsOutputReference;
    putActions(value: EventOrchestrationServiceCatchAllActions): void;
    get actionsInput(): EventOrchestrationServiceCatchAllActions | undefined;
}
export interface EventOrchestrationServiceSetRuleActionsAutomationActionHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#key EventOrchestrationService#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#value EventOrchestrationService#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationServiceSetRuleActionsAutomationActionHeaderToTerraform(struct?: EventOrchestrationServiceSetRuleActionsAutomationActionHeader | cdktn.IResolvable): any;
export declare function eventOrchestrationServiceSetRuleActionsAutomationActionHeaderToHclTerraform(struct?: EventOrchestrationServiceSetRuleActionsAutomationActionHeader | cdktn.IResolvable): any;
export declare class EventOrchestrationServiceSetRuleActionsAutomationActionHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationServiceSetRuleActionsAutomationActionHeader | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationServiceSetRuleActionsAutomationActionHeader | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationServiceSetRuleActionsAutomationActionHeaderList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationServiceSetRuleActionsAutomationActionHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationServiceSetRuleActionsAutomationActionHeaderOutputReference;
}
export interface EventOrchestrationServiceSetRuleActionsAutomationActionParameter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#key EventOrchestrationService#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#value EventOrchestrationService#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationServiceSetRuleActionsAutomationActionParameterToTerraform(struct?: EventOrchestrationServiceSetRuleActionsAutomationActionParameter | cdktn.IResolvable): any;
export declare function eventOrchestrationServiceSetRuleActionsAutomationActionParameterToHclTerraform(struct?: EventOrchestrationServiceSetRuleActionsAutomationActionParameter | cdktn.IResolvable): any;
export declare class EventOrchestrationServiceSetRuleActionsAutomationActionParameterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationServiceSetRuleActionsAutomationActionParameter | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationServiceSetRuleActionsAutomationActionParameter | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationServiceSetRuleActionsAutomationActionParameterList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationServiceSetRuleActionsAutomationActionParameter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationServiceSetRuleActionsAutomationActionParameterOutputReference;
}
export interface EventOrchestrationServiceSetRuleActionsAutomationAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#auto_send EventOrchestrationService#auto_send}
    */
    readonly autoSend?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#name EventOrchestrationService#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#trigger_types EventOrchestrationService#trigger_types}
    */
    readonly triggerTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#url EventOrchestrationService#url}
    */
    readonly url: string;
    /**
    * header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#header EventOrchestrationService#header}
    */
    readonly header?: EventOrchestrationServiceSetRuleActionsAutomationActionHeader[] | cdktn.IResolvable;
    /**
    * parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#parameter EventOrchestrationService#parameter}
    */
    readonly parameter?: EventOrchestrationServiceSetRuleActionsAutomationActionParameter[] | cdktn.IResolvable;
}
export declare function eventOrchestrationServiceSetRuleActionsAutomationActionToTerraform(struct?: EventOrchestrationServiceSetRuleActionsAutomationActionOutputReference | EventOrchestrationServiceSetRuleActionsAutomationAction): any;
export declare function eventOrchestrationServiceSetRuleActionsAutomationActionToHclTerraform(struct?: EventOrchestrationServiceSetRuleActionsAutomationActionOutputReference | EventOrchestrationServiceSetRuleActionsAutomationAction): any;
export declare class EventOrchestrationServiceSetRuleActionsAutomationActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationServiceSetRuleActionsAutomationAction | undefined;
    set internalValue(value: EventOrchestrationServiceSetRuleActionsAutomationAction | undefined);
    private _autoSend?;
    get autoSend(): boolean | cdktn.IResolvable;
    set autoSend(value: boolean | cdktn.IResolvable);
    resetAutoSend(): void;
    get autoSendInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _triggerTypes?;
    get triggerTypes(): string[];
    set triggerTypes(value: string[]);
    resetTriggerTypes(): void;
    get triggerTypesInput(): string[] | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _header;
    get header(): EventOrchestrationServiceSetRuleActionsAutomationActionHeaderList;
    putHeader(value: EventOrchestrationServiceSetRuleActionsAutomationActionHeader[] | cdktn.IResolvable): void;
    resetHeader(): void;
    get headerInput(): cdktn.IResolvable | EventOrchestrationServiceSetRuleActionsAutomationActionHeader[] | undefined;
    private _parameter;
    get parameter(): EventOrchestrationServiceSetRuleActionsAutomationActionParameterList;
    putParameter(value: EventOrchestrationServiceSetRuleActionsAutomationActionParameter[] | cdktn.IResolvable): void;
    resetParameter(): void;
    get parameterInput(): cdktn.IResolvable | EventOrchestrationServiceSetRuleActionsAutomationActionParameter[] | undefined;
}
export interface EventOrchestrationServiceSetRuleActionsExtraction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#regex EventOrchestrationService#regex}
    */
    readonly regex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#source EventOrchestrationService#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#target EventOrchestrationService#target}
    */
    readonly target: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#template EventOrchestrationService#template}
    */
    readonly template?: string;
}
export declare function eventOrchestrationServiceSetRuleActionsExtractionToTerraform(struct?: EventOrchestrationServiceSetRuleActionsExtraction | cdktn.IResolvable): any;
export declare function eventOrchestrationServiceSetRuleActionsExtractionToHclTerraform(struct?: EventOrchestrationServiceSetRuleActionsExtraction | cdktn.IResolvable): any;
export declare class EventOrchestrationServiceSetRuleActionsExtractionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationServiceSetRuleActionsExtraction | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationServiceSetRuleActionsExtraction | cdktn.IResolvable | undefined);
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    resetTemplate(): void;
    get templateInput(): string | undefined;
}
export declare class EventOrchestrationServiceSetRuleActionsExtractionList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationServiceSetRuleActionsExtraction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationServiceSetRuleActionsExtractionOutputReference;
}
export interface EventOrchestrationServiceSetRuleActionsIncidentCustomFieldUpdate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#id EventOrchestrationService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#value EventOrchestrationService#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationServiceSetRuleActionsIncidentCustomFieldUpdateToTerraform(struct?: EventOrchestrationServiceSetRuleActionsIncidentCustomFieldUpdate | cdktn.IResolvable): any;
export declare function eventOrchestrationServiceSetRuleActionsIncidentCustomFieldUpdateToHclTerraform(struct?: EventOrchestrationServiceSetRuleActionsIncidentCustomFieldUpdate | cdktn.IResolvable): any;
export declare class EventOrchestrationServiceSetRuleActionsIncidentCustomFieldUpdateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationServiceSetRuleActionsIncidentCustomFieldUpdate | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationServiceSetRuleActionsIncidentCustomFieldUpdate | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationServiceSetRuleActionsIncidentCustomFieldUpdateList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationServiceSetRuleActionsIncidentCustomFieldUpdate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationServiceSetRuleActionsIncidentCustomFieldUpdateOutputReference;
}
export interface EventOrchestrationServiceSetRuleActionsPagerdutyAutomationAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#action_id EventOrchestrationService#action_id}
    */
    readonly actionId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#trigger_types EventOrchestrationService#trigger_types}
    */
    readonly triggerTypes?: string[];
}
export declare function eventOrchestrationServiceSetRuleActionsPagerdutyAutomationActionToTerraform(struct?: EventOrchestrationServiceSetRuleActionsPagerdutyAutomationActionOutputReference | EventOrchestrationServiceSetRuleActionsPagerdutyAutomationAction): any;
export declare function eventOrchestrationServiceSetRuleActionsPagerdutyAutomationActionToHclTerraform(struct?: EventOrchestrationServiceSetRuleActionsPagerdutyAutomationActionOutputReference | EventOrchestrationServiceSetRuleActionsPagerdutyAutomationAction): any;
export declare class EventOrchestrationServiceSetRuleActionsPagerdutyAutomationActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationServiceSetRuleActionsPagerdutyAutomationAction | undefined;
    set internalValue(value: EventOrchestrationServiceSetRuleActionsPagerdutyAutomationAction | undefined);
    private _actionId?;
    get actionId(): string;
    set actionId(value: string);
    get actionIdInput(): string | undefined;
    private _triggerTypes?;
    get triggerTypes(): string[];
    set triggerTypes(value: string[]);
    resetTriggerTypes(): void;
    get triggerTypesInput(): string[] | undefined;
}
export interface EventOrchestrationServiceSetRuleActionsVariable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#name EventOrchestrationService#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#path EventOrchestrationService#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#type EventOrchestrationService#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#value EventOrchestrationService#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationServiceSetRuleActionsVariableToTerraform(struct?: EventOrchestrationServiceSetRuleActionsVariable | cdktn.IResolvable): any;
export declare function eventOrchestrationServiceSetRuleActionsVariableToHclTerraform(struct?: EventOrchestrationServiceSetRuleActionsVariable | cdktn.IResolvable): any;
export declare class EventOrchestrationServiceSetRuleActionsVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationServiceSetRuleActionsVariable | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationServiceSetRuleActionsVariable | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationServiceSetRuleActionsVariableList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationServiceSetRuleActionsVariable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationServiceSetRuleActionsVariableOutputReference;
}
export interface EventOrchestrationServiceSetRuleActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#annotate EventOrchestrationService#annotate}
    */
    readonly annotate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#escalation_policy EventOrchestrationService#escalation_policy}
    */
    readonly escalationPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#event_action EventOrchestrationService#event_action}
    */
    readonly eventAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#priority EventOrchestrationService#priority}
    */
    readonly priority?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#route_to EventOrchestrationService#route_to}
    */
    readonly routeTo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#severity EventOrchestrationService#severity}
    */
    readonly severity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#suppress EventOrchestrationService#suppress}
    */
    readonly suppress?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#suspend EventOrchestrationService#suspend}
    */
    readonly suspend?: number;
    /**
    * automation_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#automation_action EventOrchestrationService#automation_action}
    */
    readonly automationAction?: EventOrchestrationServiceSetRuleActionsAutomationAction;
    /**
    * extraction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#extraction EventOrchestrationService#extraction}
    */
    readonly extraction?: EventOrchestrationServiceSetRuleActionsExtraction[] | cdktn.IResolvable;
    /**
    * incident_custom_field_update block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#incident_custom_field_update EventOrchestrationService#incident_custom_field_update}
    */
    readonly incidentCustomFieldUpdate?: EventOrchestrationServiceSetRuleActionsIncidentCustomFieldUpdate[] | cdktn.IResolvable;
    /**
    * pagerduty_automation_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#pagerduty_automation_action EventOrchestrationService#pagerduty_automation_action}
    */
    readonly pagerdutyAutomationAction?: EventOrchestrationServiceSetRuleActionsPagerdutyAutomationAction;
    /**
    * variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#variable EventOrchestrationService#variable}
    */
    readonly variable?: EventOrchestrationServiceSetRuleActionsVariable[] | cdktn.IResolvable;
}
export declare function eventOrchestrationServiceSetRuleActionsToTerraform(struct?: EventOrchestrationServiceSetRuleActionsOutputReference | EventOrchestrationServiceSetRuleActions): any;
export declare function eventOrchestrationServiceSetRuleActionsToHclTerraform(struct?: EventOrchestrationServiceSetRuleActionsOutputReference | EventOrchestrationServiceSetRuleActions): any;
export declare class EventOrchestrationServiceSetRuleActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationServiceSetRuleActions | undefined;
    set internalValue(value: EventOrchestrationServiceSetRuleActions | undefined);
    private _annotate?;
    get annotate(): string;
    set annotate(value: string);
    resetAnnotate(): void;
    get annotateInput(): string | undefined;
    private _escalationPolicy?;
    get escalationPolicy(): string;
    set escalationPolicy(value: string);
    resetEscalationPolicy(): void;
    get escalationPolicyInput(): string | undefined;
    private _eventAction?;
    get eventAction(): string;
    set eventAction(value: string);
    resetEventAction(): void;
    get eventActionInput(): string | undefined;
    private _priority?;
    get priority(): string;
    set priority(value: string);
    resetPriority(): void;
    get priorityInput(): string | undefined;
    private _routeTo?;
    get routeTo(): string;
    set routeTo(value: string);
    resetRouteTo(): void;
    get routeToInput(): string | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    resetSeverity(): void;
    get severityInput(): string | undefined;
    private _suppress?;
    get suppress(): boolean | cdktn.IResolvable;
    set suppress(value: boolean | cdktn.IResolvable);
    resetSuppress(): void;
    get suppressInput(): boolean | cdktn.IResolvable | undefined;
    private _suspend?;
    get suspend(): number;
    set suspend(value: number);
    resetSuspend(): void;
    get suspendInput(): number | undefined;
    private _automationAction;
    get automationAction(): EventOrchestrationServiceSetRuleActionsAutomationActionOutputReference;
    putAutomationAction(value: EventOrchestrationServiceSetRuleActionsAutomationAction): void;
    resetAutomationAction(): void;
    get automationActionInput(): EventOrchestrationServiceSetRuleActionsAutomationAction | undefined;
    private _extraction;
    get extraction(): EventOrchestrationServiceSetRuleActionsExtractionList;
    putExtraction(value: EventOrchestrationServiceSetRuleActionsExtraction[] | cdktn.IResolvable): void;
    resetExtraction(): void;
    get extractionInput(): cdktn.IResolvable | EventOrchestrationServiceSetRuleActionsExtraction[] | undefined;
    private _incidentCustomFieldUpdate;
    get incidentCustomFieldUpdate(): EventOrchestrationServiceSetRuleActionsIncidentCustomFieldUpdateList;
    putIncidentCustomFieldUpdate(value: EventOrchestrationServiceSetRuleActionsIncidentCustomFieldUpdate[] | cdktn.IResolvable): void;
    resetIncidentCustomFieldUpdate(): void;
    get incidentCustomFieldUpdateInput(): cdktn.IResolvable | EventOrchestrationServiceSetRuleActionsIncidentCustomFieldUpdate[] | undefined;
    private _pagerdutyAutomationAction;
    get pagerdutyAutomationAction(): EventOrchestrationServiceSetRuleActionsPagerdutyAutomationActionOutputReference;
    putPagerdutyAutomationAction(value: EventOrchestrationServiceSetRuleActionsPagerdutyAutomationAction): void;
    resetPagerdutyAutomationAction(): void;
    get pagerdutyAutomationActionInput(): EventOrchestrationServiceSetRuleActionsPagerdutyAutomationAction | undefined;
    private _variable;
    get variable(): EventOrchestrationServiceSetRuleActionsVariableList;
    putVariable(value: EventOrchestrationServiceSetRuleActionsVariable[] | cdktn.IResolvable): void;
    resetVariable(): void;
    get variableInput(): cdktn.IResolvable | EventOrchestrationServiceSetRuleActionsVariable[] | undefined;
}
export interface EventOrchestrationServiceSetRuleCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#expression EventOrchestrationService#expression}
    */
    readonly expression: string;
}
export declare function eventOrchestrationServiceSetRuleConditionToTerraform(struct?: EventOrchestrationServiceSetRuleCondition | cdktn.IResolvable): any;
export declare function eventOrchestrationServiceSetRuleConditionToHclTerraform(struct?: EventOrchestrationServiceSetRuleCondition | cdktn.IResolvable): any;
export declare class EventOrchestrationServiceSetRuleConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationServiceSetRuleCondition | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationServiceSetRuleCondition | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export declare class EventOrchestrationServiceSetRuleConditionList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationServiceSetRuleCondition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationServiceSetRuleConditionOutputReference;
}
export interface EventOrchestrationServiceSetRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#disabled EventOrchestrationService#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#label EventOrchestrationService#label}
    */
    readonly label?: string;
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#actions EventOrchestrationService#actions}
    */
    readonly actions: EventOrchestrationServiceSetRuleActions;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#condition EventOrchestrationService#condition}
    */
    readonly condition?: EventOrchestrationServiceSetRuleCondition[] | cdktn.IResolvable;
}
export declare function eventOrchestrationServiceSetRuleToTerraform(struct?: EventOrchestrationServiceSetRule | cdktn.IResolvable): any;
export declare function eventOrchestrationServiceSetRuleToHclTerraform(struct?: EventOrchestrationServiceSetRule | cdktn.IResolvable): any;
export declare class EventOrchestrationServiceSetRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationServiceSetRule | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationServiceSetRule | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _actions;
    get actions(): EventOrchestrationServiceSetRuleActionsOutputReference;
    putActions(value: EventOrchestrationServiceSetRuleActions): void;
    get actionsInput(): EventOrchestrationServiceSetRuleActions | undefined;
    private _condition;
    get condition(): EventOrchestrationServiceSetRuleConditionList;
    putCondition(value: EventOrchestrationServiceSetRuleCondition[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | EventOrchestrationServiceSetRuleCondition[] | undefined;
}
export declare class EventOrchestrationServiceSetRuleList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationServiceSetRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationServiceSetRuleOutputReference;
}
export interface EventOrchestrationServiceSet {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#id EventOrchestrationService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#rule EventOrchestrationService#rule}
    */
    readonly rule?: EventOrchestrationServiceSetRule[] | cdktn.IResolvable;
}
export declare function eventOrchestrationServiceSetToTerraform(struct?: EventOrchestrationServiceSet | cdktn.IResolvable): any;
export declare function eventOrchestrationServiceSetToHclTerraform(struct?: EventOrchestrationServiceSet | cdktn.IResolvable): any;
export declare class EventOrchestrationServiceSetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationServiceSet | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationServiceSet | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _rule;
    get rule(): EventOrchestrationServiceSetRuleList;
    putRule(value: EventOrchestrationServiceSetRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | EventOrchestrationServiceSetRule[] | undefined;
}
export declare class EventOrchestrationServiceSetList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationServiceSet[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationServiceSetOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service pagerduty_event_orchestration_service}
*/
export declare class EventOrchestrationService extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_event_orchestration_service";
    /**
    * Generates CDKTN code for importing a EventOrchestrationService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EventOrchestrationService to import
    * @param importFromId The id of the existing EventOrchestrationService that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EventOrchestrationService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.1/docs/resources/event_orchestration_service pagerduty_event_orchestration_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EventOrchestrationServiceConfig
    */
    constructor(scope: Construct, id: string, config: EventOrchestrationServiceConfig);
    private _enableEventOrchestrationForService?;
    get enableEventOrchestrationForService(): boolean | cdktn.IResolvable;
    set enableEventOrchestrationForService(value: boolean | cdktn.IResolvable);
    resetEnableEventOrchestrationForService(): void;
    get enableEventOrchestrationForServiceInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _catchAll;
    get catchAll(): EventOrchestrationServiceCatchAllOutputReference;
    putCatchAll(value: EventOrchestrationServiceCatchAll): void;
    get catchAllInput(): EventOrchestrationServiceCatchAll | undefined;
    private _set;
    get set(): EventOrchestrationServiceSetList;
    putSet(value: EventOrchestrationServiceSet[] | cdktn.IResolvable): void;
    get setInput(): cdktn.IResolvable | EventOrchestrationServiceSet[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
