/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AutomationActionsActionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#action_classification AutomationActionsAction#action_classification}
    */
    readonly actionClassification?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#action_type AutomationActionsAction#action_type}
    */
    readonly actionType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#allow_invocation_from_event_orchestration AutomationActionsAction#allow_invocation_from_event_orchestration}
    */
    readonly allowInvocationFromEventOrchestration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#allow_invocation_manually AutomationActionsAction#allow_invocation_manually}
    */
    readonly allowInvocationManually?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#creation_time AutomationActionsAction#creation_time}
    */
    readonly creationTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#description AutomationActionsAction#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#id AutomationActionsAction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#map_to_all_services AutomationActionsAction#map_to_all_services}
    */
    readonly mapToAllServices?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#modify_time AutomationActionsAction#modify_time}
    */
    readonly modifyTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#name AutomationActionsAction#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#only_invocable_on_unresolved_incidents AutomationActionsAction#only_invocable_on_unresolved_incidents}
    */
    readonly onlyInvocableOnUnresolvedIncidents?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#runner_id AutomationActionsAction#runner_id}
    */
    readonly runnerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#runner_type AutomationActionsAction#runner_type}
    */
    readonly runnerType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#type AutomationActionsAction#type}
    */
    readonly type?: string;
    /**
    * action_data_reference block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#action_data_reference AutomationActionsAction#action_data_reference}
    */
    readonly actionDataReference: AutomationActionsActionActionDataReference;
}
export interface AutomationActionsActionActionDataReference {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#invocation_command AutomationActionsAction#invocation_command}
    */
    readonly invocationCommand?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#process_automation_job_arguments AutomationActionsAction#process_automation_job_arguments}
    */
    readonly processAutomationJobArguments?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#process_automation_job_id AutomationActionsAction#process_automation_job_id}
    */
    readonly processAutomationJobId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#process_automation_node_filter AutomationActionsAction#process_automation_node_filter}
    */
    readonly processAutomationNodeFilter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#script AutomationActionsAction#script}
    */
    readonly script?: string;
}
export declare function automationActionsActionActionDataReferenceToTerraform(struct?: AutomationActionsActionActionDataReferenceOutputReference | AutomationActionsActionActionDataReference): any;
export declare function automationActionsActionActionDataReferenceToHclTerraform(struct?: AutomationActionsActionActionDataReferenceOutputReference | AutomationActionsActionActionDataReference): any;
export declare class AutomationActionsActionActionDataReferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutomationActionsActionActionDataReference | undefined;
    set internalValue(value: AutomationActionsActionActionDataReference | undefined);
    private _invocationCommand?;
    get invocationCommand(): string;
    set invocationCommand(value: string);
    resetInvocationCommand(): void;
    get invocationCommandInput(): string | undefined;
    private _processAutomationJobArguments?;
    get processAutomationJobArguments(): string;
    set processAutomationJobArguments(value: string);
    resetProcessAutomationJobArguments(): void;
    get processAutomationJobArgumentsInput(): string | undefined;
    private _processAutomationJobId?;
    get processAutomationJobId(): string;
    set processAutomationJobId(value: string);
    resetProcessAutomationJobId(): void;
    get processAutomationJobIdInput(): string | undefined;
    private _processAutomationNodeFilter?;
    get processAutomationNodeFilter(): string;
    set processAutomationNodeFilter(value: string);
    resetProcessAutomationNodeFilter(): void;
    get processAutomationNodeFilterInput(): string | undefined;
    private _script?;
    get script(): string;
    set script(value: string);
    resetScript(): void;
    get scriptInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action pagerduty_automation_actions_action}
*/
export declare class AutomationActionsAction extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_automation_actions_action";
    /**
    * Generates CDKTN code for importing a AutomationActionsAction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AutomationActionsAction to import
    * @param importFromId The id of the existing AutomationActionsAction that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AutomationActionsAction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/automation_actions_action pagerduty_automation_actions_action} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AutomationActionsActionConfig
    */
    constructor(scope: Construct, id: string, config: AutomationActionsActionConfig);
    private _actionClassification?;
    get actionClassification(): string;
    set actionClassification(value: string);
    resetActionClassification(): void;
    get actionClassificationInput(): string | undefined;
    private _actionType?;
    get actionType(): string;
    set actionType(value: string);
    get actionTypeInput(): string | undefined;
    private _allowInvocationFromEventOrchestration?;
    get allowInvocationFromEventOrchestration(): string;
    set allowInvocationFromEventOrchestration(value: string);
    resetAllowInvocationFromEventOrchestration(): void;
    get allowInvocationFromEventOrchestrationInput(): string | undefined;
    private _allowInvocationManually?;
    get allowInvocationManually(): string;
    set allowInvocationManually(value: string);
    resetAllowInvocationManually(): void;
    get allowInvocationManuallyInput(): string | undefined;
    private _creationTime?;
    get creationTime(): string;
    set creationTime(value: string);
    resetCreationTime(): void;
    get creationTimeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _mapToAllServices?;
    get mapToAllServices(): boolean | cdktn.IResolvable;
    set mapToAllServices(value: boolean | cdktn.IResolvable);
    resetMapToAllServices(): void;
    get mapToAllServicesInput(): boolean | cdktn.IResolvable | undefined;
    private _modifyTime?;
    get modifyTime(): string;
    set modifyTime(value: string);
    resetModifyTime(): void;
    get modifyTimeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _onlyInvocableOnUnresolvedIncidents?;
    get onlyInvocableOnUnresolvedIncidents(): boolean | cdktn.IResolvable;
    set onlyInvocableOnUnresolvedIncidents(value: boolean | cdktn.IResolvable);
    resetOnlyInvocableOnUnresolvedIncidents(): void;
    get onlyInvocableOnUnresolvedIncidentsInput(): boolean | cdktn.IResolvable | undefined;
    private _runnerId?;
    get runnerId(): string;
    set runnerId(value: string);
    resetRunnerId(): void;
    get runnerIdInput(): string | undefined;
    private _runnerType?;
    get runnerType(): string;
    set runnerType(value: string);
    resetRunnerType(): void;
    get runnerTypeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _actionDataReference;
    get actionDataReference(): AutomationActionsActionActionDataReferenceOutputReference;
    putActionDataReference(value: AutomationActionsActionActionDataReference): void;
    get actionDataReferenceInput(): AutomationActionsActionActionDataReference | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
