/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface JiraCloudAccountMappingRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#account_mapping JiraCloudAccountMappingRule#account_mapping}
    */
    readonly accountMapping: string;
    /**
    * Indicates if the rule is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#enabled JiraCloudAccountMappingRule#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}
    */
    readonly name: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#config JiraCloudAccountMappingRule#config}
    */
    readonly config?: JiraCloudAccountMappingRuleConfigA;
}
export interface JiraCloudAccountMappingRuleConfigJiraCustomFields {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#source_incident_field JiraCloudAccountMappingRule#source_incident_field}
    */
    readonly sourceIncidentField?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#target_issue_field JiraCloudAccountMappingRule#target_issue_field}
    */
    readonly targetIssueField: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#target_issue_field_name JiraCloudAccountMappingRule#target_issue_field_name}
    */
    readonly targetIssueFieldName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#type JiraCloudAccountMappingRule#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#value JiraCloudAccountMappingRule#value}
    */
    readonly value?: string;
}
export declare function jiraCloudAccountMappingRuleConfigJiraCustomFieldsToTerraform(struct?: JiraCloudAccountMappingRuleConfigJiraCustomFields | cdktn.IResolvable): any;
export declare function jiraCloudAccountMappingRuleConfigJiraCustomFieldsToHclTerraform(struct?: JiraCloudAccountMappingRuleConfigJiraCustomFields | cdktn.IResolvable): any;
export declare class JiraCloudAccountMappingRuleConfigJiraCustomFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JiraCloudAccountMappingRuleConfigJiraCustomFields | cdktn.IResolvable | undefined;
    set internalValue(value: JiraCloudAccountMappingRuleConfigJiraCustomFields | cdktn.IResolvable | undefined);
    private _sourceIncidentField?;
    get sourceIncidentField(): string;
    set sourceIncidentField(value: string);
    resetSourceIncidentField(): void;
    get sourceIncidentFieldInput(): string | undefined;
    private _targetIssueField?;
    get targetIssueField(): string;
    set targetIssueField(value: string);
    get targetIssueFieldInput(): string | undefined;
    private _targetIssueFieldName?;
    get targetIssueFieldName(): string;
    set targetIssueFieldName(value: string);
    get targetIssueFieldNameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class JiraCloudAccountMappingRuleConfigJiraCustomFieldsList extends cdktn.ComplexList {
    internalValue?: JiraCloudAccountMappingRuleConfigJiraCustomFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JiraCloudAccountMappingRuleConfigJiraCustomFieldsOutputReference;
}
export interface JiraCloudAccountMappingRuleConfigJiraIssueType {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}
    */
    readonly name: string;
}
export declare function jiraCloudAccountMappingRuleConfigJiraIssueTypeToTerraform(struct?: JiraCloudAccountMappingRuleConfigJiraIssueType | cdktn.IResolvable): any;
export declare function jiraCloudAccountMappingRuleConfigJiraIssueTypeToHclTerraform(struct?: JiraCloudAccountMappingRuleConfigJiraIssueType | cdktn.IResolvable): any;
export declare class JiraCloudAccountMappingRuleConfigJiraIssueTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JiraCloudAccountMappingRuleConfigJiraIssueType | cdktn.IResolvable | undefined;
    set internalValue(value: JiraCloudAccountMappingRuleConfigJiraIssueType | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface JiraCloudAccountMappingRuleConfigJiraPriorities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#jira_id JiraCloudAccountMappingRule#jira_id}
    */
    readonly jiraId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#pagerduty_id JiraCloudAccountMappingRule#pagerduty_id}
    */
    readonly pagerdutyId: string;
}
export declare function jiraCloudAccountMappingRuleConfigJiraPrioritiesToTerraform(struct?: JiraCloudAccountMappingRuleConfigJiraPriorities | cdktn.IResolvable): any;
export declare function jiraCloudAccountMappingRuleConfigJiraPrioritiesToHclTerraform(struct?: JiraCloudAccountMappingRuleConfigJiraPriorities | cdktn.IResolvable): any;
export declare class JiraCloudAccountMappingRuleConfigJiraPrioritiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JiraCloudAccountMappingRuleConfigJiraPriorities | cdktn.IResolvable | undefined;
    set internalValue(value: JiraCloudAccountMappingRuleConfigJiraPriorities | cdktn.IResolvable | undefined);
    private _jiraId?;
    get jiraId(): string;
    set jiraId(value: string);
    get jiraIdInput(): string | undefined;
    private _pagerdutyId?;
    get pagerdutyId(): string;
    set pagerdutyId(value: string);
    get pagerdutyIdInput(): string | undefined;
}
export declare class JiraCloudAccountMappingRuleConfigJiraPrioritiesList extends cdktn.ComplexList {
    internalValue?: JiraCloudAccountMappingRuleConfigJiraPriorities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JiraCloudAccountMappingRuleConfigJiraPrioritiesOutputReference;
}
export interface JiraCloudAccountMappingRuleConfigJiraProject {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#key JiraCloudAccountMappingRule#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}
    */
    readonly name: string;
}
export declare function jiraCloudAccountMappingRuleConfigJiraProjectToTerraform(struct?: JiraCloudAccountMappingRuleConfigJiraProject | cdktn.IResolvable): any;
export declare function jiraCloudAccountMappingRuleConfigJiraProjectToHclTerraform(struct?: JiraCloudAccountMappingRuleConfigJiraProject | cdktn.IResolvable): any;
export declare class JiraCloudAccountMappingRuleConfigJiraProjectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JiraCloudAccountMappingRuleConfigJiraProject | cdktn.IResolvable | undefined;
    set internalValue(value: JiraCloudAccountMappingRuleConfigJiraProject | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}
    */
    readonly name?: string;
}
export declare function jiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledgedToTerraform(struct?: JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged | cdktn.IResolvable): any;
export declare function jiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledgedToHclTerraform(struct?: JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged | cdktn.IResolvable): any;
export declare class JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledgedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged | cdktn.IResolvable | undefined;
    set internalValue(value: JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}
    */
    readonly name?: string;
}
export declare function jiraCloudAccountMappingRuleConfigJiraStatusMappingResolvedToTerraform(struct?: JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved | cdktn.IResolvable): any;
export declare function jiraCloudAccountMappingRuleConfigJiraStatusMappingResolvedToHclTerraform(struct?: JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved | cdktn.IResolvable): any;
export declare class JiraCloudAccountMappingRuleConfigJiraStatusMappingResolvedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved | cdktn.IResolvable | undefined;
    set internalValue(value: JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}
    */
    readonly name: string;
}
export declare function jiraCloudAccountMappingRuleConfigJiraStatusMappingTriggeredToTerraform(struct?: JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered | cdktn.IResolvable): any;
export declare function jiraCloudAccountMappingRuleConfigJiraStatusMappingTriggeredToHclTerraform(struct?: JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered | cdktn.IResolvable): any;
export declare class JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggeredOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered | cdktn.IResolvable | undefined;
    set internalValue(value: JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface JiraCloudAccountMappingRuleConfigJiraStatusMapping {
    /**
    * acknowledged block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#acknowledged JiraCloudAccountMappingRule#acknowledged}
    */
    readonly acknowledged?: JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged;
    /**
    * resolved block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#resolved JiraCloudAccountMappingRule#resolved}
    */
    readonly resolved?: JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved;
    /**
    * triggered block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#triggered JiraCloudAccountMappingRule#triggered}
    */
    readonly triggered: JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered;
}
export declare function jiraCloudAccountMappingRuleConfigJiraStatusMappingToTerraform(struct?: JiraCloudAccountMappingRuleConfigJiraStatusMapping | cdktn.IResolvable): any;
export declare function jiraCloudAccountMappingRuleConfigJiraStatusMappingToHclTerraform(struct?: JiraCloudAccountMappingRuleConfigJiraStatusMapping | cdktn.IResolvable): any;
export declare class JiraCloudAccountMappingRuleConfigJiraStatusMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JiraCloudAccountMappingRuleConfigJiraStatusMapping | cdktn.IResolvable | undefined;
    set internalValue(value: JiraCloudAccountMappingRuleConfigJiraStatusMapping | cdktn.IResolvable | undefined);
    private _acknowledged;
    get acknowledged(): JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledgedOutputReference;
    putAcknowledged(value: JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged): void;
    resetAcknowledged(): void;
    get acknowledgedInput(): cdktn.IResolvable | JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged | undefined;
    private _resolved;
    get resolved(): JiraCloudAccountMappingRuleConfigJiraStatusMappingResolvedOutputReference;
    putResolved(value: JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved): void;
    resetResolved(): void;
    get resolvedInput(): cdktn.IResolvable | JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved | undefined;
    private _triggered;
    get triggered(): JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggeredOutputReference;
    putTriggered(value: JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered): void;
    get triggeredInput(): cdktn.IResolvable | JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered | undefined;
}
export interface JiraCloudAccountMappingRuleConfigJira {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#autocreate_jql JiraCloudAccountMappingRule#autocreate_jql}
    */
    readonly autocreateJql?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#create_issue_on_incident_trigger JiraCloudAccountMappingRule#create_issue_on_incident_trigger}
    */
    readonly createIssueOnIncidentTrigger?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#sync_notes_user JiraCloudAccountMappingRule#sync_notes_user}
    */
    readonly syncNotesUser?: string;
    /**
    * custom_fields block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#custom_fields JiraCloudAccountMappingRule#custom_fields}
    */
    readonly customFields?: JiraCloudAccountMappingRuleConfigJiraCustomFields[] | cdktn.IResolvable;
    /**
    * issue_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#issue_type JiraCloudAccountMappingRule#issue_type}
    */
    readonly issueType: JiraCloudAccountMappingRuleConfigJiraIssueType;
    /**
    * priorities block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#priorities JiraCloudAccountMappingRule#priorities}
    */
    readonly priorities?: JiraCloudAccountMappingRuleConfigJiraPriorities[] | cdktn.IResolvable;
    /**
    * project block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#project JiraCloudAccountMappingRule#project}
    */
    readonly project: JiraCloudAccountMappingRuleConfigJiraProject;
    /**
    * status_mapping block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#status_mapping JiraCloudAccountMappingRule#status_mapping}
    */
    readonly statusMapping?: JiraCloudAccountMappingRuleConfigJiraStatusMapping;
}
export declare function jiraCloudAccountMappingRuleConfigJiraToTerraform(struct?: JiraCloudAccountMappingRuleConfigJira | cdktn.IResolvable): any;
export declare function jiraCloudAccountMappingRuleConfigJiraToHclTerraform(struct?: JiraCloudAccountMappingRuleConfigJira | cdktn.IResolvable): any;
export declare class JiraCloudAccountMappingRuleConfigJiraOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JiraCloudAccountMappingRuleConfigJira | cdktn.IResolvable | undefined;
    set internalValue(value: JiraCloudAccountMappingRuleConfigJira | cdktn.IResolvable | undefined);
    private _autocreateJql?;
    get autocreateJql(): string;
    set autocreateJql(value: string);
    resetAutocreateJql(): void;
    get autocreateJqlInput(): string | undefined;
    private _createIssueOnIncidentTrigger?;
    get createIssueOnIncidentTrigger(): boolean | cdktn.IResolvable;
    set createIssueOnIncidentTrigger(value: boolean | cdktn.IResolvable);
    resetCreateIssueOnIncidentTrigger(): void;
    get createIssueOnIncidentTriggerInput(): boolean | cdktn.IResolvable | undefined;
    private _syncNotesUser?;
    get syncNotesUser(): string;
    set syncNotesUser(value: string);
    resetSyncNotesUser(): void;
    get syncNotesUserInput(): string | undefined;
    private _customFields;
    get customFields(): JiraCloudAccountMappingRuleConfigJiraCustomFieldsList;
    putCustomFields(value: JiraCloudAccountMappingRuleConfigJiraCustomFields[] | cdktn.IResolvable): void;
    resetCustomFields(): void;
    get customFieldsInput(): cdktn.IResolvable | JiraCloudAccountMappingRuleConfigJiraCustomFields[] | undefined;
    private _issueType;
    get issueType(): JiraCloudAccountMappingRuleConfigJiraIssueTypeOutputReference;
    putIssueType(value: JiraCloudAccountMappingRuleConfigJiraIssueType): void;
    get issueTypeInput(): cdktn.IResolvable | JiraCloudAccountMappingRuleConfigJiraIssueType | undefined;
    private _priorities;
    get priorities(): JiraCloudAccountMappingRuleConfigJiraPrioritiesList;
    putPriorities(value: JiraCloudAccountMappingRuleConfigJiraPriorities[] | cdktn.IResolvable): void;
    resetPriorities(): void;
    get prioritiesInput(): cdktn.IResolvable | JiraCloudAccountMappingRuleConfigJiraPriorities[] | undefined;
    private _project;
    get project(): JiraCloudAccountMappingRuleConfigJiraProjectOutputReference;
    putProject(value: JiraCloudAccountMappingRuleConfigJiraProject): void;
    get projectInput(): cdktn.IResolvable | JiraCloudAccountMappingRuleConfigJiraProject | undefined;
    private _statusMapping;
    get statusMapping(): JiraCloudAccountMappingRuleConfigJiraStatusMappingOutputReference;
    putStatusMapping(value: JiraCloudAccountMappingRuleConfigJiraStatusMapping): void;
    resetStatusMapping(): void;
    get statusMappingInput(): cdktn.IResolvable | JiraCloudAccountMappingRuleConfigJiraStatusMapping | undefined;
}
export interface JiraCloudAccountMappingRuleConfigA {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#service JiraCloudAccountMappingRule#service}
    */
    readonly service: string;
    /**
    * jira block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#jira JiraCloudAccountMappingRule#jira}
    */
    readonly jira?: JiraCloudAccountMappingRuleConfigJira;
}
export declare function jiraCloudAccountMappingRuleConfigAToTerraform(struct?: JiraCloudAccountMappingRuleConfigA | cdktn.IResolvable): any;
export declare function jiraCloudAccountMappingRuleConfigAToHclTerraform(struct?: JiraCloudAccountMappingRuleConfigA | cdktn.IResolvable): any;
export declare class JiraCloudAccountMappingRuleConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JiraCloudAccountMappingRuleConfigA | cdktn.IResolvable | undefined;
    set internalValue(value: JiraCloudAccountMappingRuleConfigA | cdktn.IResolvable | undefined);
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _jira;
    get jira(): JiraCloudAccountMappingRuleConfigJiraOutputReference;
    putJira(value: JiraCloudAccountMappingRuleConfigJira): void;
    resetJira(): void;
    get jiraInput(): cdktn.IResolvable | JiraCloudAccountMappingRuleConfigJira | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule pagerduty_jira_cloud_account_mapping_rule}
*/
export declare class JiraCloudAccountMappingRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_jira_cloud_account_mapping_rule";
    /**
    * Generates CDKTN code for importing a JiraCloudAccountMappingRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the JiraCloudAccountMappingRule to import
    * @param importFromId The id of the existing JiraCloudAccountMappingRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the JiraCloudAccountMappingRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/jira_cloud_account_mapping_rule pagerduty_jira_cloud_account_mapping_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options JiraCloudAccountMappingRuleConfig
    */
    constructor(scope: Construct, id: string, config: JiraCloudAccountMappingRuleConfig);
    private _accountMapping?;
    get accountMapping(): string;
    set accountMapping(value: string);
    get accountMappingInput(): string | undefined;
    get autocreateJqlDisabledReason(): string;
    get autocreateJqlDisabledUntil(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _config;
    get config(): JiraCloudAccountMappingRuleConfigAOutputReference;
    putConfig(value: JiraCloudAccountMappingRuleConfigA): void;
    resetConfig(): void;
    get configInput(): cdktn.IResolvable | JiraCloudAccountMappingRuleConfigA | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
