/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ResponsePlayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#conference_number ResponsePlay#conference_number}
    */
    readonly conferenceNumber?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#conference_url ResponsePlay#conference_url}
    */
    readonly conferenceUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#description ResponsePlay#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#from ResponsePlay#from}
    */
    readonly from: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#id ResponsePlay#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#name ResponsePlay#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#responders_message ResponsePlay#responders_message}
    */
    readonly respondersMessage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#runnability ResponsePlay#runnability}
    */
    readonly runnability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#subscribers_message ResponsePlay#subscribers_message}
    */
    readonly subscribersMessage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#team ResponsePlay#team}
    */
    readonly team?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#type ResponsePlay#type}
    */
    readonly type?: string;
    /**
    * responder block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#responder ResponsePlay#responder}
    */
    readonly responder?: ResponsePlayResponder[] | cdktn.IResolvable;
    /**
    * subscriber block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#subscriber ResponsePlay#subscriber}
    */
    readonly subscriber?: ResponsePlaySubscriber[] | cdktn.IResolvable;
}
export interface ResponsePlayResponderEscalationRuleTarget {
}
export declare function responsePlayResponderEscalationRuleTargetToTerraform(struct?: ResponsePlayResponderEscalationRuleTarget): any;
export declare function responsePlayResponderEscalationRuleTargetToHclTerraform(struct?: ResponsePlayResponderEscalationRuleTarget): any;
export declare class ResponsePlayResponderEscalationRuleTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ResponsePlayResponderEscalationRuleTarget | undefined;
    set internalValue(value: ResponsePlayResponderEscalationRuleTarget | undefined);
    get id(): string;
    get type(): string;
}
export declare class ResponsePlayResponderEscalationRuleTargetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ResponsePlayResponderEscalationRuleTargetOutputReference;
}
export interface ResponsePlayResponderEscalationRule {
}
export declare function responsePlayResponderEscalationRuleToTerraform(struct?: ResponsePlayResponderEscalationRule): any;
export declare function responsePlayResponderEscalationRuleToHclTerraform(struct?: ResponsePlayResponderEscalationRule): any;
export declare class ResponsePlayResponderEscalationRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ResponsePlayResponderEscalationRule | undefined;
    set internalValue(value: ResponsePlayResponderEscalationRule | undefined);
    get escalationDelayInMinutes(): number;
    get id(): string;
    private _target;
    get target(): ResponsePlayResponderEscalationRuleTargetList;
}
export declare class ResponsePlayResponderEscalationRuleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ResponsePlayResponderEscalationRuleOutputReference;
}
export interface ResponsePlayResponderService {
}
export declare function responsePlayResponderServiceToTerraform(struct?: ResponsePlayResponderService): any;
export declare function responsePlayResponderServiceToHclTerraform(struct?: ResponsePlayResponderService): any;
export declare class ResponsePlayResponderServiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ResponsePlayResponderService | undefined;
    set internalValue(value: ResponsePlayResponderService | undefined);
    get id(): string;
    get type(): string;
}
export declare class ResponsePlayResponderServiceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ResponsePlayResponderServiceOutputReference;
}
export interface ResponsePlayResponderTeam {
}
export declare function responsePlayResponderTeamToTerraform(struct?: ResponsePlayResponderTeam): any;
export declare function responsePlayResponderTeamToHclTerraform(struct?: ResponsePlayResponderTeam): any;
export declare class ResponsePlayResponderTeamOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ResponsePlayResponderTeam | undefined;
    set internalValue(value: ResponsePlayResponderTeam | undefined);
    get id(): string;
    get type(): string;
}
export declare class ResponsePlayResponderTeamList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ResponsePlayResponderTeamOutputReference;
}
export interface ResponsePlayResponder {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#description ResponsePlay#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#id ResponsePlay#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#name ResponsePlay#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#type ResponsePlay#type}
    */
    readonly type?: string;
}
export declare function responsePlayResponderToTerraform(struct?: ResponsePlayResponder | cdktn.IResolvable): any;
export declare function responsePlayResponderToHclTerraform(struct?: ResponsePlayResponder | cdktn.IResolvable): any;
export declare class ResponsePlayResponderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ResponsePlayResponder | cdktn.IResolvable | undefined;
    set internalValue(value: ResponsePlayResponder | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _escalationRule;
    get escalationRule(): ResponsePlayResponderEscalationRuleList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get numLoops(): number;
    get onCallHandoffNotifications(): string;
    private _service;
    get service(): ResponsePlayResponderServiceList;
    private _team;
    get team(): ResponsePlayResponderTeamList;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class ResponsePlayResponderList extends cdktn.ComplexList {
    internalValue?: ResponsePlayResponder[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ResponsePlayResponderOutputReference;
}
export interface ResponsePlaySubscriber {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#id ResponsePlay#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#type ResponsePlay#type}
    */
    readonly type?: string;
}
export declare function responsePlaySubscriberToTerraform(struct?: ResponsePlaySubscriber | cdktn.IResolvable): any;
export declare function responsePlaySubscriberToHclTerraform(struct?: ResponsePlaySubscriber | cdktn.IResolvable): any;
export declare class ResponsePlaySubscriberOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ResponsePlaySubscriber | cdktn.IResolvable | undefined;
    set internalValue(value: ResponsePlaySubscriber | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class ResponsePlaySubscriberList extends cdktn.ComplexList {
    internalValue?: ResponsePlaySubscriber[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ResponsePlaySubscriberOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play pagerduty_response_play}
*/
export declare class ResponsePlay extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_response_play";
    /**
    * Generates CDKTN code for importing a ResponsePlay resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ResponsePlay to import
    * @param importFromId The id of the existing ResponsePlay that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ResponsePlay to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/response_play pagerduty_response_play} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ResponsePlayConfig
    */
    constructor(scope: Construct, id: string, config: ResponsePlayConfig);
    private _conferenceNumber?;
    get conferenceNumber(): string;
    set conferenceNumber(value: string);
    resetConferenceNumber(): void;
    get conferenceNumberInput(): string | undefined;
    private _conferenceUrl?;
    get conferenceUrl(): string;
    set conferenceUrl(value: string);
    resetConferenceUrl(): void;
    get conferenceUrlInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _from?;
    get from(): string;
    set from(value: string);
    get fromInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _respondersMessage?;
    get respondersMessage(): string;
    set respondersMessage(value: string);
    resetRespondersMessage(): void;
    get respondersMessageInput(): string | undefined;
    private _runnability?;
    get runnability(): string;
    set runnability(value: string);
    resetRunnability(): void;
    get runnabilityInput(): string | undefined;
    private _subscribersMessage?;
    get subscribersMessage(): string;
    set subscribersMessage(value: string);
    resetSubscribersMessage(): void;
    get subscribersMessageInput(): string | undefined;
    private _team?;
    get team(): string;
    set team(value: string);
    resetTeam(): void;
    get teamInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _responder;
    get responder(): ResponsePlayResponderList;
    putResponder(value: ResponsePlayResponder[] | cdktn.IResolvable): void;
    resetResponder(): void;
    get responderInput(): cdktn.IResolvable | ResponsePlayResponder[] | undefined;
    private _subscriber;
    get subscriber(): ResponsePlaySubscriberList;
    putSubscriber(value: ResponsePlaySubscriber[] | cdktn.IResolvable): void;
    resetSubscriber(): void;
    get subscriberInput(): cdktn.IResolvable | ResponsePlaySubscriber[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
