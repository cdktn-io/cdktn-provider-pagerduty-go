/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ScheduleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#description Schedule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#id Schedule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#name Schedule#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#overflow Schedule#overflow}
    */
    readonly overflow?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#teams Schedule#teams}
    */
    readonly teams?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#time_zone Schedule#time_zone}
    */
    readonly timeZone: string;
    /**
    * layer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#layer Schedule#layer}
    */
    readonly layer: ScheduleLayer[] | cdktn.IResolvable;
}
export interface ScheduleFinalSchedule {
}
export declare function scheduleFinalScheduleToTerraform(struct?: ScheduleFinalSchedule): any;
export declare function scheduleFinalScheduleToHclTerraform(struct?: ScheduleFinalSchedule): any;
export declare class ScheduleFinalScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ScheduleFinalSchedule | undefined;
    set internalValue(value: ScheduleFinalSchedule | undefined);
    get name(): string;
    get renderedCoveragePercentage(): string;
}
export declare class ScheduleFinalScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ScheduleFinalScheduleOutputReference;
}
export interface ScheduleLayerRestriction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#duration_seconds Schedule#duration_seconds}
    */
    readonly durationSeconds: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#start_day_of_week Schedule#start_day_of_week}
    */
    readonly startDayOfWeek?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#start_time_of_day Schedule#start_time_of_day}
    */
    readonly startTimeOfDay: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#type Schedule#type}
    */
    readonly type: string;
}
export declare function scheduleLayerRestrictionToTerraform(struct?: ScheduleLayerRestriction | cdktn.IResolvable): any;
export declare function scheduleLayerRestrictionToHclTerraform(struct?: ScheduleLayerRestriction | cdktn.IResolvable): any;
export declare class ScheduleLayerRestrictionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ScheduleLayerRestriction | cdktn.IResolvable | undefined;
    set internalValue(value: ScheduleLayerRestriction | cdktn.IResolvable | undefined);
    private _durationSeconds?;
    get durationSeconds(): number;
    set durationSeconds(value: number);
    get durationSecondsInput(): number | undefined;
    private _startDayOfWeek?;
    get startDayOfWeek(): number;
    set startDayOfWeek(value: number);
    resetStartDayOfWeek(): void;
    get startDayOfWeekInput(): number | undefined;
    private _startTimeOfDay?;
    get startTimeOfDay(): string;
    set startTimeOfDay(value: string);
    get startTimeOfDayInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ScheduleLayerRestrictionList extends cdktn.ComplexList {
    internalValue?: ScheduleLayerRestriction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ScheduleLayerRestrictionOutputReference;
}
export interface ScheduleLayer {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#end Schedule#end}
    */
    readonly end?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#name Schedule#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#rotation_turn_length_seconds Schedule#rotation_turn_length_seconds}
    */
    readonly rotationTurnLengthSeconds: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#rotation_virtual_start Schedule#rotation_virtual_start}
    */
    readonly rotationVirtualStart: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#start Schedule#start}
    */
    readonly start: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#users Schedule#users}
    */
    readonly users: string[];
    /**
    * restriction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#restriction Schedule#restriction}
    */
    readonly restriction?: ScheduleLayerRestriction[] | cdktn.IResolvable;
}
export declare function scheduleLayerToTerraform(struct?: ScheduleLayer | cdktn.IResolvable): any;
export declare function scheduleLayerToHclTerraform(struct?: ScheduleLayer | cdktn.IResolvable): any;
export declare class ScheduleLayerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ScheduleLayer | cdktn.IResolvable | undefined;
    set internalValue(value: ScheduleLayer | cdktn.IResolvable | undefined);
    private _end?;
    get end(): string;
    set end(value: string);
    resetEnd(): void;
    get endInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get renderedCoveragePercentage(): string;
    private _rotationTurnLengthSeconds?;
    get rotationTurnLengthSeconds(): number;
    set rotationTurnLengthSeconds(value: number);
    get rotationTurnLengthSecondsInput(): number | undefined;
    private _rotationVirtualStart?;
    get rotationVirtualStart(): string;
    set rotationVirtualStart(value: string);
    get rotationVirtualStartInput(): string | undefined;
    private _start?;
    get start(): string;
    set start(value: string);
    get startInput(): string | undefined;
    private _users?;
    get users(): string[];
    set users(value: string[]);
    get usersInput(): string[] | undefined;
    private _restriction;
    get restriction(): ScheduleLayerRestrictionList;
    putRestriction(value: ScheduleLayerRestriction[] | cdktn.IResolvable): void;
    resetRestriction(): void;
    get restrictionInput(): cdktn.IResolvable | ScheduleLayerRestriction[] | undefined;
}
export declare class ScheduleLayerList extends cdktn.ComplexList {
    internalValue?: ScheduleLayer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ScheduleLayerOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule pagerduty_schedule}
*/
export declare class Schedule extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_schedule";
    /**
    * Generates CDKTN code for importing a Schedule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Schedule to import
    * @param importFromId The id of the existing Schedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Schedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/schedule pagerduty_schedule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ScheduleConfig
    */
    constructor(scope: Construct, id: string, config: ScheduleConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _finalSchedule;
    get finalSchedule(): ScheduleFinalScheduleList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _overflow?;
    get overflow(): boolean | cdktn.IResolvable;
    set overflow(value: boolean | cdktn.IResolvable);
    resetOverflow(): void;
    get overflowInput(): boolean | cdktn.IResolvable | undefined;
    private _teams?;
    get teams(): string[];
    set teams(value: string[]);
    resetTeams(): void;
    get teamsInput(): string[] | undefined;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    get timeZoneInput(): string | undefined;
    private _layer;
    get layer(): ScheduleLayerList;
    putLayer(value: ScheduleLayer[] | cdktn.IResolvable): void;
    get layerInput(): cdktn.IResolvable | ScheduleLayer[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
