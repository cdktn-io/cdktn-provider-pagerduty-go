/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EventOrchestrationIntegrationAConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/event_orchestration_integration#event_orchestration EventOrchestrationIntegrationA#event_orchestration}
    */
    readonly eventOrchestration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/event_orchestration_integration#label EventOrchestrationIntegrationA#label}
    */
    readonly label: string;
}
export interface EventOrchestrationIntegrationParametersA {
}
export declare function eventOrchestrationIntegrationParametersAToTerraform(struct?: EventOrchestrationIntegrationParametersA): any;
export declare function eventOrchestrationIntegrationParametersAToHclTerraform(struct?: EventOrchestrationIntegrationParametersA): any;
export declare class EventOrchestrationIntegrationParametersAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationIntegrationParametersA | undefined;
    set internalValue(value: EventOrchestrationIntegrationParametersA | undefined);
    get routingKey(): string;
    get type(): string;
}
export declare class EventOrchestrationIntegrationParametersAList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationIntegrationParametersAOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/event_orchestration_integration pagerduty_event_orchestration_integration}
*/
export declare class EventOrchestrationIntegrationA extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_event_orchestration_integration";
    /**
    * Generates CDKTN code for importing a EventOrchestrationIntegrationA resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EventOrchestrationIntegrationA to import
    * @param importFromId The id of the existing EventOrchestrationIntegrationA that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/event_orchestration_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EventOrchestrationIntegrationA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/event_orchestration_integration pagerduty_event_orchestration_integration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EventOrchestrationIntegrationAConfig
    */
    constructor(scope: Construct, id: string, config: EventOrchestrationIntegrationAConfig);
    private _eventOrchestration?;
    get eventOrchestration(): string;
    set eventOrchestration(value: string);
    get eventOrchestrationInput(): string | undefined;
    get id(): string;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    private _parameters;
    get parameters(): EventOrchestrationIntegrationParametersAList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
