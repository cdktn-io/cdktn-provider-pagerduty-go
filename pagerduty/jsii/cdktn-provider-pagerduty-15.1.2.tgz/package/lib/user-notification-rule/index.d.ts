/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface UserNotificationRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/user_notification_rule#start_delay_in_minutes UserNotificationRule#start_delay_in_minutes}
    */
    readonly startDelayInMinutes: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/user_notification_rule#urgency UserNotificationRule#urgency}
    */
    readonly urgency: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/user_notification_rule#user_id UserNotificationRule#user_id}
    */
    readonly userId: string;
    /**
    * contact_method block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/user_notification_rule#contact_method UserNotificationRule#contact_method}
    */
    readonly contactMethod: UserNotificationRuleContactMethod;
}
export interface UserNotificationRuleContactMethod {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/user_notification_rule#id UserNotificationRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/user_notification_rule#type UserNotificationRule#type}
    */
    readonly type: string;
}
export declare function userNotificationRuleContactMethodToTerraform(struct?: UserNotificationRuleContactMethod | cdktn.IResolvable): any;
export declare function userNotificationRuleContactMethodToHclTerraform(struct?: UserNotificationRuleContactMethod | cdktn.IResolvable): any;
export declare class UserNotificationRuleContactMethodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): UserNotificationRuleContactMethod | cdktn.IResolvable | undefined;
    set internalValue(value: UserNotificationRuleContactMethod | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/user_notification_rule pagerduty_user_notification_rule}
*/
export declare class UserNotificationRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_user_notification_rule";
    /**
    * Generates CDKTN code for importing a UserNotificationRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UserNotificationRule to import
    * @param importFromId The id of the existing UserNotificationRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/user_notification_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UserNotificationRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/resources/user_notification_rule pagerduty_user_notification_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UserNotificationRuleConfig
    */
    constructor(scope: Construct, id: string, config: UserNotificationRuleConfig);
    get id(): string;
    private _startDelayInMinutes?;
    get startDelayInMinutes(): number;
    set startDelayInMinutes(value: number);
    get startDelayInMinutesInput(): number | undefined;
    private _urgency?;
    get urgency(): string;
    set urgency(value: string);
    get urgencyInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    private _contactMethod;
    get contactMethod(): UserNotificationRuleContactMethodOutputReference;
    putContactMethod(value: UserNotificationRuleContactMethod): void;
    get contactMethodInput(): cdktn.IResolvable | UserNotificationRuleContactMethod | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
