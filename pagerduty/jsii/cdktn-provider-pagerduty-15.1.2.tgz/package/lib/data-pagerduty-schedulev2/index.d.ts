/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPagerdutySchedulev2Config extends cdktn.TerraformMetaArguments {
    /**
    * The name of the schedule to search for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/data-sources/schedulev2#name DataPagerdutySchedulev2#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/data-sources/schedulev2 pagerduty_schedulev2}
*/
export declare class DataPagerdutySchedulev2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_schedulev2";
    /**
    * Generates CDKTN code for importing a DataPagerdutySchedulev2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutySchedulev2 to import
    * @param importFromId The id of the existing DataPagerdutySchedulev2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/data-sources/schedulev2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutySchedulev2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.2/docs/data-sources/schedulev2 pagerduty_schedulev2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutySchedulev2Config
    */
    constructor(scope: Construct, id: string, config: DataPagerdutySchedulev2Config);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
