/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AutomationActionsActionServiceAssociationConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/automation_actions_action_service_association#action_id AutomationActionsActionServiceAssociation#action_id}
    */
    readonly actionId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/automation_actions_action_service_association#id AutomationActionsActionServiceAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/automation_actions_action_service_association#service_id AutomationActionsActionServiceAssociation#service_id}
    */
    readonly serviceId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/automation_actions_action_service_association pagerduty_automation_actions_action_service_association}
*/
export declare class AutomationActionsActionServiceAssociation extends cdktf.TerraformResource {
    static readonly tfResourceType = "pagerduty_automation_actions_action_service_association";
    /**
    * Generates CDKTF code for importing a AutomationActionsActionServiceAssociation resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AutomationActionsActionServiceAssociation to import
    * @param importFromId The id of the existing AutomationActionsActionServiceAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/automation_actions_action_service_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AutomationActionsActionServiceAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/automation_actions_action_service_association pagerduty_automation_actions_action_service_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AutomationActionsActionServiceAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AutomationActionsActionServiceAssociationConfig);
    private _actionId?;
    get actionId(): string;
    set actionId(value: string);
    get actionIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _serviceId?;
    get serviceId(): string;
    set serviceId(value: string);
    get serviceIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
