/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataPagerdutyScheduleConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/data-sources/schedule#name DataPagerdutySchedule#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/data-sources/schedule pagerduty_schedule}
*/
export declare class DataPagerdutySchedule extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_schedule";
    /**
    * Generates CDKTF code for importing a DataPagerdutySchedule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutySchedule to import
    * @param importFromId The id of the existing DataPagerdutySchedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/data-sources/schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutySchedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/data-sources/schedule pagerduty_schedule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyScheduleConfig
    */
    constructor(scope: Construct, id: string, config: DataPagerdutyScheduleConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
