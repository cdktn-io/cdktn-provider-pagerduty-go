/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ExtensionConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/extension#config Extension#config}
    */
    readonly config?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/extension#endpoint_url Extension#endpoint_url}
    */
    readonly endpointUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/extension#extension_objects Extension#extension_objects}
    */
    readonly extensionObjects: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/extension#extension_schema Extension#extension_schema}
    */
    readonly extensionSchema: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/extension#name Extension#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/extension#type Extension#type}
    */
    readonly type?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/extension pagerduty_extension}
*/
export declare class Extension extends cdktf.TerraformResource {
    static readonly tfResourceType = "pagerduty_extension";
    /**
    * Generates CDKTF code for importing a Extension resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Extension to import
    * @param importFromId The id of the existing Extension that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/extension#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Extension to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/extension pagerduty_extension} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ExtensionConfig
    */
    constructor(scope: Construct, id: string, config: ExtensionConfig);
    private _config?;
    get config(): string;
    set config(value: string);
    resetConfig(): void;
    get configInput(): string | undefined;
    private _endpointUrl?;
    get endpointUrl(): string;
    set endpointUrl(value: string);
    resetEndpointUrl(): void;
    get endpointUrlInput(): string | undefined;
    private _extensionObjects?;
    get extensionObjects(): string[];
    set extensionObjects(value: string[]);
    get extensionObjectsInput(): string[] | undefined;
    private _extensionSchema?;
    get extensionSchema(): string;
    set extensionSchema(value: string);
    get extensionSchemaInput(): string | undefined;
    get htmlUrl(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get summary(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
