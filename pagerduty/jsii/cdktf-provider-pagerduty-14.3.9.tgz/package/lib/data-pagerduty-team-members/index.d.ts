/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataPagerdutyTeamMembersConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/data-sources/team_members#id DataPagerdutyTeamMembers#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the team to find via the PagerDuty API
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/data-sources/team_members#team_id DataPagerdutyTeamMembers#team_id}
    */
    readonly teamId: string;
}
export interface DataPagerdutyTeamMembersMembers {
}
export declare function dataPagerdutyTeamMembersMembersToTerraform(struct?: DataPagerdutyTeamMembersMembers): any;
export declare function dataPagerdutyTeamMembersMembersToHclTerraform(struct?: DataPagerdutyTeamMembersMembers): any;
export declare class DataPagerdutyTeamMembersMembersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyTeamMembersMembers | undefined;
    set internalValue(value: DataPagerdutyTeamMembersMembers | undefined);
    get id(): string;
    get role(): string;
    get summary(): string;
    get type(): string;
}
export declare class DataPagerdutyTeamMembersMembersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyTeamMembersMembersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/data-sources/team_members pagerduty_team_members}
*/
export declare class DataPagerdutyTeamMembers extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_team_members";
    /**
    * Generates CDKTF code for importing a DataPagerdutyTeamMembers resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyTeamMembers to import
    * @param importFromId The id of the existing DataPagerdutyTeamMembers that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/data-sources/team_members#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyTeamMembers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/data-sources/team_members pagerduty_team_members} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyTeamMembersConfig
    */
    constructor(scope: Construct, id: string, config: DataPagerdutyTeamMembersConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _members;
    get members(): DataPagerdutyTeamMembersMembersList;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
