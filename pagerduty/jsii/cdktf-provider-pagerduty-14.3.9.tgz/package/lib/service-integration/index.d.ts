/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ServiceIntegrationConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#email_filter_mode ServiceIntegration#email_filter_mode}
    */
    readonly emailFilterMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#email_incident_creation ServiceIntegration#email_incident_creation}
    */
    readonly emailIncidentCreation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#email_parsing_fallback ServiceIntegration#email_parsing_fallback}
    */
    readonly emailParsingFallback?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#id ServiceIntegration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#integration_email ServiceIntegration#integration_email}
    */
    readonly integrationEmail?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#integration_key ServiceIntegration#integration_key}
    */
    readonly integrationKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#name ServiceIntegration#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#service ServiceIntegration#service}
    */
    readonly service: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#type ServiceIntegration#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#vendor ServiceIntegration#vendor}
    */
    readonly vendor?: string;
    /**
    * email_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#email_filter ServiceIntegration#email_filter}
    */
    readonly emailFilter?: ServiceIntegrationEmailFilter[] | cdktf.IResolvable;
    /**
    * email_parser block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#email_parser ServiceIntegration#email_parser}
    */
    readonly emailParser?: ServiceIntegrationEmailParser[] | cdktf.IResolvable;
}
export interface ServiceIntegrationEmailFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#body_mode ServiceIntegration#body_mode}
    */
    readonly bodyMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#body_regex ServiceIntegration#body_regex}
    */
    readonly bodyRegex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#from_email_mode ServiceIntegration#from_email_mode}
    */
    readonly fromEmailMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#from_email_regex ServiceIntegration#from_email_regex}
    */
    readonly fromEmailRegex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#subject_mode ServiceIntegration#subject_mode}
    */
    readonly subjectMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#subject_regex ServiceIntegration#subject_regex}
    */
    readonly subjectRegex?: string;
}
export declare function serviceIntegrationEmailFilterToTerraform(struct?: ServiceIntegrationEmailFilter | cdktf.IResolvable): any;
export declare function serviceIntegrationEmailFilterToHclTerraform(struct?: ServiceIntegrationEmailFilter | cdktf.IResolvable): any;
export declare class ServiceIntegrationEmailFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceIntegrationEmailFilter | cdktf.IResolvable | undefined;
    set internalValue(value: ServiceIntegrationEmailFilter | cdktf.IResolvable | undefined);
    private _bodyMode?;
    get bodyMode(): string;
    set bodyMode(value: string);
    resetBodyMode(): void;
    get bodyModeInput(): string | undefined;
    private _bodyRegex?;
    get bodyRegex(): string;
    set bodyRegex(value: string);
    resetBodyRegex(): void;
    get bodyRegexInput(): string | undefined;
    private _fromEmailMode?;
    get fromEmailMode(): string;
    set fromEmailMode(value: string);
    resetFromEmailMode(): void;
    get fromEmailModeInput(): string | undefined;
    private _fromEmailRegex?;
    get fromEmailRegex(): string;
    set fromEmailRegex(value: string);
    resetFromEmailRegex(): void;
    get fromEmailRegexInput(): string | undefined;
    get id(): string;
    private _subjectMode?;
    get subjectMode(): string;
    set subjectMode(value: string);
    resetSubjectMode(): void;
    get subjectModeInput(): string | undefined;
    private _subjectRegex?;
    get subjectRegex(): string;
    set subjectRegex(value: string);
    resetSubjectRegex(): void;
    get subjectRegexInput(): string | undefined;
}
export declare class ServiceIntegrationEmailFilterList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceIntegrationEmailFilter[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceIntegrationEmailFilterOutputReference;
}
export interface ServiceIntegrationEmailParserMatchPredicatePredicatePredicate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#matcher ServiceIntegration#matcher}
    */
    readonly matcher: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#part ServiceIntegration#part}
    */
    readonly part: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#type ServiceIntegration#type}
    */
    readonly type: string;
}
export declare function serviceIntegrationEmailParserMatchPredicatePredicatePredicateToTerraform(struct?: ServiceIntegrationEmailParserMatchPredicatePredicatePredicate | cdktf.IResolvable): any;
export declare function serviceIntegrationEmailParserMatchPredicatePredicatePredicateToHclTerraform(struct?: ServiceIntegrationEmailParserMatchPredicatePredicatePredicate | cdktf.IResolvable): any;
export declare class ServiceIntegrationEmailParserMatchPredicatePredicatePredicateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceIntegrationEmailParserMatchPredicatePredicatePredicate | cdktf.IResolvable | undefined;
    set internalValue(value: ServiceIntegrationEmailParserMatchPredicatePredicatePredicate | cdktf.IResolvable | undefined);
    private _matcher?;
    get matcher(): string;
    set matcher(value: string);
    get matcherInput(): string | undefined;
    private _part?;
    get part(): string;
    set part(value: string);
    get partInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ServiceIntegrationEmailParserMatchPredicatePredicatePredicateList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceIntegrationEmailParserMatchPredicatePredicatePredicate[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceIntegrationEmailParserMatchPredicatePredicatePredicateOutputReference;
}
export interface ServiceIntegrationEmailParserMatchPredicatePredicate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#matcher ServiceIntegration#matcher}
    */
    readonly matcher?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#part ServiceIntegration#part}
    */
    readonly part?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#type ServiceIntegration#type}
    */
    readonly type: string;
    /**
    * predicate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#predicate ServiceIntegration#predicate}
    */
    readonly predicate?: ServiceIntegrationEmailParserMatchPredicatePredicatePredicate[] | cdktf.IResolvable;
}
export declare function serviceIntegrationEmailParserMatchPredicatePredicateToTerraform(struct?: ServiceIntegrationEmailParserMatchPredicatePredicate | cdktf.IResolvable): any;
export declare function serviceIntegrationEmailParserMatchPredicatePredicateToHclTerraform(struct?: ServiceIntegrationEmailParserMatchPredicatePredicate | cdktf.IResolvable): any;
export declare class ServiceIntegrationEmailParserMatchPredicatePredicateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceIntegrationEmailParserMatchPredicatePredicate | cdktf.IResolvable | undefined;
    set internalValue(value: ServiceIntegrationEmailParserMatchPredicatePredicate | cdktf.IResolvable | undefined);
    private _matcher?;
    get matcher(): string;
    set matcher(value: string);
    resetMatcher(): void;
    get matcherInput(): string | undefined;
    private _part?;
    get part(): string;
    set part(value: string);
    resetPart(): void;
    get partInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _predicate;
    get predicate(): ServiceIntegrationEmailParserMatchPredicatePredicatePredicateList;
    putPredicate(value: ServiceIntegrationEmailParserMatchPredicatePredicatePredicate[] | cdktf.IResolvable): void;
    resetPredicate(): void;
    get predicateInput(): cdktf.IResolvable | ServiceIntegrationEmailParserMatchPredicatePredicatePredicate[] | undefined;
}
export declare class ServiceIntegrationEmailParserMatchPredicatePredicateList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceIntegrationEmailParserMatchPredicatePredicate[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceIntegrationEmailParserMatchPredicatePredicateOutputReference;
}
export interface ServiceIntegrationEmailParserMatchPredicate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#type ServiceIntegration#type}
    */
    readonly type: string;
    /**
    * predicate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#predicate ServiceIntegration#predicate}
    */
    readonly predicate?: ServiceIntegrationEmailParserMatchPredicatePredicate[] | cdktf.IResolvable;
}
export declare function serviceIntegrationEmailParserMatchPredicateToTerraform(struct?: ServiceIntegrationEmailParserMatchPredicateOutputReference | ServiceIntegrationEmailParserMatchPredicate): any;
export declare function serviceIntegrationEmailParserMatchPredicateToHclTerraform(struct?: ServiceIntegrationEmailParserMatchPredicateOutputReference | ServiceIntegrationEmailParserMatchPredicate): any;
export declare class ServiceIntegrationEmailParserMatchPredicateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceIntegrationEmailParserMatchPredicate | undefined;
    set internalValue(value: ServiceIntegrationEmailParserMatchPredicate | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _predicate;
    get predicate(): ServiceIntegrationEmailParserMatchPredicatePredicateList;
    putPredicate(value: ServiceIntegrationEmailParserMatchPredicatePredicate[] | cdktf.IResolvable): void;
    resetPredicate(): void;
    get predicateInput(): cdktf.IResolvable | ServiceIntegrationEmailParserMatchPredicatePredicate[] | undefined;
}
export interface ServiceIntegrationEmailParserValueExtractor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#ends_before ServiceIntegration#ends_before}
    */
    readonly endsBefore?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#part ServiceIntegration#part}
    */
    readonly part: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#regex ServiceIntegration#regex}
    */
    readonly regex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#starts_after ServiceIntegration#starts_after}
    */
    readonly startsAfter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#type ServiceIntegration#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#value_name ServiceIntegration#value_name}
    */
    readonly valueName: string;
}
export declare function serviceIntegrationEmailParserValueExtractorToTerraform(struct?: ServiceIntegrationEmailParserValueExtractor | cdktf.IResolvable): any;
export declare function serviceIntegrationEmailParserValueExtractorToHclTerraform(struct?: ServiceIntegrationEmailParserValueExtractor | cdktf.IResolvable): any;
export declare class ServiceIntegrationEmailParserValueExtractorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceIntegrationEmailParserValueExtractor | cdktf.IResolvable | undefined;
    set internalValue(value: ServiceIntegrationEmailParserValueExtractor | cdktf.IResolvable | undefined);
    private _endsBefore?;
    get endsBefore(): string;
    set endsBefore(value: string);
    resetEndsBefore(): void;
    get endsBeforeInput(): string | undefined;
    private _part?;
    get part(): string;
    set part(value: string);
    get partInput(): string | undefined;
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
    private _startsAfter?;
    get startsAfter(): string;
    set startsAfter(value: string);
    resetStartsAfter(): void;
    get startsAfterInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _valueName?;
    get valueName(): string;
    set valueName(value: string);
    get valueNameInput(): string | undefined;
}
export declare class ServiceIntegrationEmailParserValueExtractorList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceIntegrationEmailParserValueExtractor[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceIntegrationEmailParserValueExtractorOutputReference;
}
export interface ServiceIntegrationEmailParser {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#action ServiceIntegration#action}
    */
    readonly action: string;
    /**
    * match_predicate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#match_predicate ServiceIntegration#match_predicate}
    */
    readonly matchPredicate: ServiceIntegrationEmailParserMatchPredicate;
    /**
    * value_extractor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#value_extractor ServiceIntegration#value_extractor}
    */
    readonly valueExtractor?: ServiceIntegrationEmailParserValueExtractor[] | cdktf.IResolvable;
}
export declare function serviceIntegrationEmailParserToTerraform(struct?: ServiceIntegrationEmailParser | cdktf.IResolvable): any;
export declare function serviceIntegrationEmailParserToHclTerraform(struct?: ServiceIntegrationEmailParser | cdktf.IResolvable): any;
export declare class ServiceIntegrationEmailParserOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceIntegrationEmailParser | cdktf.IResolvable | undefined;
    set internalValue(value: ServiceIntegrationEmailParser | cdktf.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    get id(): number;
    private _matchPredicate;
    get matchPredicate(): ServiceIntegrationEmailParserMatchPredicateOutputReference;
    putMatchPredicate(value: ServiceIntegrationEmailParserMatchPredicate): void;
    get matchPredicateInput(): ServiceIntegrationEmailParserMatchPredicate | undefined;
    private _valueExtractor;
    get valueExtractor(): ServiceIntegrationEmailParserValueExtractorList;
    putValueExtractor(value: ServiceIntegrationEmailParserValueExtractor[] | cdktf.IResolvable): void;
    resetValueExtractor(): void;
    get valueExtractorInput(): cdktf.IResolvable | ServiceIntegrationEmailParserValueExtractor[] | undefined;
}
export declare class ServiceIntegrationEmailParserList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceIntegrationEmailParser[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceIntegrationEmailParserOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration pagerduty_service_integration}
*/
export declare class ServiceIntegration extends cdktf.TerraformResource {
    static readonly tfResourceType = "pagerduty_service_integration";
    /**
    * Generates CDKTF code for importing a ServiceIntegration resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServiceIntegration to import
    * @param importFromId The id of the existing ServiceIntegration that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServiceIntegration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_integration pagerduty_service_integration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServiceIntegrationConfig
    */
    constructor(scope: Construct, id: string, config: ServiceIntegrationConfig);
    private _emailFilterMode?;
    get emailFilterMode(): string;
    set emailFilterMode(value: string);
    resetEmailFilterMode(): void;
    get emailFilterModeInput(): string | undefined;
    private _emailIncidentCreation?;
    get emailIncidentCreation(): string;
    set emailIncidentCreation(value: string);
    resetEmailIncidentCreation(): void;
    get emailIncidentCreationInput(): string | undefined;
    private _emailParsingFallback?;
    get emailParsingFallback(): string;
    set emailParsingFallback(value: string);
    resetEmailParsingFallback(): void;
    get emailParsingFallbackInput(): string | undefined;
    get htmlUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _integrationEmail?;
    get integrationEmail(): string;
    set integrationEmail(value: string);
    resetIntegrationEmail(): void;
    get integrationEmailInput(): string | undefined;
    private _integrationKey?;
    get integrationKey(): string;
    set integrationKey(value: string);
    resetIntegrationKey(): void;
    get integrationKeyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _vendor?;
    get vendor(): string;
    set vendor(value: string);
    resetVendor(): void;
    get vendorInput(): string | undefined;
    private _emailFilter;
    get emailFilter(): ServiceIntegrationEmailFilterList;
    putEmailFilter(value: ServiceIntegrationEmailFilter[] | cdktf.IResolvable): void;
    resetEmailFilter(): void;
    get emailFilterInput(): cdktf.IResolvable | ServiceIntegrationEmailFilter[] | undefined;
    private _emailParser;
    get emailParser(): ServiceIntegrationEmailParserList;
    putEmailParser(value: ServiceIntegrationEmailParser[] | cdktf.IResolvable): void;
    resetEmailParser(): void;
    get emailParserInput(): cdktf.IResolvable | ServiceIntegrationEmailParser[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
