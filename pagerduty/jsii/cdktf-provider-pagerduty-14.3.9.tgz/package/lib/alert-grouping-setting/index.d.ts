/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AlertGroupingSettingConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/alert_grouping_setting#description AlertGroupingSetting#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/alert_grouping_setting#name AlertGroupingSetting#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/alert_grouping_setting#services AlertGroupingSetting#services}
    */
    readonly services: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/alert_grouping_setting#type AlertGroupingSetting#type}
    */
    readonly type: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/alert_grouping_setting#config AlertGroupingSetting#config}
    */
    readonly config?: AlertGroupingSettingConfigA;
}
export interface AlertGroupingSettingConfigA {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/alert_grouping_setting#aggregate AlertGroupingSetting#aggregate}
    */
    readonly aggregate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/alert_grouping_setting#fields AlertGroupingSetting#fields}
    */
    readonly fields?: string[];
    /**
    * An array of strings which represent the iag fields with which to intelligently group against
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/alert_grouping_setting#iag_fields AlertGroupingSetting#iag_fields}
    */
    readonly iagFields?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/alert_grouping_setting#time_window AlertGroupingSetting#time_window}
    */
    readonly timeWindow?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/alert_grouping_setting#timeout AlertGroupingSetting#timeout}
    */
    readonly timeout?: number;
}
export declare function alertGroupingSettingConfigAToTerraform(struct?: AlertGroupingSettingConfigA | cdktf.IResolvable): any;
export declare function alertGroupingSettingConfigAToHclTerraform(struct?: AlertGroupingSettingConfigA | cdktf.IResolvable): any;
export declare class AlertGroupingSettingConfigAOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertGroupingSettingConfigA | cdktf.IResolvable | undefined;
    set internalValue(value: AlertGroupingSettingConfigA | cdktf.IResolvable | undefined);
    private _aggregate?;
    get aggregate(): string;
    set aggregate(value: string);
    resetAggregate(): void;
    get aggregateInput(): string | undefined;
    private _fields?;
    get fields(): string[];
    set fields(value: string[]);
    resetFields(): void;
    get fieldsInput(): string[] | undefined;
    private _iagFields?;
    get iagFields(): string[];
    set iagFields(value: string[]);
    resetIagFields(): void;
    get iagFieldsInput(): string[] | undefined;
    private _timeWindow?;
    get timeWindow(): number;
    set timeWindow(value: number);
    resetTimeWindow(): void;
    get timeWindowInput(): number | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/alert_grouping_setting pagerduty_alert_grouping_setting}
*/
export declare class AlertGroupingSetting extends cdktf.TerraformResource {
    static readonly tfResourceType = "pagerduty_alert_grouping_setting";
    /**
    * Generates CDKTF code for importing a AlertGroupingSetting resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlertGroupingSetting to import
    * @param importFromId The id of the existing AlertGroupingSetting that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/alert_grouping_setting#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlertGroupingSetting to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/alert_grouping_setting pagerduty_alert_grouping_setting} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlertGroupingSettingConfig
    */
    constructor(scope: Construct, id: string, config: AlertGroupingSettingConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _services?;
    get services(): string[];
    set services(value: string[]);
    get servicesInput(): string[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _config;
    get config(): AlertGroupingSettingConfigAOutputReference;
    putConfig(value: AlertGroupingSettingConfigA): void;
    resetConfig(): void;
    get configInput(): AlertGroupingSettingConfigA | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
