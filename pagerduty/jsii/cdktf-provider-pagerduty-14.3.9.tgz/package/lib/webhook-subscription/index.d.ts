/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface WebhookSubscriptionConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/webhook_subscription#active WebhookSubscription#active}
    */
    readonly active?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/webhook_subscription#description WebhookSubscription#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/webhook_subscription#events WebhookSubscription#events}
    */
    readonly events: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/webhook_subscription#id WebhookSubscription#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/webhook_subscription#type WebhookSubscription#type}
    */
    readonly type?: string;
    /**
    * delivery_method block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/webhook_subscription#delivery_method WebhookSubscription#delivery_method}
    */
    readonly deliveryMethod: WebhookSubscriptionDeliveryMethod[] | cdktf.IResolvable;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/webhook_subscription#filter WebhookSubscription#filter}
    */
    readonly filter: WebhookSubscriptionFilter[] | cdktf.IResolvable;
}
export interface WebhookSubscriptionDeliveryMethodCustomHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/webhook_subscription#name WebhookSubscription#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/webhook_subscription#value WebhookSubscription#value}
    */
    readonly value: string;
}
export declare function webhookSubscriptionDeliveryMethodCustomHeaderToTerraform(struct?: WebhookSubscriptionDeliveryMethodCustomHeader | cdktf.IResolvable): any;
export declare function webhookSubscriptionDeliveryMethodCustomHeaderToHclTerraform(struct?: WebhookSubscriptionDeliveryMethodCustomHeader | cdktf.IResolvable): any;
export declare class WebhookSubscriptionDeliveryMethodCustomHeaderOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WebhookSubscriptionDeliveryMethodCustomHeader | cdktf.IResolvable | undefined;
    set internalValue(value: WebhookSubscriptionDeliveryMethodCustomHeader | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class WebhookSubscriptionDeliveryMethodCustomHeaderList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WebhookSubscriptionDeliveryMethodCustomHeader[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WebhookSubscriptionDeliveryMethodCustomHeaderOutputReference;
}
export interface WebhookSubscriptionDeliveryMethod {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/webhook_subscription#temporarily_disabled WebhookSubscription#temporarily_disabled}
    */
    readonly temporarilyDisabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/webhook_subscription#type WebhookSubscription#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/webhook_subscription#url WebhookSubscription#url}
    */
    readonly url?: string;
    /**
    * custom_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/webhook_subscription#custom_header WebhookSubscription#custom_header}
    */
    readonly customHeader?: WebhookSubscriptionDeliveryMethodCustomHeader[] | cdktf.IResolvable;
}
export declare function webhookSubscriptionDeliveryMethodToTerraform(struct?: WebhookSubscriptionDeliveryMethod | cdktf.IResolvable): any;
export declare function webhookSubscriptionDeliveryMethodToHclTerraform(struct?: WebhookSubscriptionDeliveryMethod | cdktf.IResolvable): any;
export declare class WebhookSubscriptionDeliveryMethodOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WebhookSubscriptionDeliveryMethod | cdktf.IResolvable | undefined;
    set internalValue(value: WebhookSubscriptionDeliveryMethod | cdktf.IResolvable | undefined);
    private _temporarilyDisabled?;
    get temporarilyDisabled(): boolean | cdktf.IResolvable;
    set temporarilyDisabled(value: boolean | cdktf.IResolvable);
    resetTemporarilyDisabled(): void;
    get temporarilyDisabledInput(): boolean | cdktf.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _customHeader;
    get customHeader(): WebhookSubscriptionDeliveryMethodCustomHeaderList;
    putCustomHeader(value: WebhookSubscriptionDeliveryMethodCustomHeader[] | cdktf.IResolvable): void;
    resetCustomHeader(): void;
    get customHeaderInput(): cdktf.IResolvable | WebhookSubscriptionDeliveryMethodCustomHeader[] | undefined;
}
export declare class WebhookSubscriptionDeliveryMethodList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WebhookSubscriptionDeliveryMethod[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WebhookSubscriptionDeliveryMethodOutputReference;
}
export interface WebhookSubscriptionFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/webhook_subscription#id WebhookSubscription#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/webhook_subscription#type WebhookSubscription#type}
    */
    readonly type: string;
}
export declare function webhookSubscriptionFilterToTerraform(struct?: WebhookSubscriptionFilter | cdktf.IResolvable): any;
export declare function webhookSubscriptionFilterToHclTerraform(struct?: WebhookSubscriptionFilter | cdktf.IResolvable): any;
export declare class WebhookSubscriptionFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WebhookSubscriptionFilter | cdktf.IResolvable | undefined;
    set internalValue(value: WebhookSubscriptionFilter | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class WebhookSubscriptionFilterList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WebhookSubscriptionFilter[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WebhookSubscriptionFilterOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/webhook_subscription pagerduty_webhook_subscription}
*/
export declare class WebhookSubscription extends cdktf.TerraformResource {
    static readonly tfResourceType = "pagerduty_webhook_subscription";
    /**
    * Generates CDKTF code for importing a WebhookSubscription resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WebhookSubscription to import
    * @param importFromId The id of the existing WebhookSubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/webhook_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WebhookSubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/webhook_subscription pagerduty_webhook_subscription} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WebhookSubscriptionConfig
    */
    constructor(scope: Construct, id: string, config: WebhookSubscriptionConfig);
    private _active?;
    get active(): boolean | cdktf.IResolvable;
    set active(value: boolean | cdktf.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktf.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _events?;
    get events(): string[];
    set events(value: string[]);
    get eventsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _deliveryMethod;
    get deliveryMethod(): WebhookSubscriptionDeliveryMethodList;
    putDeliveryMethod(value: WebhookSubscriptionDeliveryMethod[] | cdktf.IResolvable): void;
    get deliveryMethodInput(): cdktf.IResolvable | WebhookSubscriptionDeliveryMethod[] | undefined;
    private _filter;
    get filter(): WebhookSubscriptionFilterList;
    putFilter(value: WebhookSubscriptionFilter[] | cdktf.IResolvable): void;
    get filterInput(): cdktf.IResolvable | WebhookSubscriptionFilter[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
