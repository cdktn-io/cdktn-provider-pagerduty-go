/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataPagerdutyServiceIntegrationConfig extends cdktf.TerraformMetaArguments {
    /**
    * examples "Amazon CloudWatch", "New Relic"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/data-sources/service_integration#integration_summary DataPagerdutyServiceIntegration#integration_summary}
    */
    readonly integrationSummary: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/data-sources/service_integration#service_name DataPagerdutyServiceIntegration#service_name}
    */
    readonly serviceName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/data-sources/service_integration pagerduty_service_integration}
*/
export declare class DataPagerdutyServiceIntegration extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_service_integration";
    /**
    * Generates CDKTF code for importing a DataPagerdutyServiceIntegration resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyServiceIntegration to import
    * @param importFromId The id of the existing DataPagerdutyServiceIntegration that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/data-sources/service_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyServiceIntegration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/data-sources/service_integration pagerduty_service_integration} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyServiceIntegrationConfig
    */
    constructor(scope: Construct, id: string, config: DataPagerdutyServiceIntegrationConfig);
    get id(): string;
    get integrationKey(): string;
    private _integrationSummary?;
    get integrationSummary(): string;
    set integrationSummary(value: string);
    get integrationSummaryInput(): string | undefined;
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    get serviceNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
