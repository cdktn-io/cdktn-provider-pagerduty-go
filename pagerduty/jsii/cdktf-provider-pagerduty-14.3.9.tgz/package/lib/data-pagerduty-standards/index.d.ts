/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataPagerdutyStandardsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/data-sources/standards#resource_type DataPagerdutyStandards#resource_type}
    */
    readonly resourceType?: string;
}
export interface DataPagerdutyStandardsStandardsExclusions {
}
export declare function dataPagerdutyStandardsStandardsExclusionsToTerraform(struct?: DataPagerdutyStandardsStandardsExclusions): any;
export declare function dataPagerdutyStandardsStandardsExclusionsToHclTerraform(struct?: DataPagerdutyStandardsStandardsExclusions): any;
export declare class DataPagerdutyStandardsStandardsExclusionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyStandardsStandardsExclusions | undefined;
    set internalValue(value: DataPagerdutyStandardsStandardsExclusions | undefined);
    get id(): string;
    get type(): string;
}
export declare class DataPagerdutyStandardsStandardsExclusionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyStandardsStandardsExclusionsOutputReference;
}
export interface DataPagerdutyStandardsStandardsInclusions {
}
export declare function dataPagerdutyStandardsStandardsInclusionsToTerraform(struct?: DataPagerdutyStandardsStandardsInclusions): any;
export declare function dataPagerdutyStandardsStandardsInclusionsToHclTerraform(struct?: DataPagerdutyStandardsStandardsInclusions): any;
export declare class DataPagerdutyStandardsStandardsInclusionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyStandardsStandardsInclusions | undefined;
    set internalValue(value: DataPagerdutyStandardsStandardsInclusions | undefined);
    get id(): string;
    get type(): string;
}
export declare class DataPagerdutyStandardsStandardsInclusionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyStandardsStandardsInclusionsOutputReference;
}
export interface DataPagerdutyStandardsStandards {
}
export declare function dataPagerdutyStandardsStandardsToTerraform(struct?: DataPagerdutyStandardsStandards): any;
export declare function dataPagerdutyStandardsStandardsToHclTerraform(struct?: DataPagerdutyStandardsStandards): any;
export declare class DataPagerdutyStandardsStandardsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyStandardsStandards | undefined;
    set internalValue(value: DataPagerdutyStandardsStandards | undefined);
    get active(): cdktf.IResolvable;
    get description(): string;
    private _exclusions;
    get exclusions(): DataPagerdutyStandardsStandardsExclusionsList;
    get id(): string;
    private _inclusions;
    get inclusions(): DataPagerdutyStandardsStandardsInclusionsList;
    get name(): string;
    get resourceType(): string;
    get type(): string;
}
export declare class DataPagerdutyStandardsStandardsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyStandardsStandardsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/data-sources/standards pagerduty_standards}
*/
export declare class DataPagerdutyStandards extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_standards";
    /**
    * Generates CDKTF code for importing a DataPagerdutyStandards resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyStandards to import
    * @param importFromId The id of the existing DataPagerdutyStandards that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/data-sources/standards#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyStandards to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/data-sources/standards pagerduty_standards} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyStandardsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataPagerdutyStandardsConfig);
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    resetResourceType(): void;
    get resourceTypeInput(): string | undefined;
    private _standards;
    get standards(): DataPagerdutyStandardsStandardsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
