/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface UserContactMethodConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/user_contact_method#address UserContactMethod#address}
    */
    readonly address: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/user_contact_method#country_code UserContactMethod#country_code}
    */
    readonly countryCode?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/user_contact_method#device_type UserContactMethod#device_type}
    */
    readonly deviceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/user_contact_method#label UserContactMethod#label}
    */
    readonly label: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/user_contact_method#send_short_email UserContactMethod#send_short_email}
    */
    readonly sendShortEmail?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/user_contact_method#type UserContactMethod#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/user_contact_method#user_id UserContactMethod#user_id}
    */
    readonly userId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/user_contact_method pagerduty_user_contact_method}
*/
export declare class UserContactMethod extends cdktf.TerraformResource {
    static readonly tfResourceType = "pagerduty_user_contact_method";
    /**
    * Generates CDKTF code for importing a UserContactMethod resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UserContactMethod to import
    * @param importFromId The id of the existing UserContactMethod that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/user_contact_method#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UserContactMethod to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/user_contact_method pagerduty_user_contact_method} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UserContactMethodConfig
    */
    constructor(scope: Construct, id: string, config: UserContactMethodConfig);
    private _address?;
    get address(): string;
    set address(value: string);
    get addressInput(): string | undefined;
    get blacklisted(): cdktf.IResolvable;
    private _countryCode?;
    get countryCode(): number;
    set countryCode(value: number);
    resetCountryCode(): void;
    get countryCodeInput(): number | undefined;
    private _deviceType?;
    get deviceType(): string;
    set deviceType(value: string);
    resetDeviceType(): void;
    get deviceTypeInput(): string | undefined;
    get enabled(): cdktf.IResolvable;
    get id(): string;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    private _sendShortEmail?;
    get sendShortEmail(): boolean | cdktf.IResolvable;
    set sendShortEmail(value: boolean | cdktf.IResolvable);
    resetSendShortEmail(): void;
    get sendShortEmailInput(): boolean | cdktf.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
