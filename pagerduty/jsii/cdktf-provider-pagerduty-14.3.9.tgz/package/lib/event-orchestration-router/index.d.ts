/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface EventOrchestrationRouterConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#event_orchestration EventOrchestrationRouter#event_orchestration}
    */
    readonly eventOrchestration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#id EventOrchestrationRouter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * catch_all block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#catch_all EventOrchestrationRouter#catch_all}
    */
    readonly catchAll: EventOrchestrationRouterCatchAll;
    /**
    * set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#set EventOrchestrationRouter#set}
    */
    readonly set: EventOrchestrationRouterSet;
}
export interface EventOrchestrationRouterCatchAllActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#route_to EventOrchestrationRouter#route_to}
    */
    readonly routeTo: string;
}
export declare function eventOrchestrationRouterCatchAllActionsToTerraform(struct?: EventOrchestrationRouterCatchAllActionsOutputReference | EventOrchestrationRouterCatchAllActions): any;
export declare function eventOrchestrationRouterCatchAllActionsToHclTerraform(struct?: EventOrchestrationRouterCatchAllActionsOutputReference | EventOrchestrationRouterCatchAllActions): any;
export declare class EventOrchestrationRouterCatchAllActionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationRouterCatchAllActions | undefined;
    set internalValue(value: EventOrchestrationRouterCatchAllActions | undefined);
    private _routeTo?;
    get routeTo(): string;
    set routeTo(value: string);
    get routeToInput(): string | undefined;
}
export interface EventOrchestrationRouterCatchAll {
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#actions EventOrchestrationRouter#actions}
    */
    readonly actions: EventOrchestrationRouterCatchAllActions;
}
export declare function eventOrchestrationRouterCatchAllToTerraform(struct?: EventOrchestrationRouterCatchAllOutputReference | EventOrchestrationRouterCatchAll): any;
export declare function eventOrchestrationRouterCatchAllToHclTerraform(struct?: EventOrchestrationRouterCatchAllOutputReference | EventOrchestrationRouterCatchAll): any;
export declare class EventOrchestrationRouterCatchAllOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationRouterCatchAll | undefined;
    set internalValue(value: EventOrchestrationRouterCatchAll | undefined);
    private _actions;
    get actions(): EventOrchestrationRouterCatchAllActionsOutputReference;
    putActions(value: EventOrchestrationRouterCatchAllActions): void;
    get actionsInput(): EventOrchestrationRouterCatchAllActions | undefined;
}
export interface EventOrchestrationRouterSetRuleActionsDynamicRouteTo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#lookup_by EventOrchestrationRouter#lookup_by}
    */
    readonly lookupBy: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#regex EventOrchestrationRouter#regex}
    */
    readonly regex: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#source EventOrchestrationRouter#source}
    */
    readonly source: string;
}
export declare function eventOrchestrationRouterSetRuleActionsDynamicRouteToToTerraform(struct?: EventOrchestrationRouterSetRuleActionsDynamicRouteTo | cdktf.IResolvable): any;
export declare function eventOrchestrationRouterSetRuleActionsDynamicRouteToToHclTerraform(struct?: EventOrchestrationRouterSetRuleActionsDynamicRouteTo | cdktf.IResolvable): any;
export declare class EventOrchestrationRouterSetRuleActionsDynamicRouteToOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationRouterSetRuleActionsDynamicRouteTo | cdktf.IResolvable | undefined;
    set internalValue(value: EventOrchestrationRouterSetRuleActionsDynamicRouteTo | cdktf.IResolvable | undefined);
    private _lookupBy?;
    get lookupBy(): string;
    set lookupBy(value: string);
    get lookupByInput(): string | undefined;
    private _regex?;
    get regex(): string;
    set regex(value: string);
    get regexInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
}
export declare class EventOrchestrationRouterSetRuleActionsDynamicRouteToList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationRouterSetRuleActionsDynamicRouteTo[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationRouterSetRuleActionsDynamicRouteToOutputReference;
}
export interface EventOrchestrationRouterSetRuleActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#route_to EventOrchestrationRouter#route_to}
    */
    readonly routeTo?: string;
    /**
    * dynamic_route_to block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#dynamic_route_to EventOrchestrationRouter#dynamic_route_to}
    */
    readonly dynamicRouteTo?: EventOrchestrationRouterSetRuleActionsDynamicRouteTo[] | cdktf.IResolvable;
}
export declare function eventOrchestrationRouterSetRuleActionsToTerraform(struct?: EventOrchestrationRouterSetRuleActionsOutputReference | EventOrchestrationRouterSetRuleActions): any;
export declare function eventOrchestrationRouterSetRuleActionsToHclTerraform(struct?: EventOrchestrationRouterSetRuleActionsOutputReference | EventOrchestrationRouterSetRuleActions): any;
export declare class EventOrchestrationRouterSetRuleActionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationRouterSetRuleActions | undefined;
    set internalValue(value: EventOrchestrationRouterSetRuleActions | undefined);
    private _routeTo?;
    get routeTo(): string;
    set routeTo(value: string);
    resetRouteTo(): void;
    get routeToInput(): string | undefined;
    private _dynamicRouteTo;
    get dynamicRouteTo(): EventOrchestrationRouterSetRuleActionsDynamicRouteToList;
    putDynamicRouteTo(value: EventOrchestrationRouterSetRuleActionsDynamicRouteTo[] | cdktf.IResolvable): void;
    resetDynamicRouteTo(): void;
    get dynamicRouteToInput(): cdktf.IResolvable | EventOrchestrationRouterSetRuleActionsDynamicRouteTo[] | undefined;
}
export interface EventOrchestrationRouterSetRuleCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#expression EventOrchestrationRouter#expression}
    */
    readonly expression: string;
}
export declare function eventOrchestrationRouterSetRuleConditionToTerraform(struct?: EventOrchestrationRouterSetRuleCondition | cdktf.IResolvable): any;
export declare function eventOrchestrationRouterSetRuleConditionToHclTerraform(struct?: EventOrchestrationRouterSetRuleCondition | cdktf.IResolvable): any;
export declare class EventOrchestrationRouterSetRuleConditionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationRouterSetRuleCondition | cdktf.IResolvable | undefined;
    set internalValue(value: EventOrchestrationRouterSetRuleCondition | cdktf.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export declare class EventOrchestrationRouterSetRuleConditionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationRouterSetRuleCondition[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationRouterSetRuleConditionOutputReference;
}
export interface EventOrchestrationRouterSetRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#disabled EventOrchestrationRouter#disabled}
    */
    readonly disabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#label EventOrchestrationRouter#label}
    */
    readonly label?: string;
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#actions EventOrchestrationRouter#actions}
    */
    readonly actions: EventOrchestrationRouterSetRuleActions;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#condition EventOrchestrationRouter#condition}
    */
    readonly condition?: EventOrchestrationRouterSetRuleCondition[] | cdktf.IResolvable;
}
export declare function eventOrchestrationRouterSetRuleToTerraform(struct?: EventOrchestrationRouterSetRule | cdktf.IResolvable): any;
export declare function eventOrchestrationRouterSetRuleToHclTerraform(struct?: EventOrchestrationRouterSetRule | cdktf.IResolvable): any;
export declare class EventOrchestrationRouterSetRuleOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationRouterSetRule | cdktf.IResolvable | undefined;
    set internalValue(value: EventOrchestrationRouterSetRule | cdktf.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktf.IResolvable;
    set disabled(value: boolean | cdktf.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _actions;
    get actions(): EventOrchestrationRouterSetRuleActionsOutputReference;
    putActions(value: EventOrchestrationRouterSetRuleActions): void;
    get actionsInput(): EventOrchestrationRouterSetRuleActions | undefined;
    private _condition;
    get condition(): EventOrchestrationRouterSetRuleConditionList;
    putCondition(value: EventOrchestrationRouterSetRuleCondition[] | cdktf.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktf.IResolvable | EventOrchestrationRouterSetRuleCondition[] | undefined;
}
export declare class EventOrchestrationRouterSetRuleList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationRouterSetRule[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationRouterSetRuleOutputReference;
}
export interface EventOrchestrationRouterSet {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#id EventOrchestrationRouter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#rule EventOrchestrationRouter#rule}
    */
    readonly rule?: EventOrchestrationRouterSetRule[] | cdktf.IResolvable;
}
export declare function eventOrchestrationRouterSetToTerraform(struct?: EventOrchestrationRouterSetOutputReference | EventOrchestrationRouterSet): any;
export declare function eventOrchestrationRouterSetToHclTerraform(struct?: EventOrchestrationRouterSetOutputReference | EventOrchestrationRouterSet): any;
export declare class EventOrchestrationRouterSetOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationRouterSet | undefined;
    set internalValue(value: EventOrchestrationRouterSet | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _rule;
    get rule(): EventOrchestrationRouterSetRuleList;
    putRule(value: EventOrchestrationRouterSetRule[] | cdktf.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktf.IResolvable | EventOrchestrationRouterSetRule[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router pagerduty_event_orchestration_router}
*/
export declare class EventOrchestrationRouter extends cdktf.TerraformResource {
    static readonly tfResourceType = "pagerduty_event_orchestration_router";
    /**
    * Generates CDKTF code for importing a EventOrchestrationRouter resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EventOrchestrationRouter to import
    * @param importFromId The id of the existing EventOrchestrationRouter that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EventOrchestrationRouter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_router pagerduty_event_orchestration_router} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EventOrchestrationRouterConfig
    */
    constructor(scope: Construct, id: string, config: EventOrchestrationRouterConfig);
    private _eventOrchestration?;
    get eventOrchestration(): string;
    set eventOrchestration(value: string);
    get eventOrchestrationInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _catchAll;
    get catchAll(): EventOrchestrationRouterCatchAllOutputReference;
    putCatchAll(value: EventOrchestrationRouterCatchAll): void;
    get catchAllInput(): EventOrchestrationRouterCatchAll | undefined;
    private _set;
    get set(): EventOrchestrationRouterSetOutputReference;
    putSet(value: EventOrchestrationRouterSet): void;
    get setInput(): EventOrchestrationRouterSet | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
