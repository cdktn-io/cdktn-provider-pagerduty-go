/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface EventOrchestrationGlobalCacheVariableConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global_cache_variable#disabled EventOrchestrationGlobalCacheVariable#disabled}
    */
    readonly disabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global_cache_variable#event_orchestration EventOrchestrationGlobalCacheVariable#event_orchestration}
    */
    readonly eventOrchestration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global_cache_variable#name EventOrchestrationGlobalCacheVariable#name}
    */
    readonly name: string;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global_cache_variable#condition EventOrchestrationGlobalCacheVariable#condition}
    */
    readonly condition?: EventOrchestrationGlobalCacheVariableCondition[] | cdktf.IResolvable;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global_cache_variable#configuration EventOrchestrationGlobalCacheVariable#configuration}
    */
    readonly configuration: EventOrchestrationGlobalCacheVariableConfiguration;
}
export interface EventOrchestrationGlobalCacheVariableCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global_cache_variable#expression EventOrchestrationGlobalCacheVariable#expression}
    */
    readonly expression: string;
}
export declare function eventOrchestrationGlobalCacheVariableConditionToTerraform(struct?: EventOrchestrationGlobalCacheVariableCondition | cdktf.IResolvable): any;
export declare function eventOrchestrationGlobalCacheVariableConditionToHclTerraform(struct?: EventOrchestrationGlobalCacheVariableCondition | cdktf.IResolvable): any;
export declare class EventOrchestrationGlobalCacheVariableConditionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalCacheVariableCondition | cdktf.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalCacheVariableCondition | cdktf.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export declare class EventOrchestrationGlobalCacheVariableConditionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalCacheVariableCondition[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalCacheVariableConditionOutputReference;
}
export interface EventOrchestrationGlobalCacheVariableConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global_cache_variable#data_type EventOrchestrationGlobalCacheVariable#data_type}
    */
    readonly dataType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global_cache_variable#regex EventOrchestrationGlobalCacheVariable#regex}
    */
    readonly regex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global_cache_variable#source EventOrchestrationGlobalCacheVariable#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global_cache_variable#ttl_seconds EventOrchestrationGlobalCacheVariable#ttl_seconds}
    */
    readonly ttlSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global_cache_variable#type EventOrchestrationGlobalCacheVariable#type}
    */
    readonly type: string;
}
export declare function eventOrchestrationGlobalCacheVariableConfigurationToTerraform(struct?: EventOrchestrationGlobalCacheVariableConfigurationOutputReference | EventOrchestrationGlobalCacheVariableConfiguration): any;
export declare function eventOrchestrationGlobalCacheVariableConfigurationToHclTerraform(struct?: EventOrchestrationGlobalCacheVariableConfigurationOutputReference | EventOrchestrationGlobalCacheVariableConfiguration): any;
export declare class EventOrchestrationGlobalCacheVariableConfigurationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationGlobalCacheVariableConfiguration | undefined;
    set internalValue(value: EventOrchestrationGlobalCacheVariableConfiguration | undefined);
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    resetDataType(): void;
    get dataTypeInput(): string | undefined;
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _ttlSeconds?;
    get ttlSeconds(): number;
    set ttlSeconds(value: number);
    resetTtlSeconds(): void;
    get ttlSecondsInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global_cache_variable pagerduty_event_orchestration_global_cache_variable}
*/
export declare class EventOrchestrationGlobalCacheVariable extends cdktf.TerraformResource {
    static readonly tfResourceType = "pagerduty_event_orchestration_global_cache_variable";
    /**
    * Generates CDKTF code for importing a EventOrchestrationGlobalCacheVariable resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EventOrchestrationGlobalCacheVariable to import
    * @param importFromId The id of the existing EventOrchestrationGlobalCacheVariable that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global_cache_variable#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EventOrchestrationGlobalCacheVariable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global_cache_variable pagerduty_event_orchestration_global_cache_variable} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EventOrchestrationGlobalCacheVariableConfig
    */
    constructor(scope: Construct, id: string, config: EventOrchestrationGlobalCacheVariableConfig);
    private _disabled?;
    get disabled(): boolean | cdktf.IResolvable;
    set disabled(value: boolean | cdktf.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktf.IResolvable | undefined;
    private _eventOrchestration?;
    get eventOrchestration(): string;
    set eventOrchestration(value: string);
    get eventOrchestrationInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _condition;
    get condition(): EventOrchestrationGlobalCacheVariableConditionList;
    putCondition(value: EventOrchestrationGlobalCacheVariableCondition[] | cdktf.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktf.IResolvable | EventOrchestrationGlobalCacheVariableCondition[] | undefined;
    private _configuration;
    get configuration(): EventOrchestrationGlobalCacheVariableConfigurationOutputReference;
    putConfiguration(value: EventOrchestrationGlobalCacheVariableConfiguration): void;
    get configurationInput(): EventOrchestrationGlobalCacheVariableConfiguration | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
