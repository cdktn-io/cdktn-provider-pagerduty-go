/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ServiceDependencyConfig extends cdktf.TerraformMetaArguments {
    /**
    * dependency block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_dependency#dependency ServiceDependency#dependency}
    */
    readonly dependency?: ServiceDependencyDependency[] | cdktf.IResolvable;
}
export interface ServiceDependencyDependencyDependentService {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_dependency#id ServiceDependency#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_dependency#type ServiceDependency#type}
    */
    readonly type: string;
}
export declare function serviceDependencyDependencyDependentServiceToTerraform(struct?: ServiceDependencyDependencyDependentService | cdktf.IResolvable): any;
export declare function serviceDependencyDependencyDependentServiceToHclTerraform(struct?: ServiceDependencyDependencyDependentService | cdktf.IResolvable): any;
export declare class ServiceDependencyDependencyDependentServiceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceDependencyDependencyDependentService | cdktf.IResolvable | undefined;
    set internalValue(value: ServiceDependencyDependencyDependentService | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ServiceDependencyDependencyDependentServiceList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceDependencyDependencyDependentService[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceDependencyDependencyDependentServiceOutputReference;
}
export interface ServiceDependencyDependencySupportingService {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_dependency#id ServiceDependency#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_dependency#type ServiceDependency#type}
    */
    readonly type: string;
}
export declare function serviceDependencyDependencySupportingServiceToTerraform(struct?: ServiceDependencyDependencySupportingService | cdktf.IResolvable): any;
export declare function serviceDependencyDependencySupportingServiceToHclTerraform(struct?: ServiceDependencyDependencySupportingService | cdktf.IResolvable): any;
export declare class ServiceDependencyDependencySupportingServiceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceDependencyDependencySupportingService | cdktf.IResolvable | undefined;
    set internalValue(value: ServiceDependencyDependencySupportingService | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ServiceDependencyDependencySupportingServiceList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceDependencyDependencySupportingService[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceDependencyDependencySupportingServiceOutputReference;
}
export interface ServiceDependencyDependency {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_dependency#type ServiceDependency#type}
    */
    readonly type?: string;
    /**
    * dependent_service block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_dependency#dependent_service ServiceDependency#dependent_service}
    */
    readonly dependentService?: ServiceDependencyDependencyDependentService[] | cdktf.IResolvable;
    /**
    * supporting_service block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_dependency#supporting_service ServiceDependency#supporting_service}
    */
    readonly supportingService?: ServiceDependencyDependencySupportingService[] | cdktf.IResolvable;
}
export declare function serviceDependencyDependencyToTerraform(struct?: ServiceDependencyDependency | cdktf.IResolvable): any;
export declare function serviceDependencyDependencyToHclTerraform(struct?: ServiceDependencyDependency | cdktf.IResolvable): any;
export declare class ServiceDependencyDependencyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceDependencyDependency | cdktf.IResolvable | undefined;
    set internalValue(value: ServiceDependencyDependency | cdktf.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _dependentService;
    get dependentService(): ServiceDependencyDependencyDependentServiceList;
    putDependentService(value: ServiceDependencyDependencyDependentService[] | cdktf.IResolvable): void;
    resetDependentService(): void;
    get dependentServiceInput(): cdktf.IResolvable | ServiceDependencyDependencyDependentService[] | undefined;
    private _supportingService;
    get supportingService(): ServiceDependencyDependencySupportingServiceList;
    putSupportingService(value: ServiceDependencyDependencySupportingService[] | cdktf.IResolvable): void;
    resetSupportingService(): void;
    get supportingServiceInput(): cdktf.IResolvable | ServiceDependencyDependencySupportingService[] | undefined;
}
export declare class ServiceDependencyDependencyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceDependencyDependency[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceDependencyDependencyOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_dependency pagerduty_service_dependency}
*/
export declare class ServiceDependency extends cdktf.TerraformResource {
    static readonly tfResourceType = "pagerduty_service_dependency";
    /**
    * Generates CDKTF code for importing a ServiceDependency resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServiceDependency to import
    * @param importFromId The id of the existing ServiceDependency that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_dependency#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServiceDependency to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/service_dependency pagerduty_service_dependency} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServiceDependencyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ServiceDependencyConfig);
    get id(): string;
    private _dependency;
    get dependency(): ServiceDependencyDependencyList;
    putDependency(value: ServiceDependencyDependency[] | cdktf.IResolvable): void;
    resetDependency(): void;
    get dependencyInput(): cdktf.IResolvable | ServiceDependencyDependency[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
