/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RulesetRuleConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#catch_all RulesetRule#catch_all}
    */
    readonly catchAll?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#disabled RulesetRule#disabled}
    */
    readonly disabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#id RulesetRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#position RulesetRule#position}
    */
    readonly position?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#ruleset RulesetRule#ruleset}
    */
    readonly ruleset: string;
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#actions RulesetRule#actions}
    */
    readonly actions?: RulesetRuleActions;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#conditions RulesetRule#conditions}
    */
    readonly conditions?: RulesetRuleConditions;
    /**
    * time_frame block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#time_frame RulesetRule#time_frame}
    */
    readonly timeFrame?: RulesetRuleTimeFrame;
    /**
    * variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#variable RulesetRule#variable}
    */
    readonly variable?: RulesetRuleVariable[] | cdktf.IResolvable;
}
export interface RulesetRuleActionsAnnotate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#value RulesetRule#value}
    */
    readonly value?: string;
}
export declare function rulesetRuleActionsAnnotateToTerraform(struct?: RulesetRuleActionsAnnotate | cdktf.IResolvable): any;
export declare function rulesetRuleActionsAnnotateToHclTerraform(struct?: RulesetRuleActionsAnnotate | cdktf.IResolvable): any;
export declare class RulesetRuleActionsAnnotateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleActionsAnnotate | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRuleActionsAnnotate | cdktf.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRuleActionsAnnotateList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleActionsAnnotate[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleActionsAnnotateOutputReference;
}
export interface RulesetRuleActionsEventAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#value RulesetRule#value}
    */
    readonly value?: string;
}
export declare function rulesetRuleActionsEventActionToTerraform(struct?: RulesetRuleActionsEventAction | cdktf.IResolvable): any;
export declare function rulesetRuleActionsEventActionToHclTerraform(struct?: RulesetRuleActionsEventAction | cdktf.IResolvable): any;
export declare class RulesetRuleActionsEventActionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleActionsEventAction | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRuleActionsEventAction | cdktf.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRuleActionsEventActionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleActionsEventAction[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleActionsEventActionOutputReference;
}
export interface RulesetRuleActionsExtractions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#regex RulesetRule#regex}
    */
    readonly regex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#source RulesetRule#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#target RulesetRule#target}
    */
    readonly target?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#template RulesetRule#template}
    */
    readonly template?: string;
}
export declare function rulesetRuleActionsExtractionsToTerraform(struct?: RulesetRuleActionsExtractions | cdktf.IResolvable): any;
export declare function rulesetRuleActionsExtractionsToHclTerraform(struct?: RulesetRuleActionsExtractions | cdktf.IResolvable): any;
export declare class RulesetRuleActionsExtractionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleActionsExtractions | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRuleActionsExtractions | cdktf.IResolvable | undefined);
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    resetTemplate(): void;
    get templateInput(): string | undefined;
}
export declare class RulesetRuleActionsExtractionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleActionsExtractions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleActionsExtractionsOutputReference;
}
export interface RulesetRuleActionsPriority {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#value RulesetRule#value}
    */
    readonly value?: string;
}
export declare function rulesetRuleActionsPriorityToTerraform(struct?: RulesetRuleActionsPriority | cdktf.IResolvable): any;
export declare function rulesetRuleActionsPriorityToHclTerraform(struct?: RulesetRuleActionsPriority | cdktf.IResolvable): any;
export declare class RulesetRuleActionsPriorityOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleActionsPriority | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRuleActionsPriority | cdktf.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRuleActionsPriorityList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleActionsPriority[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleActionsPriorityOutputReference;
}
export interface RulesetRuleActionsRoute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#value RulesetRule#value}
    */
    readonly value?: string;
}
export declare function rulesetRuleActionsRouteToTerraform(struct?: RulesetRuleActionsRoute | cdktf.IResolvable): any;
export declare function rulesetRuleActionsRouteToHclTerraform(struct?: RulesetRuleActionsRoute | cdktf.IResolvable): any;
export declare class RulesetRuleActionsRouteOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleActionsRoute | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRuleActionsRoute | cdktf.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRuleActionsRouteList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleActionsRoute[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleActionsRouteOutputReference;
}
export interface RulesetRuleActionsSeverity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#value RulesetRule#value}
    */
    readonly value?: string;
}
export declare function rulesetRuleActionsSeverityToTerraform(struct?: RulesetRuleActionsSeverity | cdktf.IResolvable): any;
export declare function rulesetRuleActionsSeverityToHclTerraform(struct?: RulesetRuleActionsSeverity | cdktf.IResolvable): any;
export declare class RulesetRuleActionsSeverityOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleActionsSeverity | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRuleActionsSeverity | cdktf.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRuleActionsSeverityList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleActionsSeverity[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleActionsSeverityOutputReference;
}
export interface RulesetRuleActionsSuppress {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#threshold_time_amount RulesetRule#threshold_time_amount}
    */
    readonly thresholdTimeAmount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#threshold_time_unit RulesetRule#threshold_time_unit}
    */
    readonly thresholdTimeUnit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#threshold_value RulesetRule#threshold_value}
    */
    readonly thresholdValue?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#value RulesetRule#value}
    */
    readonly value?: boolean | cdktf.IResolvable;
}
export declare function rulesetRuleActionsSuppressToTerraform(struct?: RulesetRuleActionsSuppress | cdktf.IResolvable): any;
export declare function rulesetRuleActionsSuppressToHclTerraform(struct?: RulesetRuleActionsSuppress | cdktf.IResolvable): any;
export declare class RulesetRuleActionsSuppressOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleActionsSuppress | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRuleActionsSuppress | cdktf.IResolvable | undefined);
    private _thresholdTimeAmount?;
    get thresholdTimeAmount(): number;
    set thresholdTimeAmount(value: number);
    resetThresholdTimeAmount(): void;
    get thresholdTimeAmountInput(): number | undefined;
    private _thresholdTimeUnit?;
    get thresholdTimeUnit(): string;
    set thresholdTimeUnit(value: string);
    resetThresholdTimeUnit(): void;
    get thresholdTimeUnitInput(): string | undefined;
    private _thresholdValue?;
    get thresholdValue(): number;
    set thresholdValue(value: number);
    resetThresholdValue(): void;
    get thresholdValueInput(): number | undefined;
    private _value?;
    get value(): boolean | cdktf.IResolvable;
    set value(value: boolean | cdktf.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktf.IResolvable | undefined;
}
export declare class RulesetRuleActionsSuppressList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleActionsSuppress[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleActionsSuppressOutputReference;
}
export interface RulesetRuleActionsSuspend {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#value RulesetRule#value}
    */
    readonly value?: number;
}
export declare function rulesetRuleActionsSuspendToTerraform(struct?: RulesetRuleActionsSuspend | cdktf.IResolvable): any;
export declare function rulesetRuleActionsSuspendToHclTerraform(struct?: RulesetRuleActionsSuspend | cdktf.IResolvable): any;
export declare class RulesetRuleActionsSuspendOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleActionsSuspend | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRuleActionsSuspend | cdktf.IResolvable | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export declare class RulesetRuleActionsSuspendList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleActionsSuspend[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleActionsSuspendOutputReference;
}
export interface RulesetRuleActions {
    /**
    * annotate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#annotate RulesetRule#annotate}
    */
    readonly annotate?: RulesetRuleActionsAnnotate[] | cdktf.IResolvable;
    /**
    * event_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#event_action RulesetRule#event_action}
    */
    readonly eventAction?: RulesetRuleActionsEventAction[] | cdktf.IResolvable;
    /**
    * extractions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#extractions RulesetRule#extractions}
    */
    readonly extractions?: RulesetRuleActionsExtractions[] | cdktf.IResolvable;
    /**
    * priority block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#priority RulesetRule#priority}
    */
    readonly priority?: RulesetRuleActionsPriority[] | cdktf.IResolvable;
    /**
    * route block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#route RulesetRule#route}
    */
    readonly route?: RulesetRuleActionsRoute[] | cdktf.IResolvable;
    /**
    * severity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#severity RulesetRule#severity}
    */
    readonly severity?: RulesetRuleActionsSeverity[] | cdktf.IResolvable;
    /**
    * suppress block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#suppress RulesetRule#suppress}
    */
    readonly suppress?: RulesetRuleActionsSuppress[] | cdktf.IResolvable;
    /**
    * suspend block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#suspend RulesetRule#suspend}
    */
    readonly suspend?: RulesetRuleActionsSuspend[] | cdktf.IResolvable;
}
export declare function rulesetRuleActionsToTerraform(struct?: RulesetRuleActionsOutputReference | RulesetRuleActions): any;
export declare function rulesetRuleActionsToHclTerraform(struct?: RulesetRuleActionsOutputReference | RulesetRuleActions): any;
export declare class RulesetRuleActionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRuleActions | undefined;
    set internalValue(value: RulesetRuleActions | undefined);
    private _annotate;
    get annotate(): RulesetRuleActionsAnnotateList;
    putAnnotate(value: RulesetRuleActionsAnnotate[] | cdktf.IResolvable): void;
    resetAnnotate(): void;
    get annotateInput(): cdktf.IResolvable | RulesetRuleActionsAnnotate[] | undefined;
    private _eventAction;
    get eventAction(): RulesetRuleActionsEventActionList;
    putEventAction(value: RulesetRuleActionsEventAction[] | cdktf.IResolvable): void;
    resetEventAction(): void;
    get eventActionInput(): cdktf.IResolvable | RulesetRuleActionsEventAction[] | undefined;
    private _extractions;
    get extractions(): RulesetRuleActionsExtractionsList;
    putExtractions(value: RulesetRuleActionsExtractions[] | cdktf.IResolvable): void;
    resetExtractions(): void;
    get extractionsInput(): cdktf.IResolvable | RulesetRuleActionsExtractions[] | undefined;
    private _priority;
    get priority(): RulesetRuleActionsPriorityList;
    putPriority(value: RulesetRuleActionsPriority[] | cdktf.IResolvable): void;
    resetPriority(): void;
    get priorityInput(): cdktf.IResolvable | RulesetRuleActionsPriority[] | undefined;
    private _route;
    get route(): RulesetRuleActionsRouteList;
    putRoute(value: RulesetRuleActionsRoute[] | cdktf.IResolvable): void;
    resetRoute(): void;
    get routeInput(): cdktf.IResolvable | RulesetRuleActionsRoute[] | undefined;
    private _severity;
    get severity(): RulesetRuleActionsSeverityList;
    putSeverity(value: RulesetRuleActionsSeverity[] | cdktf.IResolvable): void;
    resetSeverity(): void;
    get severityInput(): cdktf.IResolvable | RulesetRuleActionsSeverity[] | undefined;
    private _suppress;
    get suppress(): RulesetRuleActionsSuppressList;
    putSuppress(value: RulesetRuleActionsSuppress[] | cdktf.IResolvable): void;
    resetSuppress(): void;
    get suppressInput(): cdktf.IResolvable | RulesetRuleActionsSuppress[] | undefined;
    private _suspend;
    get suspend(): RulesetRuleActionsSuspendList;
    putSuspend(value: RulesetRuleActionsSuspend[] | cdktf.IResolvable): void;
    resetSuspend(): void;
    get suspendInput(): cdktf.IResolvable | RulesetRuleActionsSuspend[] | undefined;
}
export interface RulesetRuleConditionsSubconditionsParameter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#path RulesetRule#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#value RulesetRule#value}
    */
    readonly value?: string;
}
export declare function rulesetRuleConditionsSubconditionsParameterToTerraform(struct?: RulesetRuleConditionsSubconditionsParameter | cdktf.IResolvable): any;
export declare function rulesetRuleConditionsSubconditionsParameterToHclTerraform(struct?: RulesetRuleConditionsSubconditionsParameter | cdktf.IResolvable): any;
export declare class RulesetRuleConditionsSubconditionsParameterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleConditionsSubconditionsParameter | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRuleConditionsSubconditionsParameter | cdktf.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRuleConditionsSubconditionsParameterList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleConditionsSubconditionsParameter[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleConditionsSubconditionsParameterOutputReference;
}
export interface RulesetRuleConditionsSubconditions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#operator RulesetRule#operator}
    */
    readonly operator?: string;
    /**
    * parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#parameter RulesetRule#parameter}
    */
    readonly parameter?: RulesetRuleConditionsSubconditionsParameter[] | cdktf.IResolvable;
}
export declare function rulesetRuleConditionsSubconditionsToTerraform(struct?: RulesetRuleConditionsSubconditions | cdktf.IResolvable): any;
export declare function rulesetRuleConditionsSubconditionsToHclTerraform(struct?: RulesetRuleConditionsSubconditions | cdktf.IResolvable): any;
export declare class RulesetRuleConditionsSubconditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleConditionsSubconditions | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRuleConditionsSubconditions | cdktf.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _parameter;
    get parameter(): RulesetRuleConditionsSubconditionsParameterList;
    putParameter(value: RulesetRuleConditionsSubconditionsParameter[] | cdktf.IResolvable): void;
    resetParameter(): void;
    get parameterInput(): cdktf.IResolvable | RulesetRuleConditionsSubconditionsParameter[] | undefined;
}
export declare class RulesetRuleConditionsSubconditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleConditionsSubconditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleConditionsSubconditionsOutputReference;
}
export interface RulesetRuleConditions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#operator RulesetRule#operator}
    */
    readonly operator?: string;
    /**
    * subconditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#subconditions RulesetRule#subconditions}
    */
    readonly subconditions?: RulesetRuleConditionsSubconditions[] | cdktf.IResolvable;
}
export declare function rulesetRuleConditionsToTerraform(struct?: RulesetRuleConditionsOutputReference | RulesetRuleConditions): any;
export declare function rulesetRuleConditionsToHclTerraform(struct?: RulesetRuleConditionsOutputReference | RulesetRuleConditions): any;
export declare class RulesetRuleConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRuleConditions | undefined;
    set internalValue(value: RulesetRuleConditions | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _subconditions;
    get subconditions(): RulesetRuleConditionsSubconditionsList;
    putSubconditions(value: RulesetRuleConditionsSubconditions[] | cdktf.IResolvable): void;
    resetSubconditions(): void;
    get subconditionsInput(): cdktf.IResolvable | RulesetRuleConditionsSubconditions[] | undefined;
}
export interface RulesetRuleTimeFrameActiveBetween {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#end_time RulesetRule#end_time}
    */
    readonly endTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#start_time RulesetRule#start_time}
    */
    readonly startTime?: number;
}
export declare function rulesetRuleTimeFrameActiveBetweenToTerraform(struct?: RulesetRuleTimeFrameActiveBetween | cdktf.IResolvable): any;
export declare function rulesetRuleTimeFrameActiveBetweenToHclTerraform(struct?: RulesetRuleTimeFrameActiveBetween | cdktf.IResolvable): any;
export declare class RulesetRuleTimeFrameActiveBetweenOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleTimeFrameActiveBetween | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRuleTimeFrameActiveBetween | cdktf.IResolvable | undefined);
    private _endTime?;
    get endTime(): number;
    set endTime(value: number);
    resetEndTime(): void;
    get endTimeInput(): number | undefined;
    private _startTime?;
    get startTime(): number;
    set startTime(value: number);
    resetStartTime(): void;
    get startTimeInput(): number | undefined;
}
export declare class RulesetRuleTimeFrameActiveBetweenList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleTimeFrameActiveBetween[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleTimeFrameActiveBetweenOutputReference;
}
export interface RulesetRuleTimeFrameScheduledWeekly {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#duration RulesetRule#duration}
    */
    readonly duration?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#start_time RulesetRule#start_time}
    */
    readonly startTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#timezone RulesetRule#timezone}
    */
    readonly timezone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#weekdays RulesetRule#weekdays}
    */
    readonly weekdays?: number[];
}
export declare function rulesetRuleTimeFrameScheduledWeeklyToTerraform(struct?: RulesetRuleTimeFrameScheduledWeekly | cdktf.IResolvable): any;
export declare function rulesetRuleTimeFrameScheduledWeeklyToHclTerraform(struct?: RulesetRuleTimeFrameScheduledWeekly | cdktf.IResolvable): any;
export declare class RulesetRuleTimeFrameScheduledWeeklyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleTimeFrameScheduledWeekly | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRuleTimeFrameScheduledWeekly | cdktf.IResolvable | undefined);
    private _duration?;
    get duration(): number;
    set duration(value: number);
    resetDuration(): void;
    get durationInput(): number | undefined;
    private _startTime?;
    get startTime(): number;
    set startTime(value: number);
    resetStartTime(): void;
    get startTimeInput(): number | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
    private _weekdays?;
    get weekdays(): number[];
    set weekdays(value: number[]);
    resetWeekdays(): void;
    get weekdaysInput(): number[] | undefined;
}
export declare class RulesetRuleTimeFrameScheduledWeeklyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleTimeFrameScheduledWeekly[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleTimeFrameScheduledWeeklyOutputReference;
}
export interface RulesetRuleTimeFrame {
    /**
    * active_between block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#active_between RulesetRule#active_between}
    */
    readonly activeBetween?: RulesetRuleTimeFrameActiveBetween[] | cdktf.IResolvable;
    /**
    * scheduled_weekly block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#scheduled_weekly RulesetRule#scheduled_weekly}
    */
    readonly scheduledWeekly?: RulesetRuleTimeFrameScheduledWeekly[] | cdktf.IResolvable;
}
export declare function rulesetRuleTimeFrameToTerraform(struct?: RulesetRuleTimeFrameOutputReference | RulesetRuleTimeFrame): any;
export declare function rulesetRuleTimeFrameToHclTerraform(struct?: RulesetRuleTimeFrameOutputReference | RulesetRuleTimeFrame): any;
export declare class RulesetRuleTimeFrameOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRuleTimeFrame | undefined;
    set internalValue(value: RulesetRuleTimeFrame | undefined);
    private _activeBetween;
    get activeBetween(): RulesetRuleTimeFrameActiveBetweenList;
    putActiveBetween(value: RulesetRuleTimeFrameActiveBetween[] | cdktf.IResolvable): void;
    resetActiveBetween(): void;
    get activeBetweenInput(): cdktf.IResolvable | RulesetRuleTimeFrameActiveBetween[] | undefined;
    private _scheduledWeekly;
    get scheduledWeekly(): RulesetRuleTimeFrameScheduledWeeklyList;
    putScheduledWeekly(value: RulesetRuleTimeFrameScheduledWeekly[] | cdktf.IResolvable): void;
    resetScheduledWeekly(): void;
    get scheduledWeeklyInput(): cdktf.IResolvable | RulesetRuleTimeFrameScheduledWeekly[] | undefined;
}
export interface RulesetRuleVariableParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#path RulesetRule#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#value RulesetRule#value}
    */
    readonly value?: string;
}
export declare function rulesetRuleVariableParametersToTerraform(struct?: RulesetRuleVariableParameters | cdktf.IResolvable): any;
export declare function rulesetRuleVariableParametersToHclTerraform(struct?: RulesetRuleVariableParameters | cdktf.IResolvable): any;
export declare class RulesetRuleVariableParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleVariableParameters | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRuleVariableParameters | cdktf.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRuleVariableParametersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleVariableParameters[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleVariableParametersOutputReference;
}
export interface RulesetRuleVariable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#name RulesetRule#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#type RulesetRule#type}
    */
    readonly type?: string;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#parameters RulesetRule#parameters}
    */
    readonly parameters?: RulesetRuleVariableParameters[] | cdktf.IResolvable;
}
export declare function rulesetRuleVariableToTerraform(struct?: RulesetRuleVariable | cdktf.IResolvable): any;
export declare function rulesetRuleVariableToHclTerraform(struct?: RulesetRuleVariable | cdktf.IResolvable): any;
export declare class RulesetRuleVariableOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleVariable | cdktf.IResolvable | undefined;
    set internalValue(value: RulesetRuleVariable | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _parameters;
    get parameters(): RulesetRuleVariableParametersList;
    putParameters(value: RulesetRuleVariableParameters[] | cdktf.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktf.IResolvable | RulesetRuleVariableParameters[] | undefined;
}
export declare class RulesetRuleVariableList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleVariable[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleVariableOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule pagerduty_ruleset_rule}
*/
export declare class RulesetRule extends cdktf.TerraformResource {
    static readonly tfResourceType = "pagerduty_ruleset_rule";
    /**
    * Generates CDKTF code for importing a RulesetRule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RulesetRule to import
    * @param importFromId The id of the existing RulesetRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RulesetRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/ruleset_rule pagerduty_ruleset_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RulesetRuleConfig
    */
    constructor(scope: Construct, id: string, config: RulesetRuleConfig);
    private _catchAll?;
    get catchAll(): boolean | cdktf.IResolvable;
    set catchAll(value: boolean | cdktf.IResolvable);
    resetCatchAll(): void;
    get catchAllInput(): boolean | cdktf.IResolvable | undefined;
    private _disabled?;
    get disabled(): boolean | cdktf.IResolvable;
    set disabled(value: boolean | cdktf.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _position?;
    get position(): number;
    set position(value: number);
    resetPosition(): void;
    get positionInput(): number | undefined;
    private _ruleset?;
    get ruleset(): string;
    set ruleset(value: string);
    get rulesetInput(): string | undefined;
    private _actions;
    get actions(): RulesetRuleActionsOutputReference;
    putActions(value: RulesetRuleActions): void;
    resetActions(): void;
    get actionsInput(): RulesetRuleActions | undefined;
    private _conditions;
    get conditions(): RulesetRuleConditionsOutputReference;
    putConditions(value: RulesetRuleConditions): void;
    resetConditions(): void;
    get conditionsInput(): RulesetRuleConditions | undefined;
    private _timeFrame;
    get timeFrame(): RulesetRuleTimeFrameOutputReference;
    putTimeFrame(value: RulesetRuleTimeFrame): void;
    resetTimeFrame(): void;
    get timeFrameInput(): RulesetRuleTimeFrame | undefined;
    private _variable;
    get variable(): RulesetRuleVariableList;
    putVariable(value: RulesetRuleVariable[] | cdktf.IResolvable): void;
    resetVariable(): void;
    get variableInput(): cdktf.IResolvable | RulesetRuleVariable[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
