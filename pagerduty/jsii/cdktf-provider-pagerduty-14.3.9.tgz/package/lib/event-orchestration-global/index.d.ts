/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface EventOrchestrationGlobalConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#event_orchestration EventOrchestrationGlobal#event_orchestration}
    */
    readonly eventOrchestration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#id EventOrchestrationGlobal#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * catch_all block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#catch_all EventOrchestrationGlobal#catch_all}
    */
    readonly catchAll: EventOrchestrationGlobalCatchAll;
    /**
    * set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#set EventOrchestrationGlobal#set}
    */
    readonly set: EventOrchestrationGlobalSet[] | cdktf.IResolvable;
}
export interface EventOrchestrationGlobalCatchAllActionsAutomationActionHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#key EventOrchestrationGlobal#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#value EventOrchestrationGlobal#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationGlobalCatchAllActionsAutomationActionHeaderToTerraform(struct?: EventOrchestrationGlobalCatchAllActionsAutomationActionHeader | cdktf.IResolvable): any;
export declare function eventOrchestrationGlobalCatchAllActionsAutomationActionHeaderToHclTerraform(struct?: EventOrchestrationGlobalCatchAllActionsAutomationActionHeader | cdktf.IResolvable): any;
export declare class EventOrchestrationGlobalCatchAllActionsAutomationActionHeaderOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalCatchAllActionsAutomationActionHeader | cdktf.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalCatchAllActionsAutomationActionHeader | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationGlobalCatchAllActionsAutomationActionHeaderList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalCatchAllActionsAutomationActionHeader[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalCatchAllActionsAutomationActionHeaderOutputReference;
}
export interface EventOrchestrationGlobalCatchAllActionsAutomationActionParameter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#key EventOrchestrationGlobal#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#value EventOrchestrationGlobal#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationGlobalCatchAllActionsAutomationActionParameterToTerraform(struct?: EventOrchestrationGlobalCatchAllActionsAutomationActionParameter | cdktf.IResolvable): any;
export declare function eventOrchestrationGlobalCatchAllActionsAutomationActionParameterToHclTerraform(struct?: EventOrchestrationGlobalCatchAllActionsAutomationActionParameter | cdktf.IResolvable): any;
export declare class EventOrchestrationGlobalCatchAllActionsAutomationActionParameterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalCatchAllActionsAutomationActionParameter | cdktf.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalCatchAllActionsAutomationActionParameter | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationGlobalCatchAllActionsAutomationActionParameterList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalCatchAllActionsAutomationActionParameter[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalCatchAllActionsAutomationActionParameterOutputReference;
}
export interface EventOrchestrationGlobalCatchAllActionsAutomationAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#auto_send EventOrchestrationGlobal#auto_send}
    */
    readonly autoSend?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#name EventOrchestrationGlobal#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#trigger_types EventOrchestrationGlobal#trigger_types}
    */
    readonly triggerTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#url EventOrchestrationGlobal#url}
    */
    readonly url: string;
    /**
    * header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#header EventOrchestrationGlobal#header}
    */
    readonly header?: EventOrchestrationGlobalCatchAllActionsAutomationActionHeader[] | cdktf.IResolvable;
    /**
    * parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#parameter EventOrchestrationGlobal#parameter}
    */
    readonly parameter?: EventOrchestrationGlobalCatchAllActionsAutomationActionParameter[] | cdktf.IResolvable;
}
export declare function eventOrchestrationGlobalCatchAllActionsAutomationActionToTerraform(struct?: EventOrchestrationGlobalCatchAllActionsAutomationActionOutputReference | EventOrchestrationGlobalCatchAllActionsAutomationAction): any;
export declare function eventOrchestrationGlobalCatchAllActionsAutomationActionToHclTerraform(struct?: EventOrchestrationGlobalCatchAllActionsAutomationActionOutputReference | EventOrchestrationGlobalCatchAllActionsAutomationAction): any;
export declare class EventOrchestrationGlobalCatchAllActionsAutomationActionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationGlobalCatchAllActionsAutomationAction | undefined;
    set internalValue(value: EventOrchestrationGlobalCatchAllActionsAutomationAction | undefined);
    private _autoSend?;
    get autoSend(): boolean | cdktf.IResolvable;
    set autoSend(value: boolean | cdktf.IResolvable);
    resetAutoSend(): void;
    get autoSendInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _triggerTypes?;
    get triggerTypes(): string[];
    set triggerTypes(value: string[]);
    resetTriggerTypes(): void;
    get triggerTypesInput(): string[] | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _header;
    get header(): EventOrchestrationGlobalCatchAllActionsAutomationActionHeaderList;
    putHeader(value: EventOrchestrationGlobalCatchAllActionsAutomationActionHeader[] | cdktf.IResolvable): void;
    resetHeader(): void;
    get headerInput(): cdktf.IResolvable | EventOrchestrationGlobalCatchAllActionsAutomationActionHeader[] | undefined;
    private _parameter;
    get parameter(): EventOrchestrationGlobalCatchAllActionsAutomationActionParameterList;
    putParameter(value: EventOrchestrationGlobalCatchAllActionsAutomationActionParameter[] | cdktf.IResolvable): void;
    resetParameter(): void;
    get parameterInput(): cdktf.IResolvable | EventOrchestrationGlobalCatchAllActionsAutomationActionParameter[] | undefined;
}
export interface EventOrchestrationGlobalCatchAllActionsExtraction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#regex EventOrchestrationGlobal#regex}
    */
    readonly regex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#source EventOrchestrationGlobal#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#target EventOrchestrationGlobal#target}
    */
    readonly target: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#template EventOrchestrationGlobal#template}
    */
    readonly template?: string;
}
export declare function eventOrchestrationGlobalCatchAllActionsExtractionToTerraform(struct?: EventOrchestrationGlobalCatchAllActionsExtraction | cdktf.IResolvable): any;
export declare function eventOrchestrationGlobalCatchAllActionsExtractionToHclTerraform(struct?: EventOrchestrationGlobalCatchAllActionsExtraction | cdktf.IResolvable): any;
export declare class EventOrchestrationGlobalCatchAllActionsExtractionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalCatchAllActionsExtraction | cdktf.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalCatchAllActionsExtraction | cdktf.IResolvable | undefined);
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    resetTemplate(): void;
    get templateInput(): string | undefined;
}
export declare class EventOrchestrationGlobalCatchAllActionsExtractionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalCatchAllActionsExtraction[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalCatchAllActionsExtractionOutputReference;
}
export interface EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#id EventOrchestrationGlobal#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#value EventOrchestrationGlobal#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdateToTerraform(struct?: EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdate | cdktf.IResolvable): any;
export declare function eventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdateToHclTerraform(struct?: EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdate | cdktf.IResolvable): any;
export declare class EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdate | cdktf.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdate | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdateList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdate[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdateOutputReference;
}
export interface EventOrchestrationGlobalCatchAllActionsVariable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#name EventOrchestrationGlobal#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#path EventOrchestrationGlobal#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#type EventOrchestrationGlobal#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#value EventOrchestrationGlobal#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationGlobalCatchAllActionsVariableToTerraform(struct?: EventOrchestrationGlobalCatchAllActionsVariable | cdktf.IResolvable): any;
export declare function eventOrchestrationGlobalCatchAllActionsVariableToHclTerraform(struct?: EventOrchestrationGlobalCatchAllActionsVariable | cdktf.IResolvable): any;
export declare class EventOrchestrationGlobalCatchAllActionsVariableOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalCatchAllActionsVariable | cdktf.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalCatchAllActionsVariable | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationGlobalCatchAllActionsVariableList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalCatchAllActionsVariable[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalCatchAllActionsVariableOutputReference;
}
export interface EventOrchestrationGlobalCatchAllActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#annotate EventOrchestrationGlobal#annotate}
    */
    readonly annotate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#drop_event EventOrchestrationGlobal#drop_event}
    */
    readonly dropEvent?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#escalation_policy EventOrchestrationGlobal#escalation_policy}
    */
    readonly escalationPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#event_action EventOrchestrationGlobal#event_action}
    */
    readonly eventAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#priority EventOrchestrationGlobal#priority}
    */
    readonly priority?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#route_to EventOrchestrationGlobal#route_to}
    */
    readonly routeTo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#severity EventOrchestrationGlobal#severity}
    */
    readonly severity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#suppress EventOrchestrationGlobal#suppress}
    */
    readonly suppress?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#suspend EventOrchestrationGlobal#suspend}
    */
    readonly suspend?: number;
    /**
    * automation_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#automation_action EventOrchestrationGlobal#automation_action}
    */
    readonly automationAction?: EventOrchestrationGlobalCatchAllActionsAutomationAction;
    /**
    * extraction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#extraction EventOrchestrationGlobal#extraction}
    */
    readonly extraction?: EventOrchestrationGlobalCatchAllActionsExtraction[] | cdktf.IResolvable;
    /**
    * incident_custom_field_update block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#incident_custom_field_update EventOrchestrationGlobal#incident_custom_field_update}
    */
    readonly incidentCustomFieldUpdate?: EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdate[] | cdktf.IResolvable;
    /**
    * variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#variable EventOrchestrationGlobal#variable}
    */
    readonly variable?: EventOrchestrationGlobalCatchAllActionsVariable[] | cdktf.IResolvable;
}
export declare function eventOrchestrationGlobalCatchAllActionsToTerraform(struct?: EventOrchestrationGlobalCatchAllActionsOutputReference | EventOrchestrationGlobalCatchAllActions): any;
export declare function eventOrchestrationGlobalCatchAllActionsToHclTerraform(struct?: EventOrchestrationGlobalCatchAllActionsOutputReference | EventOrchestrationGlobalCatchAllActions): any;
export declare class EventOrchestrationGlobalCatchAllActionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationGlobalCatchAllActions | undefined;
    set internalValue(value: EventOrchestrationGlobalCatchAllActions | undefined);
    private _annotate?;
    get annotate(): string;
    set annotate(value: string);
    resetAnnotate(): void;
    get annotateInput(): string | undefined;
    private _dropEvent?;
    get dropEvent(): boolean | cdktf.IResolvable;
    set dropEvent(value: boolean | cdktf.IResolvable);
    resetDropEvent(): void;
    get dropEventInput(): boolean | cdktf.IResolvable | undefined;
    private _escalationPolicy?;
    get escalationPolicy(): string;
    set escalationPolicy(value: string);
    resetEscalationPolicy(): void;
    get escalationPolicyInput(): string | undefined;
    private _eventAction?;
    get eventAction(): string;
    set eventAction(value: string);
    resetEventAction(): void;
    get eventActionInput(): string | undefined;
    private _priority?;
    get priority(): string;
    set priority(value: string);
    resetPriority(): void;
    get priorityInput(): string | undefined;
    private _routeTo?;
    get routeTo(): string;
    set routeTo(value: string);
    resetRouteTo(): void;
    get routeToInput(): string | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    resetSeverity(): void;
    get severityInput(): string | undefined;
    private _suppress?;
    get suppress(): boolean | cdktf.IResolvable;
    set suppress(value: boolean | cdktf.IResolvable);
    resetSuppress(): void;
    get suppressInput(): boolean | cdktf.IResolvable | undefined;
    private _suspend?;
    get suspend(): number;
    set suspend(value: number);
    resetSuspend(): void;
    get suspendInput(): number | undefined;
    private _automationAction;
    get automationAction(): EventOrchestrationGlobalCatchAllActionsAutomationActionOutputReference;
    putAutomationAction(value: EventOrchestrationGlobalCatchAllActionsAutomationAction): void;
    resetAutomationAction(): void;
    get automationActionInput(): EventOrchestrationGlobalCatchAllActionsAutomationAction | undefined;
    private _extraction;
    get extraction(): EventOrchestrationGlobalCatchAllActionsExtractionList;
    putExtraction(value: EventOrchestrationGlobalCatchAllActionsExtraction[] | cdktf.IResolvable): void;
    resetExtraction(): void;
    get extractionInput(): cdktf.IResolvable | EventOrchestrationGlobalCatchAllActionsExtraction[] | undefined;
    private _incidentCustomFieldUpdate;
    get incidentCustomFieldUpdate(): EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdateList;
    putIncidentCustomFieldUpdate(value: EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdate[] | cdktf.IResolvable): void;
    resetIncidentCustomFieldUpdate(): void;
    get incidentCustomFieldUpdateInput(): cdktf.IResolvable | EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdate[] | undefined;
    private _variable;
    get variable(): EventOrchestrationGlobalCatchAllActionsVariableList;
    putVariable(value: EventOrchestrationGlobalCatchAllActionsVariable[] | cdktf.IResolvable): void;
    resetVariable(): void;
    get variableInput(): cdktf.IResolvable | EventOrchestrationGlobalCatchAllActionsVariable[] | undefined;
}
export interface EventOrchestrationGlobalCatchAll {
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#actions EventOrchestrationGlobal#actions}
    */
    readonly actions: EventOrchestrationGlobalCatchAllActions;
}
export declare function eventOrchestrationGlobalCatchAllToTerraform(struct?: EventOrchestrationGlobalCatchAllOutputReference | EventOrchestrationGlobalCatchAll): any;
export declare function eventOrchestrationGlobalCatchAllToHclTerraform(struct?: EventOrchestrationGlobalCatchAllOutputReference | EventOrchestrationGlobalCatchAll): any;
export declare class EventOrchestrationGlobalCatchAllOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationGlobalCatchAll | undefined;
    set internalValue(value: EventOrchestrationGlobalCatchAll | undefined);
    private _actions;
    get actions(): EventOrchestrationGlobalCatchAllActionsOutputReference;
    putActions(value: EventOrchestrationGlobalCatchAllActions): void;
    get actionsInput(): EventOrchestrationGlobalCatchAllActions | undefined;
}
export interface EventOrchestrationGlobalSetRuleActionsAutomationActionHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#key EventOrchestrationGlobal#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#value EventOrchestrationGlobal#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationGlobalSetRuleActionsAutomationActionHeaderToTerraform(struct?: EventOrchestrationGlobalSetRuleActionsAutomationActionHeader | cdktf.IResolvable): any;
export declare function eventOrchestrationGlobalSetRuleActionsAutomationActionHeaderToHclTerraform(struct?: EventOrchestrationGlobalSetRuleActionsAutomationActionHeader | cdktf.IResolvable): any;
export declare class EventOrchestrationGlobalSetRuleActionsAutomationActionHeaderOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalSetRuleActionsAutomationActionHeader | cdktf.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalSetRuleActionsAutomationActionHeader | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationGlobalSetRuleActionsAutomationActionHeaderList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalSetRuleActionsAutomationActionHeader[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalSetRuleActionsAutomationActionHeaderOutputReference;
}
export interface EventOrchestrationGlobalSetRuleActionsAutomationActionParameter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#key EventOrchestrationGlobal#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#value EventOrchestrationGlobal#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationGlobalSetRuleActionsAutomationActionParameterToTerraform(struct?: EventOrchestrationGlobalSetRuleActionsAutomationActionParameter | cdktf.IResolvable): any;
export declare function eventOrchestrationGlobalSetRuleActionsAutomationActionParameterToHclTerraform(struct?: EventOrchestrationGlobalSetRuleActionsAutomationActionParameter | cdktf.IResolvable): any;
export declare class EventOrchestrationGlobalSetRuleActionsAutomationActionParameterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalSetRuleActionsAutomationActionParameter | cdktf.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalSetRuleActionsAutomationActionParameter | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationGlobalSetRuleActionsAutomationActionParameterList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalSetRuleActionsAutomationActionParameter[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalSetRuleActionsAutomationActionParameterOutputReference;
}
export interface EventOrchestrationGlobalSetRuleActionsAutomationAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#auto_send EventOrchestrationGlobal#auto_send}
    */
    readonly autoSend?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#name EventOrchestrationGlobal#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#trigger_types EventOrchestrationGlobal#trigger_types}
    */
    readonly triggerTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#url EventOrchestrationGlobal#url}
    */
    readonly url: string;
    /**
    * header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#header EventOrchestrationGlobal#header}
    */
    readonly header?: EventOrchestrationGlobalSetRuleActionsAutomationActionHeader[] | cdktf.IResolvable;
    /**
    * parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#parameter EventOrchestrationGlobal#parameter}
    */
    readonly parameter?: EventOrchestrationGlobalSetRuleActionsAutomationActionParameter[] | cdktf.IResolvable;
}
export declare function eventOrchestrationGlobalSetRuleActionsAutomationActionToTerraform(struct?: EventOrchestrationGlobalSetRuleActionsAutomationActionOutputReference | EventOrchestrationGlobalSetRuleActionsAutomationAction): any;
export declare function eventOrchestrationGlobalSetRuleActionsAutomationActionToHclTerraform(struct?: EventOrchestrationGlobalSetRuleActionsAutomationActionOutputReference | EventOrchestrationGlobalSetRuleActionsAutomationAction): any;
export declare class EventOrchestrationGlobalSetRuleActionsAutomationActionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationGlobalSetRuleActionsAutomationAction | undefined;
    set internalValue(value: EventOrchestrationGlobalSetRuleActionsAutomationAction | undefined);
    private _autoSend?;
    get autoSend(): boolean | cdktf.IResolvable;
    set autoSend(value: boolean | cdktf.IResolvable);
    resetAutoSend(): void;
    get autoSendInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _triggerTypes?;
    get triggerTypes(): string[];
    set triggerTypes(value: string[]);
    resetTriggerTypes(): void;
    get triggerTypesInput(): string[] | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _header;
    get header(): EventOrchestrationGlobalSetRuleActionsAutomationActionHeaderList;
    putHeader(value: EventOrchestrationGlobalSetRuleActionsAutomationActionHeader[] | cdktf.IResolvable): void;
    resetHeader(): void;
    get headerInput(): cdktf.IResolvable | EventOrchestrationGlobalSetRuleActionsAutomationActionHeader[] | undefined;
    private _parameter;
    get parameter(): EventOrchestrationGlobalSetRuleActionsAutomationActionParameterList;
    putParameter(value: EventOrchestrationGlobalSetRuleActionsAutomationActionParameter[] | cdktf.IResolvable): void;
    resetParameter(): void;
    get parameterInput(): cdktf.IResolvable | EventOrchestrationGlobalSetRuleActionsAutomationActionParameter[] | undefined;
}
export interface EventOrchestrationGlobalSetRuleActionsExtraction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#regex EventOrchestrationGlobal#regex}
    */
    readonly regex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#source EventOrchestrationGlobal#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#target EventOrchestrationGlobal#target}
    */
    readonly target: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#template EventOrchestrationGlobal#template}
    */
    readonly template?: string;
}
export declare function eventOrchestrationGlobalSetRuleActionsExtractionToTerraform(struct?: EventOrchestrationGlobalSetRuleActionsExtraction | cdktf.IResolvable): any;
export declare function eventOrchestrationGlobalSetRuleActionsExtractionToHclTerraform(struct?: EventOrchestrationGlobalSetRuleActionsExtraction | cdktf.IResolvable): any;
export declare class EventOrchestrationGlobalSetRuleActionsExtractionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalSetRuleActionsExtraction | cdktf.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalSetRuleActionsExtraction | cdktf.IResolvable | undefined);
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    resetTemplate(): void;
    get templateInput(): string | undefined;
}
export declare class EventOrchestrationGlobalSetRuleActionsExtractionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalSetRuleActionsExtraction[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalSetRuleActionsExtractionOutputReference;
}
export interface EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#id EventOrchestrationGlobal#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#value EventOrchestrationGlobal#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdateToTerraform(struct?: EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdate | cdktf.IResolvable): any;
export declare function eventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdateToHclTerraform(struct?: EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdate | cdktf.IResolvable): any;
export declare class EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdate | cdktf.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdate | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdateList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdate[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdateOutputReference;
}
export interface EventOrchestrationGlobalSetRuleActionsVariable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#name EventOrchestrationGlobal#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#path EventOrchestrationGlobal#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#type EventOrchestrationGlobal#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#value EventOrchestrationGlobal#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationGlobalSetRuleActionsVariableToTerraform(struct?: EventOrchestrationGlobalSetRuleActionsVariable | cdktf.IResolvable): any;
export declare function eventOrchestrationGlobalSetRuleActionsVariableToHclTerraform(struct?: EventOrchestrationGlobalSetRuleActionsVariable | cdktf.IResolvable): any;
export declare class EventOrchestrationGlobalSetRuleActionsVariableOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalSetRuleActionsVariable | cdktf.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalSetRuleActionsVariable | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationGlobalSetRuleActionsVariableList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalSetRuleActionsVariable[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalSetRuleActionsVariableOutputReference;
}
export interface EventOrchestrationGlobalSetRuleActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#annotate EventOrchestrationGlobal#annotate}
    */
    readonly annotate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#drop_event EventOrchestrationGlobal#drop_event}
    */
    readonly dropEvent?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#escalation_policy EventOrchestrationGlobal#escalation_policy}
    */
    readonly escalationPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#event_action EventOrchestrationGlobal#event_action}
    */
    readonly eventAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#priority EventOrchestrationGlobal#priority}
    */
    readonly priority?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#route_to EventOrchestrationGlobal#route_to}
    */
    readonly routeTo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#severity EventOrchestrationGlobal#severity}
    */
    readonly severity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#suppress EventOrchestrationGlobal#suppress}
    */
    readonly suppress?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#suspend EventOrchestrationGlobal#suspend}
    */
    readonly suspend?: number;
    /**
    * automation_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#automation_action EventOrchestrationGlobal#automation_action}
    */
    readonly automationAction?: EventOrchestrationGlobalSetRuleActionsAutomationAction;
    /**
    * extraction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#extraction EventOrchestrationGlobal#extraction}
    */
    readonly extraction?: EventOrchestrationGlobalSetRuleActionsExtraction[] | cdktf.IResolvable;
    /**
    * incident_custom_field_update block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#incident_custom_field_update EventOrchestrationGlobal#incident_custom_field_update}
    */
    readonly incidentCustomFieldUpdate?: EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdate[] | cdktf.IResolvable;
    /**
    * variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#variable EventOrchestrationGlobal#variable}
    */
    readonly variable?: EventOrchestrationGlobalSetRuleActionsVariable[] | cdktf.IResolvable;
}
export declare function eventOrchestrationGlobalSetRuleActionsToTerraform(struct?: EventOrchestrationGlobalSetRuleActionsOutputReference | EventOrchestrationGlobalSetRuleActions): any;
export declare function eventOrchestrationGlobalSetRuleActionsToHclTerraform(struct?: EventOrchestrationGlobalSetRuleActionsOutputReference | EventOrchestrationGlobalSetRuleActions): any;
export declare class EventOrchestrationGlobalSetRuleActionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationGlobalSetRuleActions | undefined;
    set internalValue(value: EventOrchestrationGlobalSetRuleActions | undefined);
    private _annotate?;
    get annotate(): string;
    set annotate(value: string);
    resetAnnotate(): void;
    get annotateInput(): string | undefined;
    private _dropEvent?;
    get dropEvent(): boolean | cdktf.IResolvable;
    set dropEvent(value: boolean | cdktf.IResolvable);
    resetDropEvent(): void;
    get dropEventInput(): boolean | cdktf.IResolvable | undefined;
    private _escalationPolicy?;
    get escalationPolicy(): string;
    set escalationPolicy(value: string);
    resetEscalationPolicy(): void;
    get escalationPolicyInput(): string | undefined;
    private _eventAction?;
    get eventAction(): string;
    set eventAction(value: string);
    resetEventAction(): void;
    get eventActionInput(): string | undefined;
    private _priority?;
    get priority(): string;
    set priority(value: string);
    resetPriority(): void;
    get priorityInput(): string | undefined;
    private _routeTo?;
    get routeTo(): string;
    set routeTo(value: string);
    resetRouteTo(): void;
    get routeToInput(): string | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    resetSeverity(): void;
    get severityInput(): string | undefined;
    private _suppress?;
    get suppress(): boolean | cdktf.IResolvable;
    set suppress(value: boolean | cdktf.IResolvable);
    resetSuppress(): void;
    get suppressInput(): boolean | cdktf.IResolvable | undefined;
    private _suspend?;
    get suspend(): number;
    set suspend(value: number);
    resetSuspend(): void;
    get suspendInput(): number | undefined;
    private _automationAction;
    get automationAction(): EventOrchestrationGlobalSetRuleActionsAutomationActionOutputReference;
    putAutomationAction(value: EventOrchestrationGlobalSetRuleActionsAutomationAction): void;
    resetAutomationAction(): void;
    get automationActionInput(): EventOrchestrationGlobalSetRuleActionsAutomationAction | undefined;
    private _extraction;
    get extraction(): EventOrchestrationGlobalSetRuleActionsExtractionList;
    putExtraction(value: EventOrchestrationGlobalSetRuleActionsExtraction[] | cdktf.IResolvable): void;
    resetExtraction(): void;
    get extractionInput(): cdktf.IResolvable | EventOrchestrationGlobalSetRuleActionsExtraction[] | undefined;
    private _incidentCustomFieldUpdate;
    get incidentCustomFieldUpdate(): EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdateList;
    putIncidentCustomFieldUpdate(value: EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdate[] | cdktf.IResolvable): void;
    resetIncidentCustomFieldUpdate(): void;
    get incidentCustomFieldUpdateInput(): cdktf.IResolvable | EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdate[] | undefined;
    private _variable;
    get variable(): EventOrchestrationGlobalSetRuleActionsVariableList;
    putVariable(value: EventOrchestrationGlobalSetRuleActionsVariable[] | cdktf.IResolvable): void;
    resetVariable(): void;
    get variableInput(): cdktf.IResolvable | EventOrchestrationGlobalSetRuleActionsVariable[] | undefined;
}
export interface EventOrchestrationGlobalSetRuleCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#expression EventOrchestrationGlobal#expression}
    */
    readonly expression: string;
}
export declare function eventOrchestrationGlobalSetRuleConditionToTerraform(struct?: EventOrchestrationGlobalSetRuleCondition | cdktf.IResolvable): any;
export declare function eventOrchestrationGlobalSetRuleConditionToHclTerraform(struct?: EventOrchestrationGlobalSetRuleCondition | cdktf.IResolvable): any;
export declare class EventOrchestrationGlobalSetRuleConditionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalSetRuleCondition | cdktf.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalSetRuleCondition | cdktf.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export declare class EventOrchestrationGlobalSetRuleConditionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalSetRuleCondition[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalSetRuleConditionOutputReference;
}
export interface EventOrchestrationGlobalSetRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#disabled EventOrchestrationGlobal#disabled}
    */
    readonly disabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#label EventOrchestrationGlobal#label}
    */
    readonly label?: string;
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#actions EventOrchestrationGlobal#actions}
    */
    readonly actions: EventOrchestrationGlobalSetRuleActions;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#condition EventOrchestrationGlobal#condition}
    */
    readonly condition?: EventOrchestrationGlobalSetRuleCondition[] | cdktf.IResolvable;
}
export declare function eventOrchestrationGlobalSetRuleToTerraform(struct?: EventOrchestrationGlobalSetRule | cdktf.IResolvable): any;
export declare function eventOrchestrationGlobalSetRuleToHclTerraform(struct?: EventOrchestrationGlobalSetRule | cdktf.IResolvable): any;
export declare class EventOrchestrationGlobalSetRuleOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalSetRule | cdktf.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalSetRule | cdktf.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktf.IResolvable;
    set disabled(value: boolean | cdktf.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _actions;
    get actions(): EventOrchestrationGlobalSetRuleActionsOutputReference;
    putActions(value: EventOrchestrationGlobalSetRuleActions): void;
    get actionsInput(): EventOrchestrationGlobalSetRuleActions | undefined;
    private _condition;
    get condition(): EventOrchestrationGlobalSetRuleConditionList;
    putCondition(value: EventOrchestrationGlobalSetRuleCondition[] | cdktf.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktf.IResolvable | EventOrchestrationGlobalSetRuleCondition[] | undefined;
}
export declare class EventOrchestrationGlobalSetRuleList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalSetRule[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalSetRuleOutputReference;
}
export interface EventOrchestrationGlobalSet {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#id EventOrchestrationGlobal#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#rule EventOrchestrationGlobal#rule}
    */
    readonly rule?: EventOrchestrationGlobalSetRule[] | cdktf.IResolvable;
}
export declare function eventOrchestrationGlobalSetToTerraform(struct?: EventOrchestrationGlobalSet | cdktf.IResolvable): any;
export declare function eventOrchestrationGlobalSetToHclTerraform(struct?: EventOrchestrationGlobalSet | cdktf.IResolvable): any;
export declare class EventOrchestrationGlobalSetOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalSet | cdktf.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalSet | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _rule;
    get rule(): EventOrchestrationGlobalSetRuleList;
    putRule(value: EventOrchestrationGlobalSetRule[] | cdktf.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktf.IResolvable | EventOrchestrationGlobalSetRule[] | undefined;
}
export declare class EventOrchestrationGlobalSetList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalSet[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalSetOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global pagerduty_event_orchestration_global}
*/
export declare class EventOrchestrationGlobal extends cdktf.TerraformResource {
    static readonly tfResourceType = "pagerduty_event_orchestration_global";
    /**
    * Generates CDKTF code for importing a EventOrchestrationGlobal resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EventOrchestrationGlobal to import
    * @param importFromId The id of the existing EventOrchestrationGlobal that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EventOrchestrationGlobal to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.30.8/docs/resources/event_orchestration_global pagerduty_event_orchestration_global} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EventOrchestrationGlobalConfig
    */
    constructor(scope: Construct, id: string, config: EventOrchestrationGlobalConfig);
    private _eventOrchestration?;
    get eventOrchestration(): string;
    set eventOrchestration(value: string);
    get eventOrchestrationInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _catchAll;
    get catchAll(): EventOrchestrationGlobalCatchAllOutputReference;
    putCatchAll(value: EventOrchestrationGlobalCatchAll): void;
    get catchAllInput(): EventOrchestrationGlobalCatchAll | undefined;
    private _set;
    get set(): EventOrchestrationGlobalSetList;
    putSet(value: EventOrchestrationGlobalSet[] | cdktf.IResolvable): void;
    get setInput(): cdktf.IResolvable | EventOrchestrationGlobalSet[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
