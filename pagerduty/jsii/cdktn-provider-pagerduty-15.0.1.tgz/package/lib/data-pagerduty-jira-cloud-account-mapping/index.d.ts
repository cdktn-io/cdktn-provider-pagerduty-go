/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPagerdutyJiraCloudAccountMappingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/jira_cloud_account_mapping#subdomain DataPagerdutyJiraCloudAccountMapping#subdomain}
    */
    readonly subdomain: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/jira_cloud_account_mapping pagerduty_jira_cloud_account_mapping}
*/
export declare class DataPagerdutyJiraCloudAccountMapping extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_jira_cloud_account_mapping";
    /**
    * Generates CDKTN code for importing a DataPagerdutyJiraCloudAccountMapping resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyJiraCloudAccountMapping to import
    * @param importFromId The id of the existing DataPagerdutyJiraCloudAccountMapping that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/jira_cloud_account_mapping#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyJiraCloudAccountMapping to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/jira_cloud_account_mapping pagerduty_jira_cloud_account_mapping} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyJiraCloudAccountMappingConfig
    */
    constructor(scope: Construct, id: string, config: DataPagerdutyJiraCloudAccountMappingConfig);
    get baseUrl(): string;
    get id(): string;
    private _subdomain?;
    get subdomain(): string;
    set subdomain(value: string);
    get subdomainInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
