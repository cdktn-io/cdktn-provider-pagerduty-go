/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AutomationActionsRunnerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/automation_actions_runner#description AutomationActionsRunner#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/automation_actions_runner#id AutomationActionsRunner#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/automation_actions_runner#last_seen AutomationActionsRunner#last_seen}
    */
    readonly lastSeen?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/automation_actions_runner#name AutomationActionsRunner#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/automation_actions_runner#runbook_api_key AutomationActionsRunner#runbook_api_key}
    */
    readonly runbookApiKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/automation_actions_runner#runbook_base_uri AutomationActionsRunner#runbook_base_uri}
    */
    readonly runbookBaseUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/automation_actions_runner#runner_type AutomationActionsRunner#runner_type}
    */
    readonly runnerType: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/automation_actions_runner pagerduty_automation_actions_runner}
*/
export declare class AutomationActionsRunner extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_automation_actions_runner";
    /**
    * Generates CDKTN code for importing a AutomationActionsRunner resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AutomationActionsRunner to import
    * @param importFromId The id of the existing AutomationActionsRunner that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/automation_actions_runner#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AutomationActionsRunner to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/automation_actions_runner pagerduty_automation_actions_runner} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AutomationActionsRunnerConfig
    */
    constructor(scope: Construct, id: string, config: AutomationActionsRunnerConfig);
    get creationTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lastSeen?;
    get lastSeen(): string;
    set lastSeen(value: string);
    resetLastSeen(): void;
    get lastSeenInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _runbookApiKey?;
    get runbookApiKey(): string;
    set runbookApiKey(value: string);
    resetRunbookApiKey(): void;
    get runbookApiKeyInput(): string | undefined;
    private _runbookBaseUri?;
    get runbookBaseUri(): string;
    set runbookBaseUri(value: string);
    resetRunbookBaseUri(): void;
    get runbookBaseUriInput(): string | undefined;
    private _runnerType?;
    get runnerType(): string;
    set runnerType(value: string);
    get runnerTypeInput(): string | undefined;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
