/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EventOrchestrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/event_orchestration#description EventOrchestration#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/event_orchestration#id EventOrchestration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/event_orchestration#name EventOrchestration#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/event_orchestration#team EventOrchestration#team}
    */
    readonly team?: string;
    /**
    * integration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/event_orchestration#integration EventOrchestration#integration}
    */
    readonly integration?: EventOrchestrationIntegration[] | cdktn.IResolvable;
}
export interface EventOrchestrationIntegrationParameters {
}
export declare function eventOrchestrationIntegrationParametersToTerraform(struct?: EventOrchestrationIntegrationParameters): any;
export declare function eventOrchestrationIntegrationParametersToHclTerraform(struct?: EventOrchestrationIntegrationParameters): any;
export declare class EventOrchestrationIntegrationParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationIntegrationParameters | undefined;
    set internalValue(value: EventOrchestrationIntegrationParameters | undefined);
    get routingKey(): string;
    get type(): string;
}
export declare class EventOrchestrationIntegrationParametersList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationIntegrationParametersOutputReference;
}
export interface EventOrchestrationIntegration {
}
export declare function eventOrchestrationIntegrationToTerraform(struct?: EventOrchestrationIntegration | cdktn.IResolvable): any;
export declare function eventOrchestrationIntegrationToHclTerraform(struct?: EventOrchestrationIntegration | cdktn.IResolvable): any;
export declare class EventOrchestrationIntegrationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationIntegration | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationIntegration | cdktn.IResolvable | undefined);
    get id(): string;
    get label(): string;
    private _parameters;
    get parameters(): EventOrchestrationIntegrationParametersList;
}
export declare class EventOrchestrationIntegrationList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationIntegration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationIntegrationOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/event_orchestration pagerduty_event_orchestration}
*/
export declare class EventOrchestration extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_event_orchestration";
    /**
    * Generates CDKTN code for importing a EventOrchestration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EventOrchestration to import
    * @param importFromId The id of the existing EventOrchestration that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/event_orchestration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EventOrchestration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/event_orchestration pagerduty_event_orchestration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EventOrchestrationConfig
    */
    constructor(scope: Construct, id: string, config: EventOrchestrationConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get routes(): number;
    private _team?;
    get team(): string;
    set team(value: string);
    resetTeam(): void;
    get teamInput(): string | undefined;
    private _integration;
    get integration(): EventOrchestrationIntegrationList;
    putIntegration(value: EventOrchestrationIntegration[] | cdktn.IResolvable): void;
    resetIntegration(): void;
    get integrationInput(): cdktn.IResolvable | EventOrchestrationIntegration[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
