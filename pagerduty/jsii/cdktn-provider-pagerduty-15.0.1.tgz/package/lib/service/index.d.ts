/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#acknowledgement_timeout Service#acknowledgement_timeout}
    */
    readonly acknowledgementTimeout?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#alert_creation Service#alert_creation}
    */
    readonly alertCreation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#alert_grouping Service#alert_grouping}
    */
    readonly alertGrouping?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#alert_grouping_timeout Service#alert_grouping_timeout}
    */
    readonly alertGroupingTimeout?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#auto_resolve_timeout Service#auto_resolve_timeout}
    */
    readonly autoResolveTimeout?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#description Service#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#escalation_policy Service#escalation_policy}
    */
    readonly escalationPolicy: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#id Service#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#name Service#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#response_play Service#response_play}
    */
    readonly responsePlay?: string;
    /**
    * alert_grouping_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#alert_grouping_parameters Service#alert_grouping_parameters}
    */
    readonly alertGroupingParameters?: ServiceAlertGroupingParameters;
    /**
    * auto_pause_notifications_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#auto_pause_notifications_parameters Service#auto_pause_notifications_parameters}
    */
    readonly autoPauseNotificationsParameters?: ServiceAutoPauseNotificationsParameters;
    /**
    * incident_urgency_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#incident_urgency_rule Service#incident_urgency_rule}
    */
    readonly incidentUrgencyRule?: ServiceIncidentUrgencyRule;
    /**
    * scheduled_actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#scheduled_actions Service#scheduled_actions}
    */
    readonly scheduledActions?: ServiceScheduledActions[] | cdktn.IResolvable;
    /**
    * support_hours block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#support_hours Service#support_hours}
    */
    readonly supportHours?: ServiceSupportHours;
}
export interface ServiceAlertGroupingParametersConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#aggregate Service#aggregate}
    */
    readonly aggregate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#fields Service#fields}
    */
    readonly fields?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#time_window Service#time_window}
    */
    readonly timeWindow?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#timeout Service#timeout}
    */
    readonly timeout?: number;
}
export declare function serviceAlertGroupingParametersConfigToTerraform(struct?: ServiceAlertGroupingParametersConfigOutputReference | ServiceAlertGroupingParametersConfig): any;
export declare function serviceAlertGroupingParametersConfigToHclTerraform(struct?: ServiceAlertGroupingParametersConfigOutputReference | ServiceAlertGroupingParametersConfig): any;
export declare class ServiceAlertGroupingParametersConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceAlertGroupingParametersConfig | undefined;
    set internalValue(value: ServiceAlertGroupingParametersConfig | undefined);
    private _aggregate?;
    get aggregate(): string;
    set aggregate(value: string);
    resetAggregate(): void;
    get aggregateInput(): string | undefined;
    private _fields?;
    get fields(): string[];
    set fields(value: string[]);
    resetFields(): void;
    get fieldsInput(): string[] | undefined;
    private _timeWindow?;
    get timeWindow(): number;
    set timeWindow(value: number);
    resetTimeWindow(): void;
    get timeWindowInput(): number | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
}
export interface ServiceAlertGroupingParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#type Service#type}
    */
    readonly type?: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#config Service#config}
    */
    readonly config?: ServiceAlertGroupingParametersConfig;
}
export declare function serviceAlertGroupingParametersToTerraform(struct?: ServiceAlertGroupingParametersOutputReference | ServiceAlertGroupingParameters): any;
export declare function serviceAlertGroupingParametersToHclTerraform(struct?: ServiceAlertGroupingParametersOutputReference | ServiceAlertGroupingParameters): any;
export declare class ServiceAlertGroupingParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceAlertGroupingParameters | undefined;
    set internalValue(value: ServiceAlertGroupingParameters | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _config;
    get config(): ServiceAlertGroupingParametersConfigOutputReference;
    putConfig(value: ServiceAlertGroupingParametersConfig): void;
    resetConfig(): void;
    get configInput(): ServiceAlertGroupingParametersConfig | undefined;
}
export interface ServiceAutoPauseNotificationsParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#enabled Service#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#timeout Service#timeout}
    */
    readonly timeout?: number;
}
export declare function serviceAutoPauseNotificationsParametersToTerraform(struct?: ServiceAutoPauseNotificationsParametersOutputReference | ServiceAutoPauseNotificationsParameters): any;
export declare function serviceAutoPauseNotificationsParametersToHclTerraform(struct?: ServiceAutoPauseNotificationsParametersOutputReference | ServiceAutoPauseNotificationsParameters): any;
export declare class ServiceAutoPauseNotificationsParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceAutoPauseNotificationsParameters | undefined;
    set internalValue(value: ServiceAutoPauseNotificationsParameters | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
}
export interface ServiceIncidentUrgencyRuleDuringSupportHours {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#type Service#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#urgency Service#urgency}
    */
    readonly urgency?: string;
}
export declare function serviceIncidentUrgencyRuleDuringSupportHoursToTerraform(struct?: ServiceIncidentUrgencyRuleDuringSupportHoursOutputReference | ServiceIncidentUrgencyRuleDuringSupportHours): any;
export declare function serviceIncidentUrgencyRuleDuringSupportHoursToHclTerraform(struct?: ServiceIncidentUrgencyRuleDuringSupportHoursOutputReference | ServiceIncidentUrgencyRuleDuringSupportHours): any;
export declare class ServiceIncidentUrgencyRuleDuringSupportHoursOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceIncidentUrgencyRuleDuringSupportHours | undefined;
    set internalValue(value: ServiceIncidentUrgencyRuleDuringSupportHours | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _urgency?;
    get urgency(): string;
    set urgency(value: string);
    resetUrgency(): void;
    get urgencyInput(): string | undefined;
}
export interface ServiceIncidentUrgencyRuleOutsideSupportHours {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#type Service#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#urgency Service#urgency}
    */
    readonly urgency?: string;
}
export declare function serviceIncidentUrgencyRuleOutsideSupportHoursToTerraform(struct?: ServiceIncidentUrgencyRuleOutsideSupportHoursOutputReference | ServiceIncidentUrgencyRuleOutsideSupportHours): any;
export declare function serviceIncidentUrgencyRuleOutsideSupportHoursToHclTerraform(struct?: ServiceIncidentUrgencyRuleOutsideSupportHoursOutputReference | ServiceIncidentUrgencyRuleOutsideSupportHours): any;
export declare class ServiceIncidentUrgencyRuleOutsideSupportHoursOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceIncidentUrgencyRuleOutsideSupportHours | undefined;
    set internalValue(value: ServiceIncidentUrgencyRuleOutsideSupportHours | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _urgency?;
    get urgency(): string;
    set urgency(value: string);
    resetUrgency(): void;
    get urgencyInput(): string | undefined;
}
export interface ServiceIncidentUrgencyRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#type Service#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#urgency Service#urgency}
    */
    readonly urgency?: string;
    /**
    * during_support_hours block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#during_support_hours Service#during_support_hours}
    */
    readonly duringSupportHours?: ServiceIncidentUrgencyRuleDuringSupportHours;
    /**
    * outside_support_hours block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#outside_support_hours Service#outside_support_hours}
    */
    readonly outsideSupportHours?: ServiceIncidentUrgencyRuleOutsideSupportHours;
}
export declare function serviceIncidentUrgencyRuleToTerraform(struct?: ServiceIncidentUrgencyRuleOutputReference | ServiceIncidentUrgencyRule): any;
export declare function serviceIncidentUrgencyRuleToHclTerraform(struct?: ServiceIncidentUrgencyRuleOutputReference | ServiceIncidentUrgencyRule): any;
export declare class ServiceIncidentUrgencyRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceIncidentUrgencyRule | undefined;
    set internalValue(value: ServiceIncidentUrgencyRule | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _urgency?;
    get urgency(): string;
    set urgency(value: string);
    resetUrgency(): void;
    get urgencyInput(): string | undefined;
    private _duringSupportHours;
    get duringSupportHours(): ServiceIncidentUrgencyRuleDuringSupportHoursOutputReference;
    putDuringSupportHours(value: ServiceIncidentUrgencyRuleDuringSupportHours): void;
    resetDuringSupportHours(): void;
    get duringSupportHoursInput(): ServiceIncidentUrgencyRuleDuringSupportHours | undefined;
    private _outsideSupportHours;
    get outsideSupportHours(): ServiceIncidentUrgencyRuleOutsideSupportHoursOutputReference;
    putOutsideSupportHours(value: ServiceIncidentUrgencyRuleOutsideSupportHours): void;
    resetOutsideSupportHours(): void;
    get outsideSupportHoursInput(): ServiceIncidentUrgencyRuleOutsideSupportHours | undefined;
}
export interface ServiceScheduledActionsAt {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#name Service#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#type Service#type}
    */
    readonly type?: string;
}
export declare function serviceScheduledActionsAtToTerraform(struct?: ServiceScheduledActionsAt | cdktn.IResolvable): any;
export declare function serviceScheduledActionsAtToHclTerraform(struct?: ServiceScheduledActionsAt | cdktn.IResolvable): any;
export declare class ServiceScheduledActionsAtOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceScheduledActionsAt | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceScheduledActionsAt | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class ServiceScheduledActionsAtList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceScheduledActionsAt[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceScheduledActionsAtOutputReference;
}
export interface ServiceScheduledActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#to_urgency Service#to_urgency}
    */
    readonly toUrgency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#type Service#type}
    */
    readonly type?: string;
    /**
    * at block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#at Service#at}
    */
    readonly at?: ServiceScheduledActionsAt[] | cdktn.IResolvable;
}
export declare function serviceScheduledActionsToTerraform(struct?: ServiceScheduledActions | cdktn.IResolvable): any;
export declare function serviceScheduledActionsToHclTerraform(struct?: ServiceScheduledActions | cdktn.IResolvable): any;
export declare class ServiceScheduledActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceScheduledActions | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceScheduledActions | cdktn.IResolvable | undefined);
    private _toUrgency?;
    get toUrgency(): string;
    set toUrgency(value: string);
    resetToUrgency(): void;
    get toUrgencyInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _at;
    get at(): ServiceScheduledActionsAtList;
    putAt(value: ServiceScheduledActionsAt[] | cdktn.IResolvable): void;
    resetAt(): void;
    get atInput(): cdktn.IResolvable | ServiceScheduledActionsAt[] | undefined;
}
export declare class ServiceScheduledActionsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ServiceScheduledActions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceScheduledActionsOutputReference;
}
export interface ServiceSupportHours {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#days_of_week Service#days_of_week}
    */
    readonly daysOfWeek?: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#end_time Service#end_time}
    */
    readonly endTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#start_time Service#start_time}
    */
    readonly startTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#time_zone Service#time_zone}
    */
    readonly timeZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#type Service#type}
    */
    readonly type?: string;
}
export declare function serviceSupportHoursToTerraform(struct?: ServiceSupportHoursOutputReference | ServiceSupportHours): any;
export declare function serviceSupportHoursToHclTerraform(struct?: ServiceSupportHoursOutputReference | ServiceSupportHours): any;
export declare class ServiceSupportHoursOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceSupportHours | undefined;
    set internalValue(value: ServiceSupportHours | undefined);
    private _daysOfWeek?;
    get daysOfWeek(): number[];
    set daysOfWeek(value: number[]);
    resetDaysOfWeek(): void;
    get daysOfWeekInput(): number[] | undefined;
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    resetEndTime(): void;
    get endTimeInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    resetTimeZone(): void;
    get timeZoneInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service pagerduty_service}
*/
export declare class Service extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_service";
    /**
    * Generates CDKTN code for importing a Service resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Service to import
    * @param importFromId The id of the existing Service that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Service to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/service pagerduty_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServiceConfig
    */
    constructor(scope: Construct, id: string, config: ServiceConfig);
    private _acknowledgementTimeout?;
    get acknowledgementTimeout(): string;
    set acknowledgementTimeout(value: string);
    resetAcknowledgementTimeout(): void;
    get acknowledgementTimeoutInput(): string | undefined;
    private _alertCreation?;
    get alertCreation(): string;
    set alertCreation(value: string);
    resetAlertCreation(): void;
    get alertCreationInput(): string | undefined;
    private _alertGrouping?;
    get alertGrouping(): string;
    set alertGrouping(value: string);
    resetAlertGrouping(): void;
    get alertGroupingInput(): string | undefined;
    private _alertGroupingTimeout?;
    get alertGroupingTimeout(): string;
    set alertGroupingTimeout(value: string);
    resetAlertGroupingTimeout(): void;
    get alertGroupingTimeoutInput(): string | undefined;
    private _autoResolveTimeout?;
    get autoResolveTimeout(): string;
    set autoResolveTimeout(value: string);
    resetAutoResolveTimeout(): void;
    get autoResolveTimeoutInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _escalationPolicy?;
    get escalationPolicy(): string;
    set escalationPolicy(value: string);
    get escalationPolicyInput(): string | undefined;
    get htmlUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastIncidentTimestamp(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _responsePlay?;
    get responsePlay(): string;
    set responsePlay(value: string);
    resetResponsePlay(): void;
    get responsePlayInput(): string | undefined;
    get status(): string;
    get type(): string;
    private _alertGroupingParameters;
    get alertGroupingParameters(): ServiceAlertGroupingParametersOutputReference;
    putAlertGroupingParameters(value: ServiceAlertGroupingParameters): void;
    resetAlertGroupingParameters(): void;
    get alertGroupingParametersInput(): ServiceAlertGroupingParameters | undefined;
    private _autoPauseNotificationsParameters;
    get autoPauseNotificationsParameters(): ServiceAutoPauseNotificationsParametersOutputReference;
    putAutoPauseNotificationsParameters(value: ServiceAutoPauseNotificationsParameters): void;
    resetAutoPauseNotificationsParameters(): void;
    get autoPauseNotificationsParametersInput(): ServiceAutoPauseNotificationsParameters | undefined;
    private _incidentUrgencyRule;
    get incidentUrgencyRule(): ServiceIncidentUrgencyRuleOutputReference;
    putIncidentUrgencyRule(value: ServiceIncidentUrgencyRule): void;
    resetIncidentUrgencyRule(): void;
    get incidentUrgencyRuleInput(): ServiceIncidentUrgencyRule | undefined;
    private _scheduledActions;
    get scheduledActions(): ServiceScheduledActionsList;
    putScheduledActions(value: ServiceScheduledActions[] | cdktn.IResolvable): void;
    resetScheduledActions(): void;
    get scheduledActionsInput(): cdktn.IResolvable | ServiceScheduledActions[] | undefined;
    private _supportHours;
    get supportHours(): ServiceSupportHoursOutputReference;
    putSupportHours(value: ServiceSupportHours): void;
    resetSupportHours(): void;
    get supportHoursInput(): ServiceSupportHours | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
