/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPagerdutyStandardsResourcesScoresConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/standards_resources_scores#ids DataPagerdutyStandardsResourcesScores#ids}
    */
    readonly ids: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/standards_resources_scores#resource_type DataPagerdutyStandardsResourcesScores#resource_type}
    */
    readonly resourceType: string;
}
export interface DataPagerdutyStandardsResourcesScoresResourcesScore {
}
export declare function dataPagerdutyStandardsResourcesScoresResourcesScoreToTerraform(struct?: DataPagerdutyStandardsResourcesScoresResourcesScore): any;
export declare function dataPagerdutyStandardsResourcesScoresResourcesScoreToHclTerraform(struct?: DataPagerdutyStandardsResourcesScoresResourcesScore): any;
export declare class DataPagerdutyStandardsResourcesScoresResourcesScoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataPagerdutyStandardsResourcesScoresResourcesScore | undefined;
    set internalValue(value: DataPagerdutyStandardsResourcesScoresResourcesScore | undefined);
    get passing(): number;
    get total(): number;
}
export interface DataPagerdutyStandardsResourcesScoresResourcesStandards {
}
export declare function dataPagerdutyStandardsResourcesScoresResourcesStandardsToTerraform(struct?: DataPagerdutyStandardsResourcesScoresResourcesStandards): any;
export declare function dataPagerdutyStandardsResourcesScoresResourcesStandardsToHclTerraform(struct?: DataPagerdutyStandardsResourcesScoresResourcesStandards): any;
export declare class DataPagerdutyStandardsResourcesScoresResourcesStandardsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyStandardsResourcesScoresResourcesStandards | undefined;
    set internalValue(value: DataPagerdutyStandardsResourcesScoresResourcesStandards | undefined);
    get active(): cdktn.IResolvable;
    get description(): string;
    get id(): string;
    get name(): string;
    get pass(): cdktn.IResolvable;
    get type(): string;
}
export declare class DataPagerdutyStandardsResourcesScoresResourcesStandardsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyStandardsResourcesScoresResourcesStandardsOutputReference;
}
export interface DataPagerdutyStandardsResourcesScoresResources {
}
export declare function dataPagerdutyStandardsResourcesScoresResourcesToTerraform(struct?: DataPagerdutyStandardsResourcesScoresResources): any;
export declare function dataPagerdutyStandardsResourcesScoresResourcesToHclTerraform(struct?: DataPagerdutyStandardsResourcesScoresResources): any;
export declare class DataPagerdutyStandardsResourcesScoresResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyStandardsResourcesScoresResources | undefined;
    set internalValue(value: DataPagerdutyStandardsResourcesScoresResources | undefined);
    get resourceId(): string;
    get resourceType(): string;
    private _score;
    get score(): DataPagerdutyStandardsResourcesScoresResourcesScoreOutputReference;
    private _standards;
    get standards(): DataPagerdutyStandardsResourcesScoresResourcesStandardsList;
}
export declare class DataPagerdutyStandardsResourcesScoresResourcesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyStandardsResourcesScoresResourcesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/standards_resources_scores pagerduty_standards_resources_scores}
*/
export declare class DataPagerdutyStandardsResourcesScores extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_standards_resources_scores";
    /**
    * Generates CDKTN code for importing a DataPagerdutyStandardsResourcesScores resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyStandardsResourcesScores to import
    * @param importFromId The id of the existing DataPagerdutyStandardsResourcesScores that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/standards_resources_scores#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyStandardsResourcesScores to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/standards_resources_scores pagerduty_standards_resources_scores} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyStandardsResourcesScoresConfig
    */
    constructor(scope: Construct, id: string, config: DataPagerdutyStandardsResourcesScoresConfig);
    private _ids?;
    get ids(): string[];
    set ids(value: string[]);
    get idsInput(): string[] | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    private _resources;
    get resources(): DataPagerdutyStandardsResourcesScoresResourcesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
