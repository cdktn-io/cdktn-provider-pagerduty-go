/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPagerdutyEventOrchestrationServiceCacheVariableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/event_orchestration_service_cache_variable#id DataPagerdutyEventOrchestrationServiceCacheVariable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/event_orchestration_service_cache_variable#name DataPagerdutyEventOrchestrationServiceCacheVariable#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/event_orchestration_service_cache_variable#service DataPagerdutyEventOrchestrationServiceCacheVariable#service}
    */
    readonly service: string;
}
export interface DataPagerdutyEventOrchestrationServiceCacheVariableCondition {
}
export declare function dataPagerdutyEventOrchestrationServiceCacheVariableConditionToTerraform(struct?: DataPagerdutyEventOrchestrationServiceCacheVariableCondition): any;
export declare function dataPagerdutyEventOrchestrationServiceCacheVariableConditionToHclTerraform(struct?: DataPagerdutyEventOrchestrationServiceCacheVariableCondition): any;
export declare class DataPagerdutyEventOrchestrationServiceCacheVariableConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyEventOrchestrationServiceCacheVariableCondition | undefined;
    set internalValue(value: DataPagerdutyEventOrchestrationServiceCacheVariableCondition | undefined);
    get expression(): string;
}
export declare class DataPagerdutyEventOrchestrationServiceCacheVariableConditionList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyEventOrchestrationServiceCacheVariableConditionOutputReference;
}
export interface DataPagerdutyEventOrchestrationServiceCacheVariableConfiguration {
}
export declare function dataPagerdutyEventOrchestrationServiceCacheVariableConfigurationToTerraform(struct?: DataPagerdutyEventOrchestrationServiceCacheVariableConfiguration): any;
export declare function dataPagerdutyEventOrchestrationServiceCacheVariableConfigurationToHclTerraform(struct?: DataPagerdutyEventOrchestrationServiceCacheVariableConfiguration): any;
export declare class DataPagerdutyEventOrchestrationServiceCacheVariableConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyEventOrchestrationServiceCacheVariableConfiguration | undefined;
    set internalValue(value: DataPagerdutyEventOrchestrationServiceCacheVariableConfiguration | undefined);
    get dataType(): string;
    get regex(): string;
    get source(): string;
    get ttlSeconds(): number;
    get type(): string;
}
export declare class DataPagerdutyEventOrchestrationServiceCacheVariableConfigurationList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyEventOrchestrationServiceCacheVariableConfigurationOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/event_orchestration_service_cache_variable pagerduty_event_orchestration_service_cache_variable}
*/
export declare class DataPagerdutyEventOrchestrationServiceCacheVariable extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_event_orchestration_service_cache_variable";
    /**
    * Generates CDKTN code for importing a DataPagerdutyEventOrchestrationServiceCacheVariable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyEventOrchestrationServiceCacheVariable to import
    * @param importFromId The id of the existing DataPagerdutyEventOrchestrationServiceCacheVariable that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/event_orchestration_service_cache_variable#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyEventOrchestrationServiceCacheVariable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/event_orchestration_service_cache_variable pagerduty_event_orchestration_service_cache_variable} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyEventOrchestrationServiceCacheVariableConfig
    */
    constructor(scope: Construct, id: string, config: DataPagerdutyEventOrchestrationServiceCacheVariableConfig);
    private _condition;
    get condition(): DataPagerdutyEventOrchestrationServiceCacheVariableConditionList;
    private _configuration;
    get configuration(): DataPagerdutyEventOrchestrationServiceCacheVariableConfigurationList;
    get disabled(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
