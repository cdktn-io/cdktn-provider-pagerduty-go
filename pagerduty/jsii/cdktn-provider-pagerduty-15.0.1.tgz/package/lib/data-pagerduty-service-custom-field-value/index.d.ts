/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPagerdutyServiceCustomFieldValueConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the service to get custom field values for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/service_custom_field_value#service_id DataPagerdutyServiceCustomFieldValue#service_id}
    */
    readonly serviceId: string;
}
export interface DataPagerdutyServiceCustomFieldValueCustomFields {
}
export declare function dataPagerdutyServiceCustomFieldValueCustomFieldsToTerraform(struct?: DataPagerdutyServiceCustomFieldValueCustomFields): any;
export declare function dataPagerdutyServiceCustomFieldValueCustomFieldsToHclTerraform(struct?: DataPagerdutyServiceCustomFieldValueCustomFields): any;
export declare class DataPagerdutyServiceCustomFieldValueCustomFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyServiceCustomFieldValueCustomFields | undefined;
    set internalValue(value: DataPagerdutyServiceCustomFieldValueCustomFields | undefined);
    get dataType(): string;
    get description(): string;
    get displayName(): string;
    get fieldType(): string;
    get id(): string;
    get name(): string;
    get type(): string;
    get value(): string;
}
export declare class DataPagerdutyServiceCustomFieldValueCustomFieldsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyServiceCustomFieldValueCustomFieldsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/service_custom_field_value pagerduty_service_custom_field_value}
*/
export declare class DataPagerdutyServiceCustomFieldValue extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_service_custom_field_value";
    /**
    * Generates CDKTN code for importing a DataPagerdutyServiceCustomFieldValue resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyServiceCustomFieldValue to import
    * @param importFromId The id of the existing DataPagerdutyServiceCustomFieldValue that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/service_custom_field_value#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyServiceCustomFieldValue to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/service_custom_field_value pagerduty_service_custom_field_value} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyServiceCustomFieldValueConfig
    */
    constructor(scope: Construct, id: string, config: DataPagerdutyServiceCustomFieldValueConfig);
    private _customFields;
    get customFields(): DataPagerdutyServiceCustomFieldValueCustomFieldsList;
    get id(): string;
    private _serviceId?;
    get serviceId(): string;
    set serviceId(value: string);
    get serviceIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
