/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WebhookSubscriptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/webhook_subscription#active WebhookSubscription#active}
    */
    readonly active?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/webhook_subscription#description WebhookSubscription#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/webhook_subscription#events WebhookSubscription#events}
    */
    readonly events: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/webhook_subscription#id WebhookSubscription#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/webhook_subscription#type WebhookSubscription#type}
    */
    readonly type?: string;
    /**
    * delivery_method block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/webhook_subscription#delivery_method WebhookSubscription#delivery_method}
    */
    readonly deliveryMethod: WebhookSubscriptionDeliveryMethod[] | cdktn.IResolvable;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/webhook_subscription#filter WebhookSubscription#filter}
    */
    readonly filter: WebhookSubscriptionFilter[] | cdktn.IResolvable;
}
export interface WebhookSubscriptionDeliveryMethodCustomHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/webhook_subscription#name WebhookSubscription#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/webhook_subscription#value WebhookSubscription#value}
    */
    readonly value: string;
}
export declare function webhookSubscriptionDeliveryMethodCustomHeaderToTerraform(struct?: WebhookSubscriptionDeliveryMethodCustomHeader | cdktn.IResolvable): any;
export declare function webhookSubscriptionDeliveryMethodCustomHeaderToHclTerraform(struct?: WebhookSubscriptionDeliveryMethodCustomHeader | cdktn.IResolvable): any;
export declare class WebhookSubscriptionDeliveryMethodCustomHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WebhookSubscriptionDeliveryMethodCustomHeader | cdktn.IResolvable | undefined;
    set internalValue(value: WebhookSubscriptionDeliveryMethodCustomHeader | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class WebhookSubscriptionDeliveryMethodCustomHeaderList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WebhookSubscriptionDeliveryMethodCustomHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WebhookSubscriptionDeliveryMethodCustomHeaderOutputReference;
}
export interface WebhookSubscriptionDeliveryMethod {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/webhook_subscription#temporarily_disabled WebhookSubscription#temporarily_disabled}
    */
    readonly temporarilyDisabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/webhook_subscription#type WebhookSubscription#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/webhook_subscription#url WebhookSubscription#url}
    */
    readonly url?: string;
    /**
    * custom_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/webhook_subscription#custom_header WebhookSubscription#custom_header}
    */
    readonly customHeader?: WebhookSubscriptionDeliveryMethodCustomHeader[] | cdktn.IResolvable;
}
export declare function webhookSubscriptionDeliveryMethodToTerraform(struct?: WebhookSubscriptionDeliveryMethod | cdktn.IResolvable): any;
export declare function webhookSubscriptionDeliveryMethodToHclTerraform(struct?: WebhookSubscriptionDeliveryMethod | cdktn.IResolvable): any;
export declare class WebhookSubscriptionDeliveryMethodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WebhookSubscriptionDeliveryMethod | cdktn.IResolvable | undefined;
    set internalValue(value: WebhookSubscriptionDeliveryMethod | cdktn.IResolvable | undefined);
    private _temporarilyDisabled?;
    get temporarilyDisabled(): boolean | cdktn.IResolvable;
    set temporarilyDisabled(value: boolean | cdktn.IResolvable);
    resetTemporarilyDisabled(): void;
    get temporarilyDisabledInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _customHeader;
    get customHeader(): WebhookSubscriptionDeliveryMethodCustomHeaderList;
    putCustomHeader(value: WebhookSubscriptionDeliveryMethodCustomHeader[] | cdktn.IResolvable): void;
    resetCustomHeader(): void;
    get customHeaderInput(): cdktn.IResolvable | WebhookSubscriptionDeliveryMethodCustomHeader[] | undefined;
}
export declare class WebhookSubscriptionDeliveryMethodList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WebhookSubscriptionDeliveryMethod[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WebhookSubscriptionDeliveryMethodOutputReference;
}
export interface WebhookSubscriptionFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/webhook_subscription#id WebhookSubscription#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/webhook_subscription#type WebhookSubscription#type}
    */
    readonly type: string;
}
export declare function webhookSubscriptionFilterToTerraform(struct?: WebhookSubscriptionFilter | cdktn.IResolvable): any;
export declare function webhookSubscriptionFilterToHclTerraform(struct?: WebhookSubscriptionFilter | cdktn.IResolvable): any;
export declare class WebhookSubscriptionFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WebhookSubscriptionFilter | cdktn.IResolvable | undefined;
    set internalValue(value: WebhookSubscriptionFilter | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class WebhookSubscriptionFilterList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: WebhookSubscriptionFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WebhookSubscriptionFilterOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/webhook_subscription pagerduty_webhook_subscription}
*/
export declare class WebhookSubscription extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_webhook_subscription";
    /**
    * Generates CDKTN code for importing a WebhookSubscription resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WebhookSubscription to import
    * @param importFromId The id of the existing WebhookSubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/webhook_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WebhookSubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/webhook_subscription pagerduty_webhook_subscription} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WebhookSubscriptionConfig
    */
    constructor(scope: Construct, id: string, config: WebhookSubscriptionConfig);
    private _active?;
    get active(): boolean | cdktn.IResolvable;
    set active(value: boolean | cdktn.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _events?;
    get events(): string[];
    set events(value: string[]);
    get eventsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _deliveryMethod;
    get deliveryMethod(): WebhookSubscriptionDeliveryMethodList;
    putDeliveryMethod(value: WebhookSubscriptionDeliveryMethod[] | cdktn.IResolvable): void;
    get deliveryMethodInput(): cdktn.IResolvable | WebhookSubscriptionDeliveryMethod[] | undefined;
    private _filter;
    get filter(): WebhookSubscriptionFilterList;
    putFilter(value: WebhookSubscriptionFilter[] | cdktn.IResolvable): void;
    get filterInput(): cdktn.IResolvable | WebhookSubscriptionFilter[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
