/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface UserHandoffNotificationRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The type of handoff to notify for. Possible values are 'both', 'oncall', 'offcall'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/user_handoff_notification_rule#handoff_type UserHandoffNotificationRule#handoff_type}
    */
    readonly handoffType?: string;
    /**
    * The number of minutes before the handoff to notify the user. Must be greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/user_handoff_notification_rule#notify_advance_in_minutes UserHandoffNotificationRule#notify_advance_in_minutes}
    */
    readonly notifyAdvanceInMinutes: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/user_handoff_notification_rule#user_id UserHandoffNotificationRule#user_id}
    */
    readonly userId: string;
    /**
    * contact_method block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/user_handoff_notification_rule#contact_method UserHandoffNotificationRule#contact_method}
    */
    readonly contactMethod?: UserHandoffNotificationRuleContactMethod[] | cdktn.IResolvable;
}
export interface UserHandoffNotificationRuleContactMethod {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/user_handoff_notification_rule#id UserHandoffNotificationRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * The type of contact method to notify for. Possible values are 'email_contact_method', 'email_contact_method_reference', 'phone_contact_method', 'phone_contact_method_reference', 'push_notification_contact_method', 'push_notification_contact_method_reference', 'sms_contact_method', 'sms_contact_method_reference'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/user_handoff_notification_rule#type UserHandoffNotificationRule#type}
    */
    readonly type: string;
}
export declare function userHandoffNotificationRuleContactMethodToTerraform(struct?: UserHandoffNotificationRuleContactMethod | cdktn.IResolvable): any;
export declare function userHandoffNotificationRuleContactMethodToHclTerraform(struct?: UserHandoffNotificationRuleContactMethod | cdktn.IResolvable): any;
export declare class UserHandoffNotificationRuleContactMethodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): UserHandoffNotificationRuleContactMethod | cdktn.IResolvable | undefined;
    set internalValue(value: UserHandoffNotificationRuleContactMethod | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class UserHandoffNotificationRuleContactMethodList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: UserHandoffNotificationRuleContactMethod[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): UserHandoffNotificationRuleContactMethodOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/user_handoff_notification_rule pagerduty_user_handoff_notification_rule}
*/
export declare class UserHandoffNotificationRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_user_handoff_notification_rule";
    /**
    * Generates CDKTN code for importing a UserHandoffNotificationRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UserHandoffNotificationRule to import
    * @param importFromId The id of the existing UserHandoffNotificationRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/user_handoff_notification_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UserHandoffNotificationRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/user_handoff_notification_rule pagerduty_user_handoff_notification_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UserHandoffNotificationRuleConfig
    */
    constructor(scope: Construct, id: string, config: UserHandoffNotificationRuleConfig);
    private _handoffType?;
    get handoffType(): string;
    set handoffType(value: string);
    resetHandoffType(): void;
    get handoffTypeInput(): string | undefined;
    get id(): string;
    private _notifyAdvanceInMinutes?;
    get notifyAdvanceInMinutes(): number;
    set notifyAdvanceInMinutes(value: number);
    get notifyAdvanceInMinutesInput(): number | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    private _contactMethod;
    get contactMethod(): UserHandoffNotificationRuleContactMethodList;
    putContactMethod(value: UserHandoffNotificationRuleContactMethod[] | cdktn.IResolvable): void;
    resetContactMethod(): void;
    get contactMethodInput(): cdktn.IResolvable | UserHandoffNotificationRuleContactMethod[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
