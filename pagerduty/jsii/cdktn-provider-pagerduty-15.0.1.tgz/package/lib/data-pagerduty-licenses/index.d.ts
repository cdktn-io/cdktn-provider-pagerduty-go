/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPagerdutyLicensesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/licenses#id DataPagerdutyLicenses#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataPagerdutyLicensesLicenses {
}
export declare function dataPagerdutyLicensesLicensesToTerraform(struct?: DataPagerdutyLicensesLicenses): any;
export declare function dataPagerdutyLicensesLicensesToHclTerraform(struct?: DataPagerdutyLicensesLicenses): any;
export declare class DataPagerdutyLicensesLicensesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyLicensesLicenses | undefined;
    set internalValue(value: DataPagerdutyLicensesLicenses | undefined);
    get allocationsAvailable(): number;
    get currentValue(): number;
    get description(): string;
    get htmlUrl(): string;
    get id(): string;
    get name(): string;
    get roleGroup(): string;
    get selfAttribute(): string;
    get summary(): string;
    get type(): string;
    get validRoles(): string[];
}
export declare class DataPagerdutyLicensesLicensesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyLicensesLicensesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/licenses pagerduty_licenses}
*/
export declare class DataPagerdutyLicenses extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_licenses";
    /**
    * Generates CDKTN code for importing a DataPagerdutyLicenses resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyLicenses to import
    * @param importFromId The id of the existing DataPagerdutyLicenses that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/licenses#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyLicenses to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/data-sources/licenses pagerduty_licenses} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyLicensesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataPagerdutyLicensesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _licenses;
    get licenses(): DataPagerdutyLicensesLicensesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
