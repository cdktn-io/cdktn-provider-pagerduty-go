/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IncidentWorkflowTriggerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/incident_workflow_trigger#condition IncidentWorkflowTrigger#condition}
    */
    readonly condition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/incident_workflow_trigger#id IncidentWorkflowTrigger#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/incident_workflow_trigger#services IncidentWorkflowTrigger#services}
    */
    readonly services?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/incident_workflow_trigger#subscribed_to_all_services IncidentWorkflowTrigger#subscribed_to_all_services}
    */
    readonly subscribedToAllServices: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/incident_workflow_trigger#type IncidentWorkflowTrigger#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/incident_workflow_trigger#workflow IncidentWorkflowTrigger#workflow}
    */
    readonly workflow: string;
    /**
    * permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/incident_workflow_trigger#permissions IncidentWorkflowTrigger#permissions}
    */
    readonly permissions?: IncidentWorkflowTriggerPermissions;
}
export interface IncidentWorkflowTriggerPermissions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/incident_workflow_trigger#restricted IncidentWorkflowTrigger#restricted}
    */
    readonly restricted?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/incident_workflow_trigger#team_id IncidentWorkflowTrigger#team_id}
    */
    readonly teamId?: string;
}
export declare function incidentWorkflowTriggerPermissionsToTerraform(struct?: IncidentWorkflowTriggerPermissionsOutputReference | IncidentWorkflowTriggerPermissions): any;
export declare function incidentWorkflowTriggerPermissionsToHclTerraform(struct?: IncidentWorkflowTriggerPermissionsOutputReference | IncidentWorkflowTriggerPermissions): any;
export declare class IncidentWorkflowTriggerPermissionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IncidentWorkflowTriggerPermissions | undefined;
    set internalValue(value: IncidentWorkflowTriggerPermissions | undefined);
    private _restricted?;
    get restricted(): boolean | cdktn.IResolvable;
    set restricted(value: boolean | cdktn.IResolvable);
    resetRestricted(): void;
    get restrictedInput(): boolean | cdktn.IResolvable | undefined;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    resetTeamId(): void;
    get teamIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/incident_workflow_trigger pagerduty_incident_workflow_trigger}
*/
export declare class IncidentWorkflowTrigger extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_incident_workflow_trigger";
    /**
    * Generates CDKTN code for importing a IncidentWorkflowTrigger resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IncidentWorkflowTrigger to import
    * @param importFromId The id of the existing IncidentWorkflowTrigger that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/incident_workflow_trigger#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IncidentWorkflowTrigger to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.1/docs/resources/incident_workflow_trigger pagerduty_incident_workflow_trigger} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IncidentWorkflowTriggerConfig
    */
    constructor(scope: Construct, id: string, config: IncidentWorkflowTriggerConfig);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _services?;
    get services(): string[];
    set services(value: string[]);
    resetServices(): void;
    get servicesInput(): string[] | undefined;
    private _subscribedToAllServices?;
    get subscribedToAllServices(): boolean | cdktn.IResolvable;
    set subscribedToAllServices(value: boolean | cdktn.IResolvable);
    get subscribedToAllServicesInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _workflow?;
    get workflow(): string;
    set workflow(value: string);
    get workflowInput(): string | undefined;
    private _permissions;
    get permissions(): IncidentWorkflowTriggerPermissionsOutputReference;
    putPermissions(value: IncidentWorkflowTriggerPermissions): void;
    resetPermissions(): void;
    get permissionsInput(): IncidentWorkflowTriggerPermissions | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
