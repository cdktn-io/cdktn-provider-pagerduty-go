/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ExtensionServicenowConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/extension_servicenow#endpoint_url ExtensionServicenow#endpoint_url}
    */
    readonly endpointUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/extension_servicenow#extension_objects ExtensionServicenow#extension_objects}
    */
    readonly extensionObjects: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/extension_servicenow#extension_schema ExtensionServicenow#extension_schema}
    */
    readonly extensionSchema: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/extension_servicenow#name ExtensionServicenow#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/extension_servicenow#referer ExtensionServicenow#referer}
    */
    readonly referer: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/extension_servicenow#snow_password ExtensionServicenow#snow_password}
    */
    readonly snowPassword: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/extension_servicenow#snow_user ExtensionServicenow#snow_user}
    */
    readonly snowUser: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/extension_servicenow#summary ExtensionServicenow#summary}
    */
    readonly summary?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/extension_servicenow#sync_options ExtensionServicenow#sync_options}
    */
    readonly syncOptions: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/extension_servicenow#target ExtensionServicenow#target}
    */
    readonly target: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/extension_servicenow#task_type ExtensionServicenow#task_type}
    */
    readonly taskType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/extension_servicenow#type ExtensionServicenow#type}
    */
    readonly type?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/extension_servicenow pagerduty_extension_servicenow}
*/
export declare class ExtensionServicenow extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_extension_servicenow";
    /**
    * Generates CDKTN code for importing a ExtensionServicenow resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ExtensionServicenow to import
    * @param importFromId The id of the existing ExtensionServicenow that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/extension_servicenow#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ExtensionServicenow to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/extension_servicenow pagerduty_extension_servicenow} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ExtensionServicenowConfig
    */
    constructor(scope: Construct, id: string, config: ExtensionServicenowConfig);
    private _endpointUrl?;
    get endpointUrl(): string;
    set endpointUrl(value: string);
    resetEndpointUrl(): void;
    get endpointUrlInput(): string | undefined;
    private _extensionObjects?;
    get extensionObjects(): string[];
    set extensionObjects(value: string[]);
    get extensionObjectsInput(): string[] | undefined;
    private _extensionSchema?;
    get extensionSchema(): string;
    set extensionSchema(value: string);
    get extensionSchemaInput(): string | undefined;
    get htmlUrl(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _referer?;
    get referer(): string;
    set referer(value: string);
    get refererInput(): string | undefined;
    private _snowPassword?;
    get snowPassword(): string;
    set snowPassword(value: string);
    get snowPasswordInput(): string | undefined;
    private _snowUser?;
    get snowUser(): string;
    set snowUser(value: string);
    get snowUserInput(): string | undefined;
    private _summary?;
    get summary(): string;
    set summary(value: string);
    resetSummary(): void;
    get summaryInput(): string | undefined;
    private _syncOptions?;
    get syncOptions(): string;
    set syncOptions(value: string);
    get syncOptionsInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _taskType?;
    get taskType(): string;
    set taskType(value: string);
    get taskTypeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
