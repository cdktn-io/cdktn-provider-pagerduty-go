/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IncidentTypeCustomFieldConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/incident_type_custom_field#data_type IncidentTypeCustomField#data_type}
    */
    readonly dataType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/incident_type_custom_field#default_value IncidentTypeCustomField#default_value}
    */
    readonly defaultValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/incident_type_custom_field#description IncidentTypeCustomField#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/incident_type_custom_field#display_name IncidentTypeCustomField#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/incident_type_custom_field#enabled IncidentTypeCustomField#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/incident_type_custom_field#field_options IncidentTypeCustomField#field_options}
    */
    readonly fieldOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/incident_type_custom_field#field_type IncidentTypeCustomField#field_type}
    */
    readonly fieldType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/incident_type_custom_field#incident_type IncidentTypeCustomField#incident_type}
    */
    readonly incidentType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/incident_type_custom_field#name IncidentTypeCustomField#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/incident_type_custom_field pagerduty_incident_type_custom_field}
*/
export declare class IncidentTypeCustomField extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_incident_type_custom_field";
    /**
    * Generates CDKTN code for importing a IncidentTypeCustomField resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IncidentTypeCustomField to import
    * @param importFromId The id of the existing IncidentTypeCustomField that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/incident_type_custom_field#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IncidentTypeCustomField to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/incident_type_custom_field pagerduty_incident_type_custom_field} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IncidentTypeCustomFieldConfig
    */
    constructor(scope: Construct, id: string, config: IncidentTypeCustomFieldConfig);
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    get dataTypeInput(): string | undefined;
    private _defaultValue?;
    get defaultValue(): string;
    set defaultValue(value: string);
    resetDefaultValue(): void;
    get defaultValueInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _fieldOptions?;
    get fieldOptions(): string[];
    set fieldOptions(value: string[]);
    resetFieldOptions(): void;
    get fieldOptionsInput(): string[] | undefined;
    private _fieldType?;
    get fieldType(): string;
    set fieldType(value: string);
    resetFieldType(): void;
    get fieldTypeInput(): string | undefined;
    get id(): string;
    private _incidentType?;
    get incidentType(): string;
    set incidentType(value: string);
    get incidentTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get selfAttribute(): string;
    get summary(): string;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
