/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RulesetRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#catch_all RulesetRule#catch_all}
    */
    readonly catchAll?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#disabled RulesetRule#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#id RulesetRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#position RulesetRule#position}
    */
    readonly position?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#ruleset RulesetRule#ruleset}
    */
    readonly ruleset: string;
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#actions RulesetRule#actions}
    */
    readonly actions?: RulesetRuleActions;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#conditions RulesetRule#conditions}
    */
    readonly conditions?: RulesetRuleConditions;
    /**
    * time_frame block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#time_frame RulesetRule#time_frame}
    */
    readonly timeFrame?: RulesetRuleTimeFrame;
    /**
    * variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#variable RulesetRule#variable}
    */
    readonly variable?: RulesetRuleVariable[] | cdktn.IResolvable;
}
export interface RulesetRuleActionsAnnotate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#value RulesetRule#value}
    */
    readonly value?: string;
}
export declare function rulesetRuleActionsAnnotateToTerraform(struct?: RulesetRuleActionsAnnotate | cdktn.IResolvable): any;
export declare function rulesetRuleActionsAnnotateToHclTerraform(struct?: RulesetRuleActionsAnnotate | cdktn.IResolvable): any;
export declare class RulesetRuleActionsAnnotateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleActionsAnnotate | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRuleActionsAnnotate | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRuleActionsAnnotateList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleActionsAnnotate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleActionsAnnotateOutputReference;
}
export interface RulesetRuleActionsEventAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#value RulesetRule#value}
    */
    readonly value?: string;
}
export declare function rulesetRuleActionsEventActionToTerraform(struct?: RulesetRuleActionsEventAction | cdktn.IResolvable): any;
export declare function rulesetRuleActionsEventActionToHclTerraform(struct?: RulesetRuleActionsEventAction | cdktn.IResolvable): any;
export declare class RulesetRuleActionsEventActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleActionsEventAction | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRuleActionsEventAction | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRuleActionsEventActionList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleActionsEventAction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleActionsEventActionOutputReference;
}
export interface RulesetRuleActionsExtractions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#regex RulesetRule#regex}
    */
    readonly regex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#source RulesetRule#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#target RulesetRule#target}
    */
    readonly target?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#template RulesetRule#template}
    */
    readonly template?: string;
}
export declare function rulesetRuleActionsExtractionsToTerraform(struct?: RulesetRuleActionsExtractions | cdktn.IResolvable): any;
export declare function rulesetRuleActionsExtractionsToHclTerraform(struct?: RulesetRuleActionsExtractions | cdktn.IResolvable): any;
export declare class RulesetRuleActionsExtractionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleActionsExtractions | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRuleActionsExtractions | cdktn.IResolvable | undefined);
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    resetTemplate(): void;
    get templateInput(): string | undefined;
}
export declare class RulesetRuleActionsExtractionsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleActionsExtractions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleActionsExtractionsOutputReference;
}
export interface RulesetRuleActionsPriority {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#value RulesetRule#value}
    */
    readonly value?: string;
}
export declare function rulesetRuleActionsPriorityToTerraform(struct?: RulesetRuleActionsPriority | cdktn.IResolvable): any;
export declare function rulesetRuleActionsPriorityToHclTerraform(struct?: RulesetRuleActionsPriority | cdktn.IResolvable): any;
export declare class RulesetRuleActionsPriorityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleActionsPriority | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRuleActionsPriority | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRuleActionsPriorityList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleActionsPriority[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleActionsPriorityOutputReference;
}
export interface RulesetRuleActionsRoute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#value RulesetRule#value}
    */
    readonly value?: string;
}
export declare function rulesetRuleActionsRouteToTerraform(struct?: RulesetRuleActionsRoute | cdktn.IResolvable): any;
export declare function rulesetRuleActionsRouteToHclTerraform(struct?: RulesetRuleActionsRoute | cdktn.IResolvable): any;
export declare class RulesetRuleActionsRouteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleActionsRoute | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRuleActionsRoute | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRuleActionsRouteList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleActionsRoute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleActionsRouteOutputReference;
}
export interface RulesetRuleActionsSeverity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#value RulesetRule#value}
    */
    readonly value?: string;
}
export declare function rulesetRuleActionsSeverityToTerraform(struct?: RulesetRuleActionsSeverity | cdktn.IResolvable): any;
export declare function rulesetRuleActionsSeverityToHclTerraform(struct?: RulesetRuleActionsSeverity | cdktn.IResolvable): any;
export declare class RulesetRuleActionsSeverityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleActionsSeverity | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRuleActionsSeverity | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRuleActionsSeverityList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleActionsSeverity[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleActionsSeverityOutputReference;
}
export interface RulesetRuleActionsSuppress {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#threshold_time_amount RulesetRule#threshold_time_amount}
    */
    readonly thresholdTimeAmount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#threshold_time_unit RulesetRule#threshold_time_unit}
    */
    readonly thresholdTimeUnit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#threshold_value RulesetRule#threshold_value}
    */
    readonly thresholdValue?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#value RulesetRule#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function rulesetRuleActionsSuppressToTerraform(struct?: RulesetRuleActionsSuppress | cdktn.IResolvable): any;
export declare function rulesetRuleActionsSuppressToHclTerraform(struct?: RulesetRuleActionsSuppress | cdktn.IResolvable): any;
export declare class RulesetRuleActionsSuppressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleActionsSuppress | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRuleActionsSuppress | cdktn.IResolvable | undefined);
    private _thresholdTimeAmount?;
    get thresholdTimeAmount(): number;
    set thresholdTimeAmount(value: number);
    resetThresholdTimeAmount(): void;
    get thresholdTimeAmountInput(): number | undefined;
    private _thresholdTimeUnit?;
    get thresholdTimeUnit(): string;
    set thresholdTimeUnit(value: string);
    resetThresholdTimeUnit(): void;
    get thresholdTimeUnitInput(): string | undefined;
    private _thresholdValue?;
    get thresholdValue(): number;
    set thresholdValue(value: number);
    resetThresholdValue(): void;
    get thresholdValueInput(): number | undefined;
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class RulesetRuleActionsSuppressList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleActionsSuppress[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleActionsSuppressOutputReference;
}
export interface RulesetRuleActionsSuspend {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#value RulesetRule#value}
    */
    readonly value?: number;
}
export declare function rulesetRuleActionsSuspendToTerraform(struct?: RulesetRuleActionsSuspend | cdktn.IResolvable): any;
export declare function rulesetRuleActionsSuspendToHclTerraform(struct?: RulesetRuleActionsSuspend | cdktn.IResolvable): any;
export declare class RulesetRuleActionsSuspendOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleActionsSuspend | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRuleActionsSuspend | cdktn.IResolvable | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export declare class RulesetRuleActionsSuspendList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleActionsSuspend[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleActionsSuspendOutputReference;
}
export interface RulesetRuleActions {
    /**
    * annotate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#annotate RulesetRule#annotate}
    */
    readonly annotate?: RulesetRuleActionsAnnotate[] | cdktn.IResolvable;
    /**
    * event_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#event_action RulesetRule#event_action}
    */
    readonly eventAction?: RulesetRuleActionsEventAction[] | cdktn.IResolvable;
    /**
    * extractions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#extractions RulesetRule#extractions}
    */
    readonly extractions?: RulesetRuleActionsExtractions[] | cdktn.IResolvable;
    /**
    * priority block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#priority RulesetRule#priority}
    */
    readonly priority?: RulesetRuleActionsPriority[] | cdktn.IResolvable;
    /**
    * route block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#route RulesetRule#route}
    */
    readonly route?: RulesetRuleActionsRoute[] | cdktn.IResolvable;
    /**
    * severity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#severity RulesetRule#severity}
    */
    readonly severity?: RulesetRuleActionsSeverity[] | cdktn.IResolvable;
    /**
    * suppress block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#suppress RulesetRule#suppress}
    */
    readonly suppress?: RulesetRuleActionsSuppress[] | cdktn.IResolvable;
    /**
    * suspend block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#suspend RulesetRule#suspend}
    */
    readonly suspend?: RulesetRuleActionsSuspend[] | cdktn.IResolvable;
}
export declare function rulesetRuleActionsToTerraform(struct?: RulesetRuleActionsOutputReference | RulesetRuleActions): any;
export declare function rulesetRuleActionsToHclTerraform(struct?: RulesetRuleActionsOutputReference | RulesetRuleActions): any;
export declare class RulesetRuleActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRuleActions | undefined;
    set internalValue(value: RulesetRuleActions | undefined);
    private _annotate;
    get annotate(): RulesetRuleActionsAnnotateList;
    putAnnotate(value: RulesetRuleActionsAnnotate[] | cdktn.IResolvable): void;
    resetAnnotate(): void;
    get annotateInput(): cdktn.IResolvable | RulesetRuleActionsAnnotate[] | undefined;
    private _eventAction;
    get eventAction(): RulesetRuleActionsEventActionList;
    putEventAction(value: RulesetRuleActionsEventAction[] | cdktn.IResolvable): void;
    resetEventAction(): void;
    get eventActionInput(): cdktn.IResolvable | RulesetRuleActionsEventAction[] | undefined;
    private _extractions;
    get extractions(): RulesetRuleActionsExtractionsList;
    putExtractions(value: RulesetRuleActionsExtractions[] | cdktn.IResolvable): void;
    resetExtractions(): void;
    get extractionsInput(): cdktn.IResolvable | RulesetRuleActionsExtractions[] | undefined;
    private _priority;
    get priority(): RulesetRuleActionsPriorityList;
    putPriority(value: RulesetRuleActionsPriority[] | cdktn.IResolvable): void;
    resetPriority(): void;
    get priorityInput(): cdktn.IResolvable | RulesetRuleActionsPriority[] | undefined;
    private _route;
    get route(): RulesetRuleActionsRouteList;
    putRoute(value: RulesetRuleActionsRoute[] | cdktn.IResolvable): void;
    resetRoute(): void;
    get routeInput(): cdktn.IResolvable | RulesetRuleActionsRoute[] | undefined;
    private _severity;
    get severity(): RulesetRuleActionsSeverityList;
    putSeverity(value: RulesetRuleActionsSeverity[] | cdktn.IResolvable): void;
    resetSeverity(): void;
    get severityInput(): cdktn.IResolvable | RulesetRuleActionsSeverity[] | undefined;
    private _suppress;
    get suppress(): RulesetRuleActionsSuppressList;
    putSuppress(value: RulesetRuleActionsSuppress[] | cdktn.IResolvable): void;
    resetSuppress(): void;
    get suppressInput(): cdktn.IResolvable | RulesetRuleActionsSuppress[] | undefined;
    private _suspend;
    get suspend(): RulesetRuleActionsSuspendList;
    putSuspend(value: RulesetRuleActionsSuspend[] | cdktn.IResolvable): void;
    resetSuspend(): void;
    get suspendInput(): cdktn.IResolvable | RulesetRuleActionsSuspend[] | undefined;
}
export interface RulesetRuleConditionsSubconditionsParameter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#path RulesetRule#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#value RulesetRule#value}
    */
    readonly value?: string;
}
export declare function rulesetRuleConditionsSubconditionsParameterToTerraform(struct?: RulesetRuleConditionsSubconditionsParameter | cdktn.IResolvable): any;
export declare function rulesetRuleConditionsSubconditionsParameterToHclTerraform(struct?: RulesetRuleConditionsSubconditionsParameter | cdktn.IResolvable): any;
export declare class RulesetRuleConditionsSubconditionsParameterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleConditionsSubconditionsParameter | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRuleConditionsSubconditionsParameter | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRuleConditionsSubconditionsParameterList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleConditionsSubconditionsParameter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleConditionsSubconditionsParameterOutputReference;
}
export interface RulesetRuleConditionsSubconditions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#operator RulesetRule#operator}
    */
    readonly operator?: string;
    /**
    * parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#parameter RulesetRule#parameter}
    */
    readonly parameter?: RulesetRuleConditionsSubconditionsParameter[] | cdktn.IResolvable;
}
export declare function rulesetRuleConditionsSubconditionsToTerraform(struct?: RulesetRuleConditionsSubconditions | cdktn.IResolvable): any;
export declare function rulesetRuleConditionsSubconditionsToHclTerraform(struct?: RulesetRuleConditionsSubconditions | cdktn.IResolvable): any;
export declare class RulesetRuleConditionsSubconditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleConditionsSubconditions | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRuleConditionsSubconditions | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _parameter;
    get parameter(): RulesetRuleConditionsSubconditionsParameterList;
    putParameter(value: RulesetRuleConditionsSubconditionsParameter[] | cdktn.IResolvable): void;
    resetParameter(): void;
    get parameterInput(): cdktn.IResolvable | RulesetRuleConditionsSubconditionsParameter[] | undefined;
}
export declare class RulesetRuleConditionsSubconditionsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleConditionsSubconditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleConditionsSubconditionsOutputReference;
}
export interface RulesetRuleConditions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#operator RulesetRule#operator}
    */
    readonly operator?: string;
    /**
    * subconditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#subconditions RulesetRule#subconditions}
    */
    readonly subconditions?: RulesetRuleConditionsSubconditions[] | cdktn.IResolvable;
}
export declare function rulesetRuleConditionsToTerraform(struct?: RulesetRuleConditionsOutputReference | RulesetRuleConditions): any;
export declare function rulesetRuleConditionsToHclTerraform(struct?: RulesetRuleConditionsOutputReference | RulesetRuleConditions): any;
export declare class RulesetRuleConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRuleConditions | undefined;
    set internalValue(value: RulesetRuleConditions | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _subconditions;
    get subconditions(): RulesetRuleConditionsSubconditionsList;
    putSubconditions(value: RulesetRuleConditionsSubconditions[] | cdktn.IResolvable): void;
    resetSubconditions(): void;
    get subconditionsInput(): cdktn.IResolvable | RulesetRuleConditionsSubconditions[] | undefined;
}
export interface RulesetRuleTimeFrameActiveBetween {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#end_time RulesetRule#end_time}
    */
    readonly endTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#start_time RulesetRule#start_time}
    */
    readonly startTime?: number;
}
export declare function rulesetRuleTimeFrameActiveBetweenToTerraform(struct?: RulesetRuleTimeFrameActiveBetween | cdktn.IResolvable): any;
export declare function rulesetRuleTimeFrameActiveBetweenToHclTerraform(struct?: RulesetRuleTimeFrameActiveBetween | cdktn.IResolvable): any;
export declare class RulesetRuleTimeFrameActiveBetweenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleTimeFrameActiveBetween | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRuleTimeFrameActiveBetween | cdktn.IResolvable | undefined);
    private _endTime?;
    get endTime(): number;
    set endTime(value: number);
    resetEndTime(): void;
    get endTimeInput(): number | undefined;
    private _startTime?;
    get startTime(): number;
    set startTime(value: number);
    resetStartTime(): void;
    get startTimeInput(): number | undefined;
}
export declare class RulesetRuleTimeFrameActiveBetweenList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleTimeFrameActiveBetween[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleTimeFrameActiveBetweenOutputReference;
}
export interface RulesetRuleTimeFrameScheduledWeekly {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#duration RulesetRule#duration}
    */
    readonly duration?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#start_time RulesetRule#start_time}
    */
    readonly startTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#timezone RulesetRule#timezone}
    */
    readonly timezone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#weekdays RulesetRule#weekdays}
    */
    readonly weekdays?: number[];
}
export declare function rulesetRuleTimeFrameScheduledWeeklyToTerraform(struct?: RulesetRuleTimeFrameScheduledWeekly | cdktn.IResolvable): any;
export declare function rulesetRuleTimeFrameScheduledWeeklyToHclTerraform(struct?: RulesetRuleTimeFrameScheduledWeekly | cdktn.IResolvable): any;
export declare class RulesetRuleTimeFrameScheduledWeeklyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleTimeFrameScheduledWeekly | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRuleTimeFrameScheduledWeekly | cdktn.IResolvable | undefined);
    private _duration?;
    get duration(): number;
    set duration(value: number);
    resetDuration(): void;
    get durationInput(): number | undefined;
    private _startTime?;
    get startTime(): number;
    set startTime(value: number);
    resetStartTime(): void;
    get startTimeInput(): number | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
    private _weekdays?;
    get weekdays(): number[];
    set weekdays(value: number[]);
    resetWeekdays(): void;
    get weekdaysInput(): number[] | undefined;
}
export declare class RulesetRuleTimeFrameScheduledWeeklyList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleTimeFrameScheduledWeekly[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleTimeFrameScheduledWeeklyOutputReference;
}
export interface RulesetRuleTimeFrame {
    /**
    * active_between block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#active_between RulesetRule#active_between}
    */
    readonly activeBetween?: RulesetRuleTimeFrameActiveBetween[] | cdktn.IResolvable;
    /**
    * scheduled_weekly block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#scheduled_weekly RulesetRule#scheduled_weekly}
    */
    readonly scheduledWeekly?: RulesetRuleTimeFrameScheduledWeekly[] | cdktn.IResolvable;
}
export declare function rulesetRuleTimeFrameToTerraform(struct?: RulesetRuleTimeFrameOutputReference | RulesetRuleTimeFrame): any;
export declare function rulesetRuleTimeFrameToHclTerraform(struct?: RulesetRuleTimeFrameOutputReference | RulesetRuleTimeFrame): any;
export declare class RulesetRuleTimeFrameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRuleTimeFrame | undefined;
    set internalValue(value: RulesetRuleTimeFrame | undefined);
    private _activeBetween;
    get activeBetween(): RulesetRuleTimeFrameActiveBetweenList;
    putActiveBetween(value: RulesetRuleTimeFrameActiveBetween[] | cdktn.IResolvable): void;
    resetActiveBetween(): void;
    get activeBetweenInput(): cdktn.IResolvable | RulesetRuleTimeFrameActiveBetween[] | undefined;
    private _scheduledWeekly;
    get scheduledWeekly(): RulesetRuleTimeFrameScheduledWeeklyList;
    putScheduledWeekly(value: RulesetRuleTimeFrameScheduledWeekly[] | cdktn.IResolvable): void;
    resetScheduledWeekly(): void;
    get scheduledWeeklyInput(): cdktn.IResolvable | RulesetRuleTimeFrameScheduledWeekly[] | undefined;
}
export interface RulesetRuleVariableParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#path RulesetRule#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#value RulesetRule#value}
    */
    readonly value?: string;
}
export declare function rulesetRuleVariableParametersToTerraform(struct?: RulesetRuleVariableParameters | cdktn.IResolvable): any;
export declare function rulesetRuleVariableParametersToHclTerraform(struct?: RulesetRuleVariableParameters | cdktn.IResolvable): any;
export declare class RulesetRuleVariableParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleVariableParameters | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRuleVariableParameters | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRuleVariableParametersList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleVariableParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleVariableParametersOutputReference;
}
export interface RulesetRuleVariable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#name RulesetRule#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#type RulesetRule#type}
    */
    readonly type?: string;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#parameters RulesetRule#parameters}
    */
    readonly parameters?: RulesetRuleVariableParameters[] | cdktn.IResolvable;
}
export declare function rulesetRuleVariableToTerraform(struct?: RulesetRuleVariable | cdktn.IResolvable): any;
export declare function rulesetRuleVariableToHclTerraform(struct?: RulesetRuleVariable | cdktn.IResolvable): any;
export declare class RulesetRuleVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRuleVariable | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRuleVariable | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _parameters;
    get parameters(): RulesetRuleVariableParametersList;
    putParameters(value: RulesetRuleVariableParameters[] | cdktn.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | RulesetRuleVariableParameters[] | undefined;
}
export declare class RulesetRuleVariableList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRuleVariable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRuleVariableOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule pagerduty_ruleset_rule}
*/
export declare class RulesetRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_ruleset_rule";
    /**
    * Generates CDKTN code for importing a RulesetRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RulesetRule to import
    * @param importFromId The id of the existing RulesetRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RulesetRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/ruleset_rule pagerduty_ruleset_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RulesetRuleConfig
    */
    constructor(scope: Construct, id: string, config: RulesetRuleConfig);
    private _catchAll?;
    get catchAll(): boolean | cdktn.IResolvable;
    set catchAll(value: boolean | cdktn.IResolvable);
    resetCatchAll(): void;
    get catchAllInput(): boolean | cdktn.IResolvable | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _position?;
    get position(): number;
    set position(value: number);
    resetPosition(): void;
    get positionInput(): number | undefined;
    private _ruleset?;
    get ruleset(): string;
    set ruleset(value: string);
    get rulesetInput(): string | undefined;
    private _actions;
    get actions(): RulesetRuleActionsOutputReference;
    putActions(value: RulesetRuleActions): void;
    resetActions(): void;
    get actionsInput(): RulesetRuleActions | undefined;
    private _conditions;
    get conditions(): RulesetRuleConditionsOutputReference;
    putConditions(value: RulesetRuleConditions): void;
    resetConditions(): void;
    get conditionsInput(): RulesetRuleConditions | undefined;
    private _timeFrame;
    get timeFrame(): RulesetRuleTimeFrameOutputReference;
    putTimeFrame(value: RulesetRuleTimeFrame): void;
    resetTimeFrame(): void;
    get timeFrameInput(): RulesetRuleTimeFrame | undefined;
    private _variable;
    get variable(): RulesetRuleVariableList;
    putVariable(value: RulesetRuleVariable[] | cdktn.IResolvable): void;
    resetVariable(): void;
    get variableInput(): cdktn.IResolvable | RulesetRuleVariable[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
