/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EventOrchestrationGlobalConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#event_orchestration EventOrchestrationGlobal#event_orchestration}
    */
    readonly eventOrchestration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#id EventOrchestrationGlobal#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * catch_all block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#catch_all EventOrchestrationGlobal#catch_all}
    */
    readonly catchAll: EventOrchestrationGlobalCatchAll;
    /**
    * set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#set EventOrchestrationGlobal#set}
    */
    readonly set: EventOrchestrationGlobalSet[] | cdktn.IResolvable;
}
export interface EventOrchestrationGlobalCatchAllActionsAutomationActionHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#key EventOrchestrationGlobal#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#value EventOrchestrationGlobal#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationGlobalCatchAllActionsAutomationActionHeaderToTerraform(struct?: EventOrchestrationGlobalCatchAllActionsAutomationActionHeader | cdktn.IResolvable): any;
export declare function eventOrchestrationGlobalCatchAllActionsAutomationActionHeaderToHclTerraform(struct?: EventOrchestrationGlobalCatchAllActionsAutomationActionHeader | cdktn.IResolvable): any;
export declare class EventOrchestrationGlobalCatchAllActionsAutomationActionHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalCatchAllActionsAutomationActionHeader | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalCatchAllActionsAutomationActionHeader | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationGlobalCatchAllActionsAutomationActionHeaderList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalCatchAllActionsAutomationActionHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalCatchAllActionsAutomationActionHeaderOutputReference;
}
export interface EventOrchestrationGlobalCatchAllActionsAutomationActionParameter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#key EventOrchestrationGlobal#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#value EventOrchestrationGlobal#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationGlobalCatchAllActionsAutomationActionParameterToTerraform(struct?: EventOrchestrationGlobalCatchAllActionsAutomationActionParameter | cdktn.IResolvable): any;
export declare function eventOrchestrationGlobalCatchAllActionsAutomationActionParameterToHclTerraform(struct?: EventOrchestrationGlobalCatchAllActionsAutomationActionParameter | cdktn.IResolvable): any;
export declare class EventOrchestrationGlobalCatchAllActionsAutomationActionParameterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalCatchAllActionsAutomationActionParameter | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalCatchAllActionsAutomationActionParameter | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationGlobalCatchAllActionsAutomationActionParameterList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalCatchAllActionsAutomationActionParameter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalCatchAllActionsAutomationActionParameterOutputReference;
}
export interface EventOrchestrationGlobalCatchAllActionsAutomationAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#auto_send EventOrchestrationGlobal#auto_send}
    */
    readonly autoSend?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#name EventOrchestrationGlobal#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#trigger_types EventOrchestrationGlobal#trigger_types}
    */
    readonly triggerTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#url EventOrchestrationGlobal#url}
    */
    readonly url: string;
    /**
    * header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#header EventOrchestrationGlobal#header}
    */
    readonly header?: EventOrchestrationGlobalCatchAllActionsAutomationActionHeader[] | cdktn.IResolvable;
    /**
    * parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#parameter EventOrchestrationGlobal#parameter}
    */
    readonly parameter?: EventOrchestrationGlobalCatchAllActionsAutomationActionParameter[] | cdktn.IResolvable;
}
export declare function eventOrchestrationGlobalCatchAllActionsAutomationActionToTerraform(struct?: EventOrchestrationGlobalCatchAllActionsAutomationActionOutputReference | EventOrchestrationGlobalCatchAllActionsAutomationAction): any;
export declare function eventOrchestrationGlobalCatchAllActionsAutomationActionToHclTerraform(struct?: EventOrchestrationGlobalCatchAllActionsAutomationActionOutputReference | EventOrchestrationGlobalCatchAllActionsAutomationAction): any;
export declare class EventOrchestrationGlobalCatchAllActionsAutomationActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationGlobalCatchAllActionsAutomationAction | undefined;
    set internalValue(value: EventOrchestrationGlobalCatchAllActionsAutomationAction | undefined);
    private _autoSend?;
    get autoSend(): boolean | cdktn.IResolvable;
    set autoSend(value: boolean | cdktn.IResolvable);
    resetAutoSend(): void;
    get autoSendInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _triggerTypes?;
    get triggerTypes(): string[];
    set triggerTypes(value: string[]);
    resetTriggerTypes(): void;
    get triggerTypesInput(): string[] | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _header;
    get header(): EventOrchestrationGlobalCatchAllActionsAutomationActionHeaderList;
    putHeader(value: EventOrchestrationGlobalCatchAllActionsAutomationActionHeader[] | cdktn.IResolvable): void;
    resetHeader(): void;
    get headerInput(): cdktn.IResolvable | EventOrchestrationGlobalCatchAllActionsAutomationActionHeader[] | undefined;
    private _parameter;
    get parameter(): EventOrchestrationGlobalCatchAllActionsAutomationActionParameterList;
    putParameter(value: EventOrchestrationGlobalCatchAllActionsAutomationActionParameter[] | cdktn.IResolvable): void;
    resetParameter(): void;
    get parameterInput(): cdktn.IResolvable | EventOrchestrationGlobalCatchAllActionsAutomationActionParameter[] | undefined;
}
export interface EventOrchestrationGlobalCatchAllActionsExtraction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#regex EventOrchestrationGlobal#regex}
    */
    readonly regex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#source EventOrchestrationGlobal#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#target EventOrchestrationGlobal#target}
    */
    readonly target: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#template EventOrchestrationGlobal#template}
    */
    readonly template?: string;
}
export declare function eventOrchestrationGlobalCatchAllActionsExtractionToTerraform(struct?: EventOrchestrationGlobalCatchAllActionsExtraction | cdktn.IResolvable): any;
export declare function eventOrchestrationGlobalCatchAllActionsExtractionToHclTerraform(struct?: EventOrchestrationGlobalCatchAllActionsExtraction | cdktn.IResolvable): any;
export declare class EventOrchestrationGlobalCatchAllActionsExtractionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalCatchAllActionsExtraction | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalCatchAllActionsExtraction | cdktn.IResolvable | undefined);
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    resetTemplate(): void;
    get templateInput(): string | undefined;
}
export declare class EventOrchestrationGlobalCatchAllActionsExtractionList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalCatchAllActionsExtraction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalCatchAllActionsExtractionOutputReference;
}
export interface EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#id EventOrchestrationGlobal#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#value EventOrchestrationGlobal#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdateToTerraform(struct?: EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdate | cdktn.IResolvable): any;
export declare function eventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdateToHclTerraform(struct?: EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdate | cdktn.IResolvable): any;
export declare class EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdate | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdate | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdateList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdateOutputReference;
}
export interface EventOrchestrationGlobalCatchAllActionsVariable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#name EventOrchestrationGlobal#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#path EventOrchestrationGlobal#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#type EventOrchestrationGlobal#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#value EventOrchestrationGlobal#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationGlobalCatchAllActionsVariableToTerraform(struct?: EventOrchestrationGlobalCatchAllActionsVariable | cdktn.IResolvable): any;
export declare function eventOrchestrationGlobalCatchAllActionsVariableToHclTerraform(struct?: EventOrchestrationGlobalCatchAllActionsVariable | cdktn.IResolvable): any;
export declare class EventOrchestrationGlobalCatchAllActionsVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalCatchAllActionsVariable | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalCatchAllActionsVariable | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationGlobalCatchAllActionsVariableList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalCatchAllActionsVariable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalCatchAllActionsVariableOutputReference;
}
export interface EventOrchestrationGlobalCatchAllActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#annotate EventOrchestrationGlobal#annotate}
    */
    readonly annotate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#drop_event EventOrchestrationGlobal#drop_event}
    */
    readonly dropEvent?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#escalation_policy EventOrchestrationGlobal#escalation_policy}
    */
    readonly escalationPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#event_action EventOrchestrationGlobal#event_action}
    */
    readonly eventAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#priority EventOrchestrationGlobal#priority}
    */
    readonly priority?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#route_to EventOrchestrationGlobal#route_to}
    */
    readonly routeTo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#severity EventOrchestrationGlobal#severity}
    */
    readonly severity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#suppress EventOrchestrationGlobal#suppress}
    */
    readonly suppress?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#suspend EventOrchestrationGlobal#suspend}
    */
    readonly suspend?: number;
    /**
    * automation_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#automation_action EventOrchestrationGlobal#automation_action}
    */
    readonly automationAction?: EventOrchestrationGlobalCatchAllActionsAutomationAction;
    /**
    * extraction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#extraction EventOrchestrationGlobal#extraction}
    */
    readonly extraction?: EventOrchestrationGlobalCatchAllActionsExtraction[] | cdktn.IResolvable;
    /**
    * incident_custom_field_update block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#incident_custom_field_update EventOrchestrationGlobal#incident_custom_field_update}
    */
    readonly incidentCustomFieldUpdate?: EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdate[] | cdktn.IResolvable;
    /**
    * variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#variable EventOrchestrationGlobal#variable}
    */
    readonly variable?: EventOrchestrationGlobalCatchAllActionsVariable[] | cdktn.IResolvable;
}
export declare function eventOrchestrationGlobalCatchAllActionsToTerraform(struct?: EventOrchestrationGlobalCatchAllActionsOutputReference | EventOrchestrationGlobalCatchAllActions): any;
export declare function eventOrchestrationGlobalCatchAllActionsToHclTerraform(struct?: EventOrchestrationGlobalCatchAllActionsOutputReference | EventOrchestrationGlobalCatchAllActions): any;
export declare class EventOrchestrationGlobalCatchAllActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationGlobalCatchAllActions | undefined;
    set internalValue(value: EventOrchestrationGlobalCatchAllActions | undefined);
    private _annotate?;
    get annotate(): string;
    set annotate(value: string);
    resetAnnotate(): void;
    get annotateInput(): string | undefined;
    private _dropEvent?;
    get dropEvent(): boolean | cdktn.IResolvable;
    set dropEvent(value: boolean | cdktn.IResolvable);
    resetDropEvent(): void;
    get dropEventInput(): boolean | cdktn.IResolvable | undefined;
    private _escalationPolicy?;
    get escalationPolicy(): string;
    set escalationPolicy(value: string);
    resetEscalationPolicy(): void;
    get escalationPolicyInput(): string | undefined;
    private _eventAction?;
    get eventAction(): string;
    set eventAction(value: string);
    resetEventAction(): void;
    get eventActionInput(): string | undefined;
    private _priority?;
    get priority(): string;
    set priority(value: string);
    resetPriority(): void;
    get priorityInput(): string | undefined;
    private _routeTo?;
    get routeTo(): string;
    set routeTo(value: string);
    resetRouteTo(): void;
    get routeToInput(): string | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    resetSeverity(): void;
    get severityInput(): string | undefined;
    private _suppress?;
    get suppress(): boolean | cdktn.IResolvable;
    set suppress(value: boolean | cdktn.IResolvable);
    resetSuppress(): void;
    get suppressInput(): boolean | cdktn.IResolvable | undefined;
    private _suspend?;
    get suspend(): number;
    set suspend(value: number);
    resetSuspend(): void;
    get suspendInput(): number | undefined;
    private _automationAction;
    get automationAction(): EventOrchestrationGlobalCatchAllActionsAutomationActionOutputReference;
    putAutomationAction(value: EventOrchestrationGlobalCatchAllActionsAutomationAction): void;
    resetAutomationAction(): void;
    get automationActionInput(): EventOrchestrationGlobalCatchAllActionsAutomationAction | undefined;
    private _extraction;
    get extraction(): EventOrchestrationGlobalCatchAllActionsExtractionList;
    putExtraction(value: EventOrchestrationGlobalCatchAllActionsExtraction[] | cdktn.IResolvable): void;
    resetExtraction(): void;
    get extractionInput(): cdktn.IResolvable | EventOrchestrationGlobalCatchAllActionsExtraction[] | undefined;
    private _incidentCustomFieldUpdate;
    get incidentCustomFieldUpdate(): EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdateList;
    putIncidentCustomFieldUpdate(value: EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdate[] | cdktn.IResolvable): void;
    resetIncidentCustomFieldUpdate(): void;
    get incidentCustomFieldUpdateInput(): cdktn.IResolvable | EventOrchestrationGlobalCatchAllActionsIncidentCustomFieldUpdate[] | undefined;
    private _variable;
    get variable(): EventOrchestrationGlobalCatchAllActionsVariableList;
    putVariable(value: EventOrchestrationGlobalCatchAllActionsVariable[] | cdktn.IResolvable): void;
    resetVariable(): void;
    get variableInput(): cdktn.IResolvable | EventOrchestrationGlobalCatchAllActionsVariable[] | undefined;
}
export interface EventOrchestrationGlobalCatchAll {
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#actions EventOrchestrationGlobal#actions}
    */
    readonly actions: EventOrchestrationGlobalCatchAllActions;
}
export declare function eventOrchestrationGlobalCatchAllToTerraform(struct?: EventOrchestrationGlobalCatchAllOutputReference | EventOrchestrationGlobalCatchAll): any;
export declare function eventOrchestrationGlobalCatchAllToHclTerraform(struct?: EventOrchestrationGlobalCatchAllOutputReference | EventOrchestrationGlobalCatchAll): any;
export declare class EventOrchestrationGlobalCatchAllOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationGlobalCatchAll | undefined;
    set internalValue(value: EventOrchestrationGlobalCatchAll | undefined);
    private _actions;
    get actions(): EventOrchestrationGlobalCatchAllActionsOutputReference;
    putActions(value: EventOrchestrationGlobalCatchAllActions): void;
    get actionsInput(): EventOrchestrationGlobalCatchAllActions | undefined;
}
export interface EventOrchestrationGlobalSetRuleActionsAutomationActionHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#key EventOrchestrationGlobal#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#value EventOrchestrationGlobal#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationGlobalSetRuleActionsAutomationActionHeaderToTerraform(struct?: EventOrchestrationGlobalSetRuleActionsAutomationActionHeader | cdktn.IResolvable): any;
export declare function eventOrchestrationGlobalSetRuleActionsAutomationActionHeaderToHclTerraform(struct?: EventOrchestrationGlobalSetRuleActionsAutomationActionHeader | cdktn.IResolvable): any;
export declare class EventOrchestrationGlobalSetRuleActionsAutomationActionHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalSetRuleActionsAutomationActionHeader | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalSetRuleActionsAutomationActionHeader | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationGlobalSetRuleActionsAutomationActionHeaderList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalSetRuleActionsAutomationActionHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalSetRuleActionsAutomationActionHeaderOutputReference;
}
export interface EventOrchestrationGlobalSetRuleActionsAutomationActionParameter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#key EventOrchestrationGlobal#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#value EventOrchestrationGlobal#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationGlobalSetRuleActionsAutomationActionParameterToTerraform(struct?: EventOrchestrationGlobalSetRuleActionsAutomationActionParameter | cdktn.IResolvable): any;
export declare function eventOrchestrationGlobalSetRuleActionsAutomationActionParameterToHclTerraform(struct?: EventOrchestrationGlobalSetRuleActionsAutomationActionParameter | cdktn.IResolvable): any;
export declare class EventOrchestrationGlobalSetRuleActionsAutomationActionParameterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalSetRuleActionsAutomationActionParameter | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalSetRuleActionsAutomationActionParameter | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationGlobalSetRuleActionsAutomationActionParameterList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalSetRuleActionsAutomationActionParameter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalSetRuleActionsAutomationActionParameterOutputReference;
}
export interface EventOrchestrationGlobalSetRuleActionsAutomationAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#auto_send EventOrchestrationGlobal#auto_send}
    */
    readonly autoSend?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#name EventOrchestrationGlobal#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#trigger_types EventOrchestrationGlobal#trigger_types}
    */
    readonly triggerTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#url EventOrchestrationGlobal#url}
    */
    readonly url: string;
    /**
    * header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#header EventOrchestrationGlobal#header}
    */
    readonly header?: EventOrchestrationGlobalSetRuleActionsAutomationActionHeader[] | cdktn.IResolvable;
    /**
    * parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#parameter EventOrchestrationGlobal#parameter}
    */
    readonly parameter?: EventOrchestrationGlobalSetRuleActionsAutomationActionParameter[] | cdktn.IResolvable;
}
export declare function eventOrchestrationGlobalSetRuleActionsAutomationActionToTerraform(struct?: EventOrchestrationGlobalSetRuleActionsAutomationActionOutputReference | EventOrchestrationGlobalSetRuleActionsAutomationAction): any;
export declare function eventOrchestrationGlobalSetRuleActionsAutomationActionToHclTerraform(struct?: EventOrchestrationGlobalSetRuleActionsAutomationActionOutputReference | EventOrchestrationGlobalSetRuleActionsAutomationAction): any;
export declare class EventOrchestrationGlobalSetRuleActionsAutomationActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationGlobalSetRuleActionsAutomationAction | undefined;
    set internalValue(value: EventOrchestrationGlobalSetRuleActionsAutomationAction | undefined);
    private _autoSend?;
    get autoSend(): boolean | cdktn.IResolvable;
    set autoSend(value: boolean | cdktn.IResolvable);
    resetAutoSend(): void;
    get autoSendInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _triggerTypes?;
    get triggerTypes(): string[];
    set triggerTypes(value: string[]);
    resetTriggerTypes(): void;
    get triggerTypesInput(): string[] | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _header;
    get header(): EventOrchestrationGlobalSetRuleActionsAutomationActionHeaderList;
    putHeader(value: EventOrchestrationGlobalSetRuleActionsAutomationActionHeader[] | cdktn.IResolvable): void;
    resetHeader(): void;
    get headerInput(): cdktn.IResolvable | EventOrchestrationGlobalSetRuleActionsAutomationActionHeader[] | undefined;
    private _parameter;
    get parameter(): EventOrchestrationGlobalSetRuleActionsAutomationActionParameterList;
    putParameter(value: EventOrchestrationGlobalSetRuleActionsAutomationActionParameter[] | cdktn.IResolvable): void;
    resetParameter(): void;
    get parameterInput(): cdktn.IResolvable | EventOrchestrationGlobalSetRuleActionsAutomationActionParameter[] | undefined;
}
export interface EventOrchestrationGlobalSetRuleActionsExtraction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#regex EventOrchestrationGlobal#regex}
    */
    readonly regex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#source EventOrchestrationGlobal#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#target EventOrchestrationGlobal#target}
    */
    readonly target: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#template EventOrchestrationGlobal#template}
    */
    readonly template?: string;
}
export declare function eventOrchestrationGlobalSetRuleActionsExtractionToTerraform(struct?: EventOrchestrationGlobalSetRuleActionsExtraction | cdktn.IResolvable): any;
export declare function eventOrchestrationGlobalSetRuleActionsExtractionToHclTerraform(struct?: EventOrchestrationGlobalSetRuleActionsExtraction | cdktn.IResolvable): any;
export declare class EventOrchestrationGlobalSetRuleActionsExtractionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalSetRuleActionsExtraction | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalSetRuleActionsExtraction | cdktn.IResolvable | undefined);
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    resetTemplate(): void;
    get templateInput(): string | undefined;
}
export declare class EventOrchestrationGlobalSetRuleActionsExtractionList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalSetRuleActionsExtraction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalSetRuleActionsExtractionOutputReference;
}
export interface EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#id EventOrchestrationGlobal#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#value EventOrchestrationGlobal#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdateToTerraform(struct?: EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdate | cdktn.IResolvable): any;
export declare function eventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdateToHclTerraform(struct?: EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdate | cdktn.IResolvable): any;
export declare class EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdate | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdate | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdateList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdateOutputReference;
}
export interface EventOrchestrationGlobalSetRuleActionsVariable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#name EventOrchestrationGlobal#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#path EventOrchestrationGlobal#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#type EventOrchestrationGlobal#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#value EventOrchestrationGlobal#value}
    */
    readonly value: string;
}
export declare function eventOrchestrationGlobalSetRuleActionsVariableToTerraform(struct?: EventOrchestrationGlobalSetRuleActionsVariable | cdktn.IResolvable): any;
export declare function eventOrchestrationGlobalSetRuleActionsVariableToHclTerraform(struct?: EventOrchestrationGlobalSetRuleActionsVariable | cdktn.IResolvable): any;
export declare class EventOrchestrationGlobalSetRuleActionsVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalSetRuleActionsVariable | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalSetRuleActionsVariable | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class EventOrchestrationGlobalSetRuleActionsVariableList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalSetRuleActionsVariable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalSetRuleActionsVariableOutputReference;
}
export interface EventOrchestrationGlobalSetRuleActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#annotate EventOrchestrationGlobal#annotate}
    */
    readonly annotate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#drop_event EventOrchestrationGlobal#drop_event}
    */
    readonly dropEvent?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#escalation_policy EventOrchestrationGlobal#escalation_policy}
    */
    readonly escalationPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#event_action EventOrchestrationGlobal#event_action}
    */
    readonly eventAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#priority EventOrchestrationGlobal#priority}
    */
    readonly priority?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#route_to EventOrchestrationGlobal#route_to}
    */
    readonly routeTo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#severity EventOrchestrationGlobal#severity}
    */
    readonly severity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#suppress EventOrchestrationGlobal#suppress}
    */
    readonly suppress?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#suspend EventOrchestrationGlobal#suspend}
    */
    readonly suspend?: number;
    /**
    * automation_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#automation_action EventOrchestrationGlobal#automation_action}
    */
    readonly automationAction?: EventOrchestrationGlobalSetRuleActionsAutomationAction;
    /**
    * extraction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#extraction EventOrchestrationGlobal#extraction}
    */
    readonly extraction?: EventOrchestrationGlobalSetRuleActionsExtraction[] | cdktn.IResolvable;
    /**
    * incident_custom_field_update block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#incident_custom_field_update EventOrchestrationGlobal#incident_custom_field_update}
    */
    readonly incidentCustomFieldUpdate?: EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdate[] | cdktn.IResolvable;
    /**
    * variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#variable EventOrchestrationGlobal#variable}
    */
    readonly variable?: EventOrchestrationGlobalSetRuleActionsVariable[] | cdktn.IResolvable;
}
export declare function eventOrchestrationGlobalSetRuleActionsToTerraform(struct?: EventOrchestrationGlobalSetRuleActionsOutputReference | EventOrchestrationGlobalSetRuleActions): any;
export declare function eventOrchestrationGlobalSetRuleActionsToHclTerraform(struct?: EventOrchestrationGlobalSetRuleActionsOutputReference | EventOrchestrationGlobalSetRuleActions): any;
export declare class EventOrchestrationGlobalSetRuleActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationGlobalSetRuleActions | undefined;
    set internalValue(value: EventOrchestrationGlobalSetRuleActions | undefined);
    private _annotate?;
    get annotate(): string;
    set annotate(value: string);
    resetAnnotate(): void;
    get annotateInput(): string | undefined;
    private _dropEvent?;
    get dropEvent(): boolean | cdktn.IResolvable;
    set dropEvent(value: boolean | cdktn.IResolvable);
    resetDropEvent(): void;
    get dropEventInput(): boolean | cdktn.IResolvable | undefined;
    private _escalationPolicy?;
    get escalationPolicy(): string;
    set escalationPolicy(value: string);
    resetEscalationPolicy(): void;
    get escalationPolicyInput(): string | undefined;
    private _eventAction?;
    get eventAction(): string;
    set eventAction(value: string);
    resetEventAction(): void;
    get eventActionInput(): string | undefined;
    private _priority?;
    get priority(): string;
    set priority(value: string);
    resetPriority(): void;
    get priorityInput(): string | undefined;
    private _routeTo?;
    get routeTo(): string;
    set routeTo(value: string);
    resetRouteTo(): void;
    get routeToInput(): string | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    resetSeverity(): void;
    get severityInput(): string | undefined;
    private _suppress?;
    get suppress(): boolean | cdktn.IResolvable;
    set suppress(value: boolean | cdktn.IResolvable);
    resetSuppress(): void;
    get suppressInput(): boolean | cdktn.IResolvable | undefined;
    private _suspend?;
    get suspend(): number;
    set suspend(value: number);
    resetSuspend(): void;
    get suspendInput(): number | undefined;
    private _automationAction;
    get automationAction(): EventOrchestrationGlobalSetRuleActionsAutomationActionOutputReference;
    putAutomationAction(value: EventOrchestrationGlobalSetRuleActionsAutomationAction): void;
    resetAutomationAction(): void;
    get automationActionInput(): EventOrchestrationGlobalSetRuleActionsAutomationAction | undefined;
    private _extraction;
    get extraction(): EventOrchestrationGlobalSetRuleActionsExtractionList;
    putExtraction(value: EventOrchestrationGlobalSetRuleActionsExtraction[] | cdktn.IResolvable): void;
    resetExtraction(): void;
    get extractionInput(): cdktn.IResolvable | EventOrchestrationGlobalSetRuleActionsExtraction[] | undefined;
    private _incidentCustomFieldUpdate;
    get incidentCustomFieldUpdate(): EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdateList;
    putIncidentCustomFieldUpdate(value: EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdate[] | cdktn.IResolvable): void;
    resetIncidentCustomFieldUpdate(): void;
    get incidentCustomFieldUpdateInput(): cdktn.IResolvable | EventOrchestrationGlobalSetRuleActionsIncidentCustomFieldUpdate[] | undefined;
    private _variable;
    get variable(): EventOrchestrationGlobalSetRuleActionsVariableList;
    putVariable(value: EventOrchestrationGlobalSetRuleActionsVariable[] | cdktn.IResolvable): void;
    resetVariable(): void;
    get variableInput(): cdktn.IResolvable | EventOrchestrationGlobalSetRuleActionsVariable[] | undefined;
}
export interface EventOrchestrationGlobalSetRuleCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#expression EventOrchestrationGlobal#expression}
    */
    readonly expression: string;
}
export declare function eventOrchestrationGlobalSetRuleConditionToTerraform(struct?: EventOrchestrationGlobalSetRuleCondition | cdktn.IResolvable): any;
export declare function eventOrchestrationGlobalSetRuleConditionToHclTerraform(struct?: EventOrchestrationGlobalSetRuleCondition | cdktn.IResolvable): any;
export declare class EventOrchestrationGlobalSetRuleConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalSetRuleCondition | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalSetRuleCondition | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export declare class EventOrchestrationGlobalSetRuleConditionList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalSetRuleCondition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalSetRuleConditionOutputReference;
}
export interface EventOrchestrationGlobalSetRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#disabled EventOrchestrationGlobal#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#label EventOrchestrationGlobal#label}
    */
    readonly label?: string;
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#actions EventOrchestrationGlobal#actions}
    */
    readonly actions: EventOrchestrationGlobalSetRuleActions;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#condition EventOrchestrationGlobal#condition}
    */
    readonly condition?: EventOrchestrationGlobalSetRuleCondition[] | cdktn.IResolvable;
}
export declare function eventOrchestrationGlobalSetRuleToTerraform(struct?: EventOrchestrationGlobalSetRule | cdktn.IResolvable): any;
export declare function eventOrchestrationGlobalSetRuleToHclTerraform(struct?: EventOrchestrationGlobalSetRule | cdktn.IResolvable): any;
export declare class EventOrchestrationGlobalSetRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalSetRule | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalSetRule | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _actions;
    get actions(): EventOrchestrationGlobalSetRuleActionsOutputReference;
    putActions(value: EventOrchestrationGlobalSetRuleActions): void;
    get actionsInput(): EventOrchestrationGlobalSetRuleActions | undefined;
    private _condition;
    get condition(): EventOrchestrationGlobalSetRuleConditionList;
    putCondition(value: EventOrchestrationGlobalSetRuleCondition[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | EventOrchestrationGlobalSetRuleCondition[] | undefined;
}
export declare class EventOrchestrationGlobalSetRuleList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalSetRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalSetRuleOutputReference;
}
export interface EventOrchestrationGlobalSet {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#id EventOrchestrationGlobal#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#rule EventOrchestrationGlobal#rule}
    */
    readonly rule?: EventOrchestrationGlobalSetRule[] | cdktn.IResolvable;
}
export declare function eventOrchestrationGlobalSetToTerraform(struct?: EventOrchestrationGlobalSet | cdktn.IResolvable): any;
export declare function eventOrchestrationGlobalSetToHclTerraform(struct?: EventOrchestrationGlobalSet | cdktn.IResolvable): any;
export declare class EventOrchestrationGlobalSetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationGlobalSet | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationGlobalSet | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _rule;
    get rule(): EventOrchestrationGlobalSetRuleList;
    putRule(value: EventOrchestrationGlobalSetRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | EventOrchestrationGlobalSetRule[] | undefined;
}
export declare class EventOrchestrationGlobalSetList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationGlobalSet[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationGlobalSetOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global pagerduty_event_orchestration_global}
*/
export declare class EventOrchestrationGlobal extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_event_orchestration_global";
    /**
    * Generates CDKTN code for importing a EventOrchestrationGlobal resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EventOrchestrationGlobal to import
    * @param importFromId The id of the existing EventOrchestrationGlobal that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EventOrchestrationGlobal to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_global pagerduty_event_orchestration_global} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EventOrchestrationGlobalConfig
    */
    constructor(scope: Construct, id: string, config: EventOrchestrationGlobalConfig);
    private _eventOrchestration?;
    get eventOrchestration(): string;
    set eventOrchestration(value: string);
    get eventOrchestrationInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _catchAll;
    get catchAll(): EventOrchestrationGlobalCatchAllOutputReference;
    putCatchAll(value: EventOrchestrationGlobalCatchAll): void;
    get catchAllInput(): EventOrchestrationGlobalCatchAll | undefined;
    private _set;
    get set(): EventOrchestrationGlobalSetList;
    putSet(value: EventOrchestrationGlobalSet[] | cdktn.IResolvable): void;
    get setInput(): cdktn.IResolvable | EventOrchestrationGlobalSet[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
