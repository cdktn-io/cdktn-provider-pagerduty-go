/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EventOrchestrationServiceCacheVariableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_service_cache_variable#disabled EventOrchestrationServiceCacheVariable#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_service_cache_variable#name EventOrchestrationServiceCacheVariable#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_service_cache_variable#service EventOrchestrationServiceCacheVariable#service}
    */
    readonly service: string;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_service_cache_variable#condition EventOrchestrationServiceCacheVariable#condition}
    */
    readonly condition?: EventOrchestrationServiceCacheVariableCondition[] | cdktn.IResolvable;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_service_cache_variable#configuration EventOrchestrationServiceCacheVariable#configuration}
    */
    readonly configuration: EventOrchestrationServiceCacheVariableConfiguration;
}
export interface EventOrchestrationServiceCacheVariableCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_service_cache_variable#expression EventOrchestrationServiceCacheVariable#expression}
    */
    readonly expression: string;
}
export declare function eventOrchestrationServiceCacheVariableConditionToTerraform(struct?: EventOrchestrationServiceCacheVariableCondition | cdktn.IResolvable): any;
export declare function eventOrchestrationServiceCacheVariableConditionToHclTerraform(struct?: EventOrchestrationServiceCacheVariableCondition | cdktn.IResolvable): any;
export declare class EventOrchestrationServiceCacheVariableConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationServiceCacheVariableCondition | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationServiceCacheVariableCondition | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export declare class EventOrchestrationServiceCacheVariableConditionList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EventOrchestrationServiceCacheVariableCondition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationServiceCacheVariableConditionOutputReference;
}
export interface EventOrchestrationServiceCacheVariableConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_service_cache_variable#data_type EventOrchestrationServiceCacheVariable#data_type}
    */
    readonly dataType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_service_cache_variable#regex EventOrchestrationServiceCacheVariable#regex}
    */
    readonly regex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_service_cache_variable#source EventOrchestrationServiceCacheVariable#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_service_cache_variable#ttl_seconds EventOrchestrationServiceCacheVariable#ttl_seconds}
    */
    readonly ttlSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_service_cache_variable#type EventOrchestrationServiceCacheVariable#type}
    */
    readonly type: string;
}
export declare function eventOrchestrationServiceCacheVariableConfigurationToTerraform(struct?: EventOrchestrationServiceCacheVariableConfigurationOutputReference | EventOrchestrationServiceCacheVariableConfiguration): any;
export declare function eventOrchestrationServiceCacheVariableConfigurationToHclTerraform(struct?: EventOrchestrationServiceCacheVariableConfigurationOutputReference | EventOrchestrationServiceCacheVariableConfiguration): any;
export declare class EventOrchestrationServiceCacheVariableConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationServiceCacheVariableConfiguration | undefined;
    set internalValue(value: EventOrchestrationServiceCacheVariableConfiguration | undefined);
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    resetDataType(): void;
    get dataTypeInput(): string | undefined;
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _ttlSeconds?;
    get ttlSeconds(): number;
    set ttlSeconds(value: number);
    resetTtlSeconds(): void;
    get ttlSecondsInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_service_cache_variable pagerduty_event_orchestration_service_cache_variable}
*/
export declare class EventOrchestrationServiceCacheVariable extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_event_orchestration_service_cache_variable";
    /**
    * Generates CDKTN code for importing a EventOrchestrationServiceCacheVariable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EventOrchestrationServiceCacheVariable to import
    * @param importFromId The id of the existing EventOrchestrationServiceCacheVariable that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_service_cache_variable#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EventOrchestrationServiceCacheVariable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/event_orchestration_service_cache_variable pagerduty_event_orchestration_service_cache_variable} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EventOrchestrationServiceCacheVariableConfig
    */
    constructor(scope: Construct, id: string, config: EventOrchestrationServiceCacheVariableConfig);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _condition;
    get condition(): EventOrchestrationServiceCacheVariableConditionList;
    putCondition(value: EventOrchestrationServiceCacheVariableCondition[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | EventOrchestrationServiceCacheVariableCondition[] | undefined;
    private _configuration;
    get configuration(): EventOrchestrationServiceCacheVariableConfigurationOutputReference;
    putConfiguration(value: EventOrchestrationServiceCacheVariableConfiguration): void;
    get configurationInput(): EventOrchestrationServiceCacheVariableConfiguration | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
