/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPagerdutyEventOrchestrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/data-sources/event_orchestration#id DataPagerdutyEventOrchestration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/data-sources/event_orchestration#name DataPagerdutyEventOrchestration#name}
    */
    readonly name: string;
    /**
    * integration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/data-sources/event_orchestration#integration DataPagerdutyEventOrchestration#integration}
    */
    readonly integration?: DataPagerdutyEventOrchestrationIntegration[] | cdktn.IResolvable;
}
export interface DataPagerdutyEventOrchestrationIntegrationParameters {
}
export declare function dataPagerdutyEventOrchestrationIntegrationParametersToTerraform(struct?: DataPagerdutyEventOrchestrationIntegrationParameters): any;
export declare function dataPagerdutyEventOrchestrationIntegrationParametersToHclTerraform(struct?: DataPagerdutyEventOrchestrationIntegrationParameters): any;
export declare class DataPagerdutyEventOrchestrationIntegrationParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyEventOrchestrationIntegrationParameters | undefined;
    set internalValue(value: DataPagerdutyEventOrchestrationIntegrationParameters | undefined);
    get routingKey(): string;
    get type(): string;
}
export declare class DataPagerdutyEventOrchestrationIntegrationParametersList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyEventOrchestrationIntegrationParametersOutputReference;
}
export interface DataPagerdutyEventOrchestrationIntegration {
}
export declare function dataPagerdutyEventOrchestrationIntegrationToTerraform(struct?: DataPagerdutyEventOrchestrationIntegration | cdktn.IResolvable): any;
export declare function dataPagerdutyEventOrchestrationIntegrationToHclTerraform(struct?: DataPagerdutyEventOrchestrationIntegration | cdktn.IResolvable): any;
export declare class DataPagerdutyEventOrchestrationIntegrationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyEventOrchestrationIntegration | cdktn.IResolvable | undefined;
    set internalValue(value: DataPagerdutyEventOrchestrationIntegration | cdktn.IResolvable | undefined);
    get id(): string;
    get label(): string;
    private _parameters;
    get parameters(): DataPagerdutyEventOrchestrationIntegrationParametersList;
}
export declare class DataPagerdutyEventOrchestrationIntegrationList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataPagerdutyEventOrchestrationIntegration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyEventOrchestrationIntegrationOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/data-sources/event_orchestration pagerduty_event_orchestration}
*/
export declare class DataPagerdutyEventOrchestration extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_event_orchestration";
    /**
    * Generates CDKTN code for importing a DataPagerdutyEventOrchestration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyEventOrchestration to import
    * @param importFromId The id of the existing DataPagerdutyEventOrchestration that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/data-sources/event_orchestration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyEventOrchestration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/data-sources/event_orchestration pagerduty_event_orchestration} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyEventOrchestrationConfig
    */
    constructor(scope: Construct, id: string, config: DataPagerdutyEventOrchestrationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _integration;
    get integration(): DataPagerdutyEventOrchestrationIntegrationList;
    putIntegration(value: DataPagerdutyEventOrchestrationIntegration[] | cdktn.IResolvable): void;
    resetIntegration(): void;
    get integrationInput(): cdktn.IResolvable | DataPagerdutyEventOrchestrationIntegration[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
