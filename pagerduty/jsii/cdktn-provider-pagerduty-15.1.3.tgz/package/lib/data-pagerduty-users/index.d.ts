/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPagerdutyUsersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/data-sources/users#team_ids DataPagerdutyUsers#team_ids}
    */
    readonly teamIds?: string[];
}
export interface DataPagerdutyUsersUsers {
}
export declare function dataPagerdutyUsersUsersToTerraform(struct?: DataPagerdutyUsersUsers): any;
export declare function dataPagerdutyUsersUsersToHclTerraform(struct?: DataPagerdutyUsersUsers): any;
export declare class DataPagerdutyUsersUsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyUsersUsers | undefined;
    set internalValue(value: DataPagerdutyUsersUsers | undefined);
    get description(): string;
    get email(): string;
    get id(): string;
    get jobTitle(): string;
    get name(): string;
    get role(): string;
    get timeZone(): string;
    get type(): string;
}
export declare class DataPagerdutyUsersUsersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyUsersUsersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/data-sources/users pagerduty_users}
*/
export declare class DataPagerdutyUsers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_users";
    /**
    * Generates CDKTN code for importing a DataPagerdutyUsers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyUsers to import
    * @param importFromId The id of the existing DataPagerdutyUsers that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/data-sources/users#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyUsers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/data-sources/users pagerduty_users} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyUsersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataPagerdutyUsersConfig);
    get id(): string;
    private _teamIds?;
    get teamIds(): string[];
    set teamIds(value: string[]);
    resetTeamIds(): void;
    get teamIdsInput(): string[] | undefined;
    private _users;
    get users(): DataPagerdutyUsersUsersList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
