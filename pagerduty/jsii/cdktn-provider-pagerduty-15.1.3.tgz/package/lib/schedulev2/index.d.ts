/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface Schedulev2Config extends cdktn.TerraformMetaArguments {
    /**
    * A description of the schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#description Schedulev2#description}
    */
    readonly description?: string;
    /**
    * The name of the schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#name Schedulev2#name}
    */
    readonly name: string;
    /**
    * List of team IDs to associate with this schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#teams Schedulev2#teams}
    */
    readonly teams?: string[];
    /**
    * The time zone of the schedule (IANA format, e.g. 'America/New_York').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#time_zone Schedulev2#time_zone}
    */
    readonly timeZone: string;
    /**
    * rotation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#rotation Schedulev2#rotation}
    */
    readonly rotation?: Schedulev2Rotation[] | cdktn.IResolvable;
}
export interface Schedulev2RotationEventAssignmentStrategyMember {
    /**
    * The member type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#type Schedulev2#type}
    */
    readonly type: string;
    /**
    * The obfuscated user ID. Required when type is 'user_member'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#user_id Schedulev2#user_id}
    */
    readonly userId?: string;
}
export declare function schedulev2RotationEventAssignmentStrategyMemberToTerraform(struct?: Schedulev2RotationEventAssignmentStrategyMember | cdktn.IResolvable): any;
export declare function schedulev2RotationEventAssignmentStrategyMemberToHclTerraform(struct?: Schedulev2RotationEventAssignmentStrategyMember | cdktn.IResolvable): any;
export declare class Schedulev2RotationEventAssignmentStrategyMemberOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Schedulev2RotationEventAssignmentStrategyMember | cdktn.IResolvable | undefined;
    set internalValue(value: Schedulev2RotationEventAssignmentStrategyMember | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
}
export declare class Schedulev2RotationEventAssignmentStrategyMemberList extends cdktn.ComplexList {
    internalValue?: Schedulev2RotationEventAssignmentStrategyMember[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Schedulev2RotationEventAssignmentStrategyMemberOutputReference;
}
export interface Schedulev2RotationEventAssignmentStrategy {
    /**
    * Number of shifts per member per recurrence cycle. Defaults to 1 for 'rotating_member_assignment_strategy' when not set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#shifts_per_member Schedulev2#shifts_per_member}
    */
    readonly shiftsPerMember?: number;
    /**
    * The assignment strategy type. Use 'rotating_member_assignment_strategy' for user-based rotation, or 'every_member_assignment_strategy' for all-hands coverage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#type Schedulev2#type}
    */
    readonly type: string;
    /**
    * member block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#member Schedulev2#member}
    */
    readonly member?: Schedulev2RotationEventAssignmentStrategyMember[] | cdktn.IResolvable;
}
export declare function schedulev2RotationEventAssignmentStrategyToTerraform(struct?: Schedulev2RotationEventAssignmentStrategy | cdktn.IResolvable): any;
export declare function schedulev2RotationEventAssignmentStrategyToHclTerraform(struct?: Schedulev2RotationEventAssignmentStrategy | cdktn.IResolvable): any;
export declare class Schedulev2RotationEventAssignmentStrategyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Schedulev2RotationEventAssignmentStrategy | cdktn.IResolvable | undefined;
    set internalValue(value: Schedulev2RotationEventAssignmentStrategy | cdktn.IResolvable | undefined);
    private _shiftsPerMember?;
    get shiftsPerMember(): number;
    set shiftsPerMember(value: number);
    resetShiftsPerMember(): void;
    get shiftsPerMemberInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _member;
    get member(): Schedulev2RotationEventAssignmentStrategyMemberList;
    putMember(value: Schedulev2RotationEventAssignmentStrategyMember[] | cdktn.IResolvable): void;
    resetMember(): void;
    get memberInput(): cdktn.IResolvable | Schedulev2RotationEventAssignmentStrategyMember[] | undefined;
}
export declare class Schedulev2RotationEventAssignmentStrategyList extends cdktn.ComplexList {
    internalValue?: Schedulev2RotationEventAssignmentStrategy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Schedulev2RotationEventAssignmentStrategyOutputReference;
}
export interface Schedulev2RotationEvent {
    /**
    * When this event configuration starts producing shifts (ISO-8601 UTC). Must be a future time; the API will adjust past times to the current time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#effective_since Schedulev2#effective_since}
    */
    readonly effectiveSince: string;
    /**
    * When this event configuration stops producing shifts (ISO-8601 UTC). Null or omitted means indefinite.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#effective_until Schedulev2#effective_until}
    */
    readonly effectiveUntil?: string;
    /**
    * The shift end time with timezone offset (ISO-8601 format, e.g. '2024-01-01T17:00:00-05:00').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#end_time Schedulev2#end_time}
    */
    readonly endTime: string;
    /**
    * The name of the event.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#name Schedulev2#name}
    */
    readonly name: string;
    /**
    * List of RRULE strings defining the recurrence pattern (RFC 5545, e.g. 'RRULE:FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#recurrence Schedulev2#recurrence}
    */
    readonly recurrence: string[];
    /**
    * The shift start time with timezone offset (ISO-8601 format, e.g. '2024-01-01T09:00:00-05:00').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#start_time Schedulev2#start_time}
    */
    readonly startTime: string;
    /**
    * assignment_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#assignment_strategy Schedulev2#assignment_strategy}
    */
    readonly assignmentStrategy?: Schedulev2RotationEventAssignmentStrategy[] | cdktn.IResolvable;
}
export declare function schedulev2RotationEventToTerraform(struct?: Schedulev2RotationEvent | cdktn.IResolvable): any;
export declare function schedulev2RotationEventToHclTerraform(struct?: Schedulev2RotationEvent | cdktn.IResolvable): any;
export declare class Schedulev2RotationEventOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Schedulev2RotationEvent | cdktn.IResolvable | undefined;
    set internalValue(value: Schedulev2RotationEvent | cdktn.IResolvable | undefined);
    private _effectiveSince?;
    get effectiveSince(): string;
    set effectiveSince(value: string);
    get effectiveSinceInput(): string | undefined;
    private _effectiveUntil?;
    get effectiveUntil(): string;
    set effectiveUntil(value: string);
    resetEffectiveUntil(): void;
    get effectiveUntilInput(): string | undefined;
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    get endTimeInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _recurrence?;
    get recurrence(): string[];
    set recurrence(value: string[]);
    get recurrenceInput(): string[] | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
    private _assignmentStrategy;
    get assignmentStrategy(): Schedulev2RotationEventAssignmentStrategyList;
    putAssignmentStrategy(value: Schedulev2RotationEventAssignmentStrategy[] | cdktn.IResolvable): void;
    resetAssignmentStrategy(): void;
    get assignmentStrategyInput(): cdktn.IResolvable | Schedulev2RotationEventAssignmentStrategy[] | undefined;
}
export declare class Schedulev2RotationEventList extends cdktn.ComplexList {
    internalValue?: Schedulev2RotationEvent[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Schedulev2RotationEventOutputReference;
}
export interface Schedulev2Rotation {
    /**
    * event block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#event Schedulev2#event}
    */
    readonly event?: Schedulev2RotationEvent[] | cdktn.IResolvable;
}
export declare function schedulev2RotationToTerraform(struct?: Schedulev2Rotation | cdktn.IResolvable): any;
export declare function schedulev2RotationToHclTerraform(struct?: Schedulev2Rotation | cdktn.IResolvable): any;
export declare class Schedulev2RotationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Schedulev2Rotation | cdktn.IResolvable | undefined;
    set internalValue(value: Schedulev2Rotation | cdktn.IResolvable | undefined);
    get id(): string;
    private _event;
    get event(): Schedulev2RotationEventList;
    putEvent(value: Schedulev2RotationEvent[] | cdktn.IResolvable): void;
    resetEvent(): void;
    get eventInput(): cdktn.IResolvable | Schedulev2RotationEvent[] | undefined;
}
export declare class Schedulev2RotationList extends cdktn.ComplexList {
    internalValue?: Schedulev2Rotation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Schedulev2RotationOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2 pagerduty_schedulev2}
*/
export declare class Schedulev2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_schedulev2";
    /**
    * Generates CDKTN code for importing a Schedulev2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Schedulev2 to import
    * @param importFromId The id of the existing Schedulev2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Schedulev2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/schedulev2 pagerduty_schedulev2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options Schedulev2Config
    */
    constructor(scope: Construct, id: string, config: Schedulev2Config);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _teams?;
    get teams(): string[];
    set teams(value: string[]);
    resetTeams(): void;
    get teamsInput(): string[] | undefined;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    get timeZoneInput(): string | undefined;
    private _rotation;
    get rotation(): Schedulev2RotationList;
    putRotation(value: Schedulev2Rotation[] | cdktn.IResolvable): void;
    resetRotation(): void;
    get rotationInput(): cdktn.IResolvable | Schedulev2Rotation[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
