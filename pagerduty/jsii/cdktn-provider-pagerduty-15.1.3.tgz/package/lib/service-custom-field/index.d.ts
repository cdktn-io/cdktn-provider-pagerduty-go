/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServiceCustomFieldConfig extends cdktn.TerraformMetaArguments {
    /**
    * The kind of data the custom field is allowed to contain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/service_custom_field#data_type ServiceCustomField#data_type}
    */
    readonly dataType: string;
    /**
    * Default value for the field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/service_custom_field#default_value ServiceCustomField#default_value}
    */
    readonly defaultValue?: string;
    /**
    * A description of the data this field contains.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/service_custom_field#description ServiceCustomField#description}
    */
    readonly description?: string;
    /**
    * The human-readable name of the field. This must be unique across an account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/service_custom_field#display_name ServiceCustomField#display_name}
    */
    readonly displayName: string;
    /**
    * Whether the field is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/service_custom_field#enabled ServiceCustomField#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The type of data this field contains. In combination with the `data_type` field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/service_custom_field#field_type ServiceCustomField#field_type}
    */
    readonly fieldType: string;
    /**
    * The name of the field. May include ASCII characters, specifically lowercase letters, digits, and underescores. The `name` for a Field must be unique and cannot be changed once created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/service_custom_field#name ServiceCustomField#name}
    */
    readonly name: string;
    /**
    * field_option block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/service_custom_field#field_option ServiceCustomField#field_option}
    */
    readonly fieldOption?: ServiceCustomFieldFieldOption[] | cdktn.IResolvable;
}
export interface ServiceCustomFieldFieldOption {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/service_custom_field#data_type ServiceCustomField#data_type}
    */
    readonly dataType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/service_custom_field#value ServiceCustomField#value}
    */
    readonly value: string;
}
export declare function serviceCustomFieldFieldOptionToTerraform(struct?: ServiceCustomFieldFieldOption | cdktn.IResolvable): any;
export declare function serviceCustomFieldFieldOptionToHclTerraform(struct?: ServiceCustomFieldFieldOption | cdktn.IResolvable): any;
export declare class ServiceCustomFieldFieldOptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceCustomFieldFieldOption | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceCustomFieldFieldOption | cdktn.IResolvable | undefined);
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    get dataTypeInput(): string | undefined;
    get id(): string;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ServiceCustomFieldFieldOptionList extends cdktn.ComplexList {
    internalValue?: ServiceCustomFieldFieldOption[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceCustomFieldFieldOptionOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/service_custom_field pagerduty_service_custom_field}
*/
export declare class ServiceCustomField extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_service_custom_field";
    /**
    * Generates CDKTN code for importing a ServiceCustomField resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServiceCustomField to import
    * @param importFromId The id of the existing ServiceCustomField that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/service_custom_field#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServiceCustomField to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/service_custom_field pagerduty_service_custom_field} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServiceCustomFieldConfig
    */
    constructor(scope: Construct, id: string, config: ServiceCustomFieldConfig);
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    get dataTypeInput(): string | undefined;
    private _defaultValue?;
    get defaultValue(): string;
    set defaultValue(value: string);
    resetDefaultValue(): void;
    get defaultValueInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _fieldType?;
    get fieldType(): string;
    set fieldType(value: string);
    get fieldTypeInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get selfAttribute(): string;
    get summary(): string;
    get type(): string;
    private _fieldOption;
    get fieldOption(): ServiceCustomFieldFieldOptionList;
    putFieldOption(value: ServiceCustomFieldFieldOption[] | cdktn.IResolvable): void;
    resetFieldOption(): void;
    get fieldOptionInput(): cdktn.IResolvable | ServiceCustomFieldFieldOption[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
