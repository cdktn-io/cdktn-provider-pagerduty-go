/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EventOrchestrationRouterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#event_orchestration EventOrchestrationRouter#event_orchestration}
    */
    readonly eventOrchestration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#id EventOrchestrationRouter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * catch_all block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#catch_all EventOrchestrationRouter#catch_all}
    */
    readonly catchAll: EventOrchestrationRouterCatchAll;
    /**
    * set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#set EventOrchestrationRouter#set}
    */
    readonly set: EventOrchestrationRouterSet;
}
export interface EventOrchestrationRouterCatchAllActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#route_to EventOrchestrationRouter#route_to}
    */
    readonly routeTo: string;
}
export declare function eventOrchestrationRouterCatchAllActionsToTerraform(struct?: EventOrchestrationRouterCatchAllActionsOutputReference | EventOrchestrationRouterCatchAllActions): any;
export declare function eventOrchestrationRouterCatchAllActionsToHclTerraform(struct?: EventOrchestrationRouterCatchAllActionsOutputReference | EventOrchestrationRouterCatchAllActions): any;
export declare class EventOrchestrationRouterCatchAllActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationRouterCatchAllActions | undefined;
    set internalValue(value: EventOrchestrationRouterCatchAllActions | undefined);
    private _routeTo?;
    get routeTo(): string;
    set routeTo(value: string);
    get routeToInput(): string | undefined;
}
export interface EventOrchestrationRouterCatchAll {
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#actions EventOrchestrationRouter#actions}
    */
    readonly actions: EventOrchestrationRouterCatchAllActions;
}
export declare function eventOrchestrationRouterCatchAllToTerraform(struct?: EventOrchestrationRouterCatchAllOutputReference | EventOrchestrationRouterCatchAll): any;
export declare function eventOrchestrationRouterCatchAllToHclTerraform(struct?: EventOrchestrationRouterCatchAllOutputReference | EventOrchestrationRouterCatchAll): any;
export declare class EventOrchestrationRouterCatchAllOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationRouterCatchAll | undefined;
    set internalValue(value: EventOrchestrationRouterCatchAll | undefined);
    private _actions;
    get actions(): EventOrchestrationRouterCatchAllActionsOutputReference;
    putActions(value: EventOrchestrationRouterCatchAllActions): void;
    get actionsInput(): EventOrchestrationRouterCatchAllActions | undefined;
}
export interface EventOrchestrationRouterSetRuleActionsDynamicRouteTo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#lookup_by EventOrchestrationRouter#lookup_by}
    */
    readonly lookupBy: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#regex EventOrchestrationRouter#regex}
    */
    readonly regex: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#source EventOrchestrationRouter#source}
    */
    readonly source: string;
}
export declare function eventOrchestrationRouterSetRuleActionsDynamicRouteToToTerraform(struct?: EventOrchestrationRouterSetRuleActionsDynamicRouteTo | cdktn.IResolvable): any;
export declare function eventOrchestrationRouterSetRuleActionsDynamicRouteToToHclTerraform(struct?: EventOrchestrationRouterSetRuleActionsDynamicRouteTo | cdktn.IResolvable): any;
export declare class EventOrchestrationRouterSetRuleActionsDynamicRouteToOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationRouterSetRuleActionsDynamicRouteTo | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationRouterSetRuleActionsDynamicRouteTo | cdktn.IResolvable | undefined);
    private _lookupBy?;
    get lookupBy(): string;
    set lookupBy(value: string);
    get lookupByInput(): string | undefined;
    private _regex?;
    get regex(): string;
    set regex(value: string);
    get regexInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
}
export declare class EventOrchestrationRouterSetRuleActionsDynamicRouteToList extends cdktn.ComplexList {
    internalValue?: EventOrchestrationRouterSetRuleActionsDynamicRouteTo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationRouterSetRuleActionsDynamicRouteToOutputReference;
}
export interface EventOrchestrationRouterSetRuleActions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#route_to EventOrchestrationRouter#route_to}
    */
    readonly routeTo?: string;
    /**
    * dynamic_route_to block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#dynamic_route_to EventOrchestrationRouter#dynamic_route_to}
    */
    readonly dynamicRouteTo?: EventOrchestrationRouterSetRuleActionsDynamicRouteTo[] | cdktn.IResolvable;
}
export declare function eventOrchestrationRouterSetRuleActionsToTerraform(struct?: EventOrchestrationRouterSetRuleActionsOutputReference | EventOrchestrationRouterSetRuleActions): any;
export declare function eventOrchestrationRouterSetRuleActionsToHclTerraform(struct?: EventOrchestrationRouterSetRuleActionsOutputReference | EventOrchestrationRouterSetRuleActions): any;
export declare class EventOrchestrationRouterSetRuleActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationRouterSetRuleActions | undefined;
    set internalValue(value: EventOrchestrationRouterSetRuleActions | undefined);
    private _routeTo?;
    get routeTo(): string;
    set routeTo(value: string);
    resetRouteTo(): void;
    get routeToInput(): string | undefined;
    private _dynamicRouteTo;
    get dynamicRouteTo(): EventOrchestrationRouterSetRuleActionsDynamicRouteToList;
    putDynamicRouteTo(value: EventOrchestrationRouterSetRuleActionsDynamicRouteTo[] | cdktn.IResolvable): void;
    resetDynamicRouteTo(): void;
    get dynamicRouteToInput(): cdktn.IResolvable | EventOrchestrationRouterSetRuleActionsDynamicRouteTo[] | undefined;
}
export interface EventOrchestrationRouterSetRuleCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#expression EventOrchestrationRouter#expression}
    */
    readonly expression: string;
}
export declare function eventOrchestrationRouterSetRuleConditionToTerraform(struct?: EventOrchestrationRouterSetRuleCondition | cdktn.IResolvable): any;
export declare function eventOrchestrationRouterSetRuleConditionToHclTerraform(struct?: EventOrchestrationRouterSetRuleCondition | cdktn.IResolvable): any;
export declare class EventOrchestrationRouterSetRuleConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationRouterSetRuleCondition | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationRouterSetRuleCondition | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export declare class EventOrchestrationRouterSetRuleConditionList extends cdktn.ComplexList {
    internalValue?: EventOrchestrationRouterSetRuleCondition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationRouterSetRuleConditionOutputReference;
}
export interface EventOrchestrationRouterSetRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#disabled EventOrchestrationRouter#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#label EventOrchestrationRouter#label}
    */
    readonly label?: string;
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#actions EventOrchestrationRouter#actions}
    */
    readonly actions: EventOrchestrationRouterSetRuleActions;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#condition EventOrchestrationRouter#condition}
    */
    readonly condition?: EventOrchestrationRouterSetRuleCondition[] | cdktn.IResolvable;
}
export declare function eventOrchestrationRouterSetRuleToTerraform(struct?: EventOrchestrationRouterSetRule | cdktn.IResolvable): any;
export declare function eventOrchestrationRouterSetRuleToHclTerraform(struct?: EventOrchestrationRouterSetRule | cdktn.IResolvable): any;
export declare class EventOrchestrationRouterSetRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EventOrchestrationRouterSetRule | cdktn.IResolvable | undefined;
    set internalValue(value: EventOrchestrationRouterSetRule | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _actions;
    get actions(): EventOrchestrationRouterSetRuleActionsOutputReference;
    putActions(value: EventOrchestrationRouterSetRuleActions): void;
    get actionsInput(): EventOrchestrationRouterSetRuleActions | undefined;
    private _condition;
    get condition(): EventOrchestrationRouterSetRuleConditionList;
    putCondition(value: EventOrchestrationRouterSetRuleCondition[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | EventOrchestrationRouterSetRuleCondition[] | undefined;
}
export declare class EventOrchestrationRouterSetRuleList extends cdktn.ComplexList {
    internalValue?: EventOrchestrationRouterSetRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EventOrchestrationRouterSetRuleOutputReference;
}
export interface EventOrchestrationRouterSet {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#id EventOrchestrationRouter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#rule EventOrchestrationRouter#rule}
    */
    readonly rule?: EventOrchestrationRouterSetRule[] | cdktn.IResolvable;
}
export declare function eventOrchestrationRouterSetToTerraform(struct?: EventOrchestrationRouterSetOutputReference | EventOrchestrationRouterSet): any;
export declare function eventOrchestrationRouterSetToHclTerraform(struct?: EventOrchestrationRouterSetOutputReference | EventOrchestrationRouterSet): any;
export declare class EventOrchestrationRouterSetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EventOrchestrationRouterSet | undefined;
    set internalValue(value: EventOrchestrationRouterSet | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _rule;
    get rule(): EventOrchestrationRouterSetRuleList;
    putRule(value: EventOrchestrationRouterSetRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | EventOrchestrationRouterSetRule[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router pagerduty_event_orchestration_router}
*/
export declare class EventOrchestrationRouter extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_event_orchestration_router";
    /**
    * Generates CDKTN code for importing a EventOrchestrationRouter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EventOrchestrationRouter to import
    * @param importFromId The id of the existing EventOrchestrationRouter that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EventOrchestrationRouter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/event_orchestration_router pagerduty_event_orchestration_router} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EventOrchestrationRouterConfig
    */
    constructor(scope: Construct, id: string, config: EventOrchestrationRouterConfig);
    private _eventOrchestration?;
    get eventOrchestration(): string;
    set eventOrchestration(value: string);
    get eventOrchestrationInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _catchAll;
    get catchAll(): EventOrchestrationRouterCatchAllOutputReference;
    putCatchAll(value: EventOrchestrationRouterCatchAll): void;
    get catchAllInput(): EventOrchestrationRouterCatchAll | undefined;
    private _set;
    get set(): EventOrchestrationRouterSetOutputReference;
    putSet(value: EventOrchestrationRouterSet): void;
    get setInput(): EventOrchestrationRouterSet | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
