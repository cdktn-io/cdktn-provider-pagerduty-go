/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IncidentWorkflowConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#description IncidentWorkflow#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#id IncidentWorkflow#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#is_enabled IncidentWorkflow#is_enabled}
    */
    readonly isEnabled?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#name IncidentWorkflow#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#team IncidentWorkflow#team}
    */
    readonly team?: string;
    /**
    * step block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#step IncidentWorkflow#step}
    */
    readonly step?: IncidentWorkflowStep[] | cdktn.IResolvable;
}
export interface IncidentWorkflowStepInlineStepsInputStepInput {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#name IncidentWorkflow#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#value IncidentWorkflow#value}
    */
    readonly value: string;
}
export declare function incidentWorkflowStepInlineStepsInputStepInputToTerraform(struct?: IncidentWorkflowStepInlineStepsInputStepInput | cdktn.IResolvable): any;
export declare function incidentWorkflowStepInlineStepsInputStepInputToHclTerraform(struct?: IncidentWorkflowStepInlineStepsInputStepInput | cdktn.IResolvable): any;
export declare class IncidentWorkflowStepInlineStepsInputStepInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IncidentWorkflowStepInlineStepsInputStepInput | cdktn.IResolvable | undefined;
    set internalValue(value: IncidentWorkflowStepInlineStepsInputStepInput | cdktn.IResolvable | undefined);
    get generated(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class IncidentWorkflowStepInlineStepsInputStepInputList extends cdktn.ComplexList {
    internalValue?: IncidentWorkflowStepInlineStepsInputStepInput[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IncidentWorkflowStepInlineStepsInputStepInputOutputReference;
}
export interface IncidentWorkflowStepInlineStepsInputStep {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#action IncidentWorkflow#action}
    */
    readonly action: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#name IncidentWorkflow#name}
    */
    readonly name: string;
    /**
    * input block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#input IncidentWorkflow#input}
    */
    readonly input?: IncidentWorkflowStepInlineStepsInputStepInput[] | cdktn.IResolvable;
}
export declare function incidentWorkflowStepInlineStepsInputStepToTerraform(struct?: IncidentWorkflowStepInlineStepsInputStep | cdktn.IResolvable): any;
export declare function incidentWorkflowStepInlineStepsInputStepToHclTerraform(struct?: IncidentWorkflowStepInlineStepsInputStep | cdktn.IResolvable): any;
export declare class IncidentWorkflowStepInlineStepsInputStepOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IncidentWorkflowStepInlineStepsInputStep | cdktn.IResolvable | undefined;
    set internalValue(value: IncidentWorkflowStepInlineStepsInputStep | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _input;
    get input(): IncidentWorkflowStepInlineStepsInputStepInputList;
    putInput(value: IncidentWorkflowStepInlineStepsInputStepInput[] | cdktn.IResolvable): void;
    resetInput(): void;
    get inputInput(): cdktn.IResolvable | IncidentWorkflowStepInlineStepsInputStepInput[] | undefined;
}
export declare class IncidentWorkflowStepInlineStepsInputStepList extends cdktn.ComplexList {
    internalValue?: IncidentWorkflowStepInlineStepsInputStep[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IncidentWorkflowStepInlineStepsInputStepOutputReference;
}
export interface IncidentWorkflowStepInlineStepsInput {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#name IncidentWorkflow#name}
    */
    readonly name: string;
    /**
    * step block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#step IncidentWorkflow#step}
    */
    readonly step?: IncidentWorkflowStepInlineStepsInputStep[] | cdktn.IResolvable;
}
export declare function incidentWorkflowStepInlineStepsInputToTerraform(struct?: IncidentWorkflowStepInlineStepsInput | cdktn.IResolvable): any;
export declare function incidentWorkflowStepInlineStepsInputToHclTerraform(struct?: IncidentWorkflowStepInlineStepsInput | cdktn.IResolvable): any;
export declare class IncidentWorkflowStepInlineStepsInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IncidentWorkflowStepInlineStepsInput | cdktn.IResolvable | undefined;
    set internalValue(value: IncidentWorkflowStepInlineStepsInput | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _step;
    get step(): IncidentWorkflowStepInlineStepsInputStepList;
    putStep(value: IncidentWorkflowStepInlineStepsInputStep[] | cdktn.IResolvable): void;
    resetStep(): void;
    get stepInput(): cdktn.IResolvable | IncidentWorkflowStepInlineStepsInputStep[] | undefined;
}
export declare class IncidentWorkflowStepInlineStepsInputList extends cdktn.ComplexList {
    internalValue?: IncidentWorkflowStepInlineStepsInput[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IncidentWorkflowStepInlineStepsInputOutputReference;
}
export interface IncidentWorkflowStepInput {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#name IncidentWorkflow#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#value IncidentWorkflow#value}
    */
    readonly value: string;
}
export declare function incidentWorkflowStepInputToTerraform(struct?: IncidentWorkflowStepInput | cdktn.IResolvable): any;
export declare function incidentWorkflowStepInputToHclTerraform(struct?: IncidentWorkflowStepInput | cdktn.IResolvable): any;
export declare class IncidentWorkflowStepInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IncidentWorkflowStepInput | cdktn.IResolvable | undefined;
    set internalValue(value: IncidentWorkflowStepInput | cdktn.IResolvable | undefined);
    get generated(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class IncidentWorkflowStepInputList extends cdktn.ComplexList {
    internalValue?: IncidentWorkflowStepInput[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IncidentWorkflowStepInputOutputReference;
}
export interface IncidentWorkflowStep {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#action IncidentWorkflow#action}
    */
    readonly action: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#name IncidentWorkflow#name}
    */
    readonly name: string;
    /**
    * inline_steps_input block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#inline_steps_input IncidentWorkflow#inline_steps_input}
    */
    readonly inlineStepsInput?: IncidentWorkflowStepInlineStepsInput[] | cdktn.IResolvable;
    /**
    * input block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#input IncidentWorkflow#input}
    */
    readonly input?: IncidentWorkflowStepInput[] | cdktn.IResolvable;
}
export declare function incidentWorkflowStepToTerraform(struct?: IncidentWorkflowStep | cdktn.IResolvable): any;
export declare function incidentWorkflowStepToHclTerraform(struct?: IncidentWorkflowStep | cdktn.IResolvable): any;
export declare class IncidentWorkflowStepOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IncidentWorkflowStep | cdktn.IResolvable | undefined;
    set internalValue(value: IncidentWorkflowStep | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _inlineStepsInput;
    get inlineStepsInput(): IncidentWorkflowStepInlineStepsInputList;
    putInlineStepsInput(value: IncidentWorkflowStepInlineStepsInput[] | cdktn.IResolvable): void;
    resetInlineStepsInput(): void;
    get inlineStepsInputInput(): cdktn.IResolvable | IncidentWorkflowStepInlineStepsInput[] | undefined;
    private _input;
    get input(): IncidentWorkflowStepInputList;
    putInput(value: IncidentWorkflowStepInput[] | cdktn.IResolvable): void;
    resetInput(): void;
    get inputInput(): cdktn.IResolvable | IncidentWorkflowStepInput[] | undefined;
}
export declare class IncidentWorkflowStepList extends cdktn.ComplexList {
    internalValue?: IncidentWorkflowStep[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IncidentWorkflowStepOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow pagerduty_incident_workflow}
*/
export declare class IncidentWorkflow extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_incident_workflow";
    /**
    * Generates CDKTN code for importing a IncidentWorkflow resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IncidentWorkflow to import
    * @param importFromId The id of the existing IncidentWorkflow that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IncidentWorkflow to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/resources/incident_workflow pagerduty_incident_workflow} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IncidentWorkflowConfig
    */
    constructor(scope: Construct, id: string, config: IncidentWorkflowConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isEnabled?;
    get isEnabled(): string;
    set isEnabled(value: string);
    resetIsEnabled(): void;
    get isEnabledInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _team?;
    get team(): string;
    set team(value: string);
    resetTeam(): void;
    get teamInput(): string | undefined;
    private _step;
    get step(): IncidentWorkflowStepList;
    putStep(value: IncidentWorkflowStep[] | cdktn.IResolvable): void;
    resetStep(): void;
    get stepInput(): cdktn.IResolvable | IncidentWorkflowStep[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
