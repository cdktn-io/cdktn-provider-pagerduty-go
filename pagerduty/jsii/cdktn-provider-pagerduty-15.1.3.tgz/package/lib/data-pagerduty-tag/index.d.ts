/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPagerdutyTagConfig extends cdktn.TerraformMetaArguments {
    /**
    * The label of the tag to find in the PagerDuty API
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/data-sources/tag#label DataPagerdutyTag#label}
    */
    readonly label: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/data-sources/tag pagerduty_tag}
*/
export declare class DataPagerdutyTag extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_tag";
    /**
    * Generates CDKTN code for importing a DataPagerdutyTag resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyTag to import
    * @param importFromId The id of the existing DataPagerdutyTag that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/data-sources/tag#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyTag to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.32.3/docs/data-sources/tag pagerduty_tag} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyTagConfig
    */
    constructor(scope: Construct, id: string, config: DataPagerdutyTagConfig);
    get id(): string;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
