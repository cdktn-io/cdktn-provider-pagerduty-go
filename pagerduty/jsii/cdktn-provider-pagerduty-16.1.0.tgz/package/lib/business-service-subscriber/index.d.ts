/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BusinessServiceSubscriberConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.33.0/docs/resources/business_service_subscriber#business_service_id BusinessServiceSubscriber#business_service_id}
    */
    readonly businessServiceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.33.0/docs/resources/business_service_subscriber#id BusinessServiceSubscriber#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.33.0/docs/resources/business_service_subscriber#subscriber_id BusinessServiceSubscriber#subscriber_id}
    */
    readonly subscriberId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.33.0/docs/resources/business_service_subscriber#subscriber_type BusinessServiceSubscriber#subscriber_type}
    */
    readonly subscriberType: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.33.0/docs/resources/business_service_subscriber pagerduty_business_service_subscriber}
*/
export declare class BusinessServiceSubscriber extends cdktn.TerraformResource {
    static readonly tfResourceType = "pagerduty_business_service_subscriber";
    /**
    * Generates CDKTN code for importing a BusinessServiceSubscriber resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BusinessServiceSubscriber to import
    * @param importFromId The id of the existing BusinessServiceSubscriber that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.33.0/docs/resources/business_service_subscriber#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BusinessServiceSubscriber to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.33.0/docs/resources/business_service_subscriber pagerduty_business_service_subscriber} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BusinessServiceSubscriberConfig
    */
    constructor(scope: Construct, id: string, config: BusinessServiceSubscriberConfig);
    private _businessServiceId?;
    get businessServiceId(): string;
    set businessServiceId(value: string);
    get businessServiceIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _subscriberId?;
    get subscriberId(): string;
    set subscriberId(value: string);
    get subscriberIdInput(): string | undefined;
    private _subscriberType?;
    get subscriberType(): string;
    set subscriberType(value: string);
    get subscriberTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
