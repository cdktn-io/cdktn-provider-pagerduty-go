/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPagerdutyAlertGroupingSettingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/alert_grouping_setting#name DataPagerdutyAlertGroupingSetting#name}
    */
    readonly name: string;
}
export interface DataPagerdutyAlertGroupingSettingConfigA {
}
export declare function dataPagerdutyAlertGroupingSettingConfigAToTerraform(struct?: DataPagerdutyAlertGroupingSettingConfigA | cdktn.IResolvable): any;
export declare function dataPagerdutyAlertGroupingSettingConfigAToHclTerraform(struct?: DataPagerdutyAlertGroupingSettingConfigA | cdktn.IResolvable): any;
export declare class DataPagerdutyAlertGroupingSettingConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataPagerdutyAlertGroupingSettingConfigA | cdktn.IResolvable | undefined;
    set internalValue(value: DataPagerdutyAlertGroupingSettingConfigA | cdktn.IResolvable | undefined);
    get aggregate(): string;
    get fields(): string[];
    get iagFields(): string[];
    get timeWindow(): number;
    get timeout(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/alert_grouping_setting pagerduty_alert_grouping_setting}
*/
export declare class DataPagerdutyAlertGroupingSetting extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_alert_grouping_setting";
    /**
    * Generates CDKTN code for importing a DataPagerdutyAlertGroupingSetting resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyAlertGroupingSetting to import
    * @param importFromId The id of the existing DataPagerdutyAlertGroupingSetting that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/alert_grouping_setting#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyAlertGroupingSetting to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/alert_grouping_setting pagerduty_alert_grouping_setting} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyAlertGroupingSettingConfig
    */
    constructor(scope: Construct, id: string, config: DataPagerdutyAlertGroupingSettingConfig);
    get description(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get services(): string[];
    get type(): string;
    private _config;
    get config(): DataPagerdutyAlertGroupingSettingConfigAOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
