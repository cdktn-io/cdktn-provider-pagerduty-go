/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPagerdutyAutomationActionsActionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/automation_actions_action#action_classification DataPagerdutyAutomationActionsAction#action_classification}
    */
    readonly actionClassification?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/automation_actions_action#allow_invocation_from_event_orchestration DataPagerdutyAutomationActionsAction#allow_invocation_from_event_orchestration}
    */
    readonly allowInvocationFromEventOrchestration?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/automation_actions_action#allow_invocation_manually DataPagerdutyAutomationActionsAction#allow_invocation_manually}
    */
    readonly allowInvocationManually?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/automation_actions_action#creation_time DataPagerdutyAutomationActionsAction#creation_time}
    */
    readonly creationTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/automation_actions_action#description DataPagerdutyAutomationActionsAction#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/automation_actions_action#id DataPagerdutyAutomationActionsAction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/automation_actions_action#map_to_all_services DataPagerdutyAutomationActionsAction#map_to_all_services}
    */
    readonly mapToAllServices?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/automation_actions_action#modify_time DataPagerdutyAutomationActionsAction#modify_time}
    */
    readonly modifyTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/automation_actions_action#only_invocable_on_unresolved_incidents DataPagerdutyAutomationActionsAction#only_invocable_on_unresolved_incidents}
    */
    readonly onlyInvocableOnUnresolvedIncidents?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/automation_actions_action#runner_id DataPagerdutyAutomationActionsAction#runner_id}
    */
    readonly runnerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/automation_actions_action#runner_type DataPagerdutyAutomationActionsAction#runner_type}
    */
    readonly runnerType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/automation_actions_action#type DataPagerdutyAutomationActionsAction#type}
    */
    readonly type?: string;
}
export interface DataPagerdutyAutomationActionsActionActionDataReference {
}
export declare function dataPagerdutyAutomationActionsActionActionDataReferenceToTerraform(struct?: DataPagerdutyAutomationActionsActionActionDataReference): any;
export declare function dataPagerdutyAutomationActionsActionActionDataReferenceToHclTerraform(struct?: DataPagerdutyAutomationActionsActionActionDataReference): any;
export declare class DataPagerdutyAutomationActionsActionActionDataReferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyAutomationActionsActionActionDataReference | undefined;
    set internalValue(value: DataPagerdutyAutomationActionsActionActionDataReference | undefined);
    get invocationCommand(): string;
    get processAutomationJobArguments(): string;
    get processAutomationJobId(): string;
    get processAutomationNodeFilter(): string;
    get script(): string;
}
export declare class DataPagerdutyAutomationActionsActionActionDataReferenceList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyAutomationActionsActionActionDataReferenceOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/automation_actions_action pagerduty_automation_actions_action}
*/
export declare class DataPagerdutyAutomationActionsAction extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_automation_actions_action";
    /**
    * Generates CDKTN code for importing a DataPagerdutyAutomationActionsAction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyAutomationActionsAction to import
    * @param importFromId The id of the existing DataPagerdutyAutomationActionsAction that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/automation_actions_action#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyAutomationActionsAction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/automation_actions_action pagerduty_automation_actions_action} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyAutomationActionsActionConfig
    */
    constructor(scope: Construct, id: string, config: DataPagerdutyAutomationActionsActionConfig);
    private _actionClassification?;
    get actionClassification(): string;
    set actionClassification(value: string);
    resetActionClassification(): void;
    get actionClassificationInput(): string | undefined;
    private _actionDataReference;
    get actionDataReference(): DataPagerdutyAutomationActionsActionActionDataReferenceList;
    get actionType(): string;
    private _allowInvocationFromEventOrchestration?;
    get allowInvocationFromEventOrchestration(): boolean | cdktn.IResolvable;
    set allowInvocationFromEventOrchestration(value: boolean | cdktn.IResolvable);
    resetAllowInvocationFromEventOrchestration(): void;
    get allowInvocationFromEventOrchestrationInput(): boolean | cdktn.IResolvable | undefined;
    private _allowInvocationManually?;
    get allowInvocationManually(): boolean | cdktn.IResolvable;
    set allowInvocationManually(value: boolean | cdktn.IResolvable);
    resetAllowInvocationManually(): void;
    get allowInvocationManuallyInput(): boolean | cdktn.IResolvable | undefined;
    private _creationTime?;
    get creationTime(): string;
    set creationTime(value: string);
    resetCreationTime(): void;
    get creationTimeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _mapToAllServices?;
    get mapToAllServices(): boolean | cdktn.IResolvable;
    set mapToAllServices(value: boolean | cdktn.IResolvable);
    resetMapToAllServices(): void;
    get mapToAllServicesInput(): boolean | cdktn.IResolvable | undefined;
    private _modifyTime?;
    get modifyTime(): string;
    set modifyTime(value: string);
    resetModifyTime(): void;
    get modifyTimeInput(): string | undefined;
    get name(): string;
    private _onlyInvocableOnUnresolvedIncidents?;
    get onlyInvocableOnUnresolvedIncidents(): boolean | cdktn.IResolvable;
    set onlyInvocableOnUnresolvedIncidents(value: boolean | cdktn.IResolvable);
    resetOnlyInvocableOnUnresolvedIncidents(): void;
    get onlyInvocableOnUnresolvedIncidentsInput(): boolean | cdktn.IResolvable | undefined;
    private _runnerId?;
    get runnerId(): string;
    set runnerId(value: string);
    resetRunnerId(): void;
    get runnerIdInput(): string | undefined;
    private _runnerType?;
    get runnerType(): string;
    set runnerType(value: string);
    resetRunnerType(): void;
    get runnerTypeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
