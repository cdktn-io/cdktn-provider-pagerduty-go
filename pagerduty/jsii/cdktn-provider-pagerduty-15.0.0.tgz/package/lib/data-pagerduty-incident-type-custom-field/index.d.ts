/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPagerdutyIncidentTypeCustomFieldConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/incident_type_custom_field#display_name DataPagerdutyIncidentTypeCustomField#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/incident_type_custom_field#incident_type DataPagerdutyIncidentTypeCustomField#incident_type}
    */
    readonly incidentType: string;
}
export interface DataPagerdutyIncidentTypeCustomFieldFieldOptionsData {
}
export declare function dataPagerdutyIncidentTypeCustomFieldFieldOptionsDataToTerraform(struct?: DataPagerdutyIncidentTypeCustomFieldFieldOptionsData): any;
export declare function dataPagerdutyIncidentTypeCustomFieldFieldOptionsDataToHclTerraform(struct?: DataPagerdutyIncidentTypeCustomFieldFieldOptionsData): any;
export declare class DataPagerdutyIncidentTypeCustomFieldFieldOptionsDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataPagerdutyIncidentTypeCustomFieldFieldOptionsData | undefined;
    set internalValue(value: DataPagerdutyIncidentTypeCustomFieldFieldOptionsData | undefined);
    get dataType(): string;
    get value(): string;
}
export interface DataPagerdutyIncidentTypeCustomFieldFieldOptions {
}
export declare function dataPagerdutyIncidentTypeCustomFieldFieldOptionsToTerraform(struct?: DataPagerdutyIncidentTypeCustomFieldFieldOptions): any;
export declare function dataPagerdutyIncidentTypeCustomFieldFieldOptionsToHclTerraform(struct?: DataPagerdutyIncidentTypeCustomFieldFieldOptions): any;
export declare class DataPagerdutyIncidentTypeCustomFieldFieldOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPagerdutyIncidentTypeCustomFieldFieldOptions | undefined;
    set internalValue(value: DataPagerdutyIncidentTypeCustomFieldFieldOptions | undefined);
    private _data;
    get data(): DataPagerdutyIncidentTypeCustomFieldFieldOptionsDataOutputReference;
    get id(): string;
    get type(): string;
}
export declare class DataPagerdutyIncidentTypeCustomFieldFieldOptionsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPagerdutyIncidentTypeCustomFieldFieldOptionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/incident_type_custom_field pagerduty_incident_type_custom_field}
*/
export declare class DataPagerdutyIncidentTypeCustomField extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "pagerduty_incident_type_custom_field";
    /**
    * Generates CDKTN code for importing a DataPagerdutyIncidentTypeCustomField resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPagerdutyIncidentTypeCustomField to import
    * @param importFromId The id of the existing DataPagerdutyIncidentTypeCustomField that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/incident_type_custom_field#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPagerdutyIncidentTypeCustomField to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/data-sources/incident_type_custom_field pagerduty_incident_type_custom_field} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPagerdutyIncidentTypeCustomFieldConfig
    */
    constructor(scope: Construct, id: string, config: DataPagerdutyIncidentTypeCustomFieldConfig);
    get dataType(): string;
    get defaultValue(): string;
    get description(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get enabled(): cdktn.IResolvable;
    private _fieldOptions;
    get fieldOptions(): DataPagerdutyIncidentTypeCustomFieldFieldOptionsList;
    get fieldType(): string;
    get id(): string;
    private _incidentType?;
    get incidentType(): string;
    set incidentType(value: string);
    get incidentTypeInput(): string | undefined;
    get name(): string;
    get selfAttribute(): string;
    get summary(): string;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
